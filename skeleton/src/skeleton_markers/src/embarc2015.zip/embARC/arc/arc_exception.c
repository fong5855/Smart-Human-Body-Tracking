/* ------------------------------------------
 * Copyright (c) 2015, Synopsys, Inc. All rights reserved.

 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:

 * 1) Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.

 * 2) Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation and/or
 * other materials provided with the distribution.

 * 3) Neither the name of the Synopsys, Inc., nor the names of its contributors may
 * be used to endorse or promote products derived from this software without
 * specific prior written permission.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * \version 2015.05
 * \date 2014-07-15
 * \author Wayne Ren(Wei.Ren@synopsys.com)
--------------------------------------------- */

/**
 * \file
 * \ingroup ARC_HAL_EXCEPTION_CPU ARC_HAL_EXCEPTION_INTERRUPT
 * \brief C Implementation of exception and interrupt management
 */

#include "arc_exception.h"
#include "arc_cache.h"

/**
 * \addtogroup ARC_HAL_EXCEPTION_CPU
 * @{
 * \var exc_entry_table
 * \brief exception entry table
 *
 * install exception entry table to ARC_AUX_INT_VECT_BASE in startup.
 * According to ARCv2 ISA, vectors are fetched in instruction space and thus
 * may be present in ICCM, Instruction Cache, or
 * main memory accessed by instruction fetch logic.
 * So it is put into a specific section .vector.
 *
 * Please note that the exc_entry_table maybe cached in ARC. Some functions is
 * defined in .s files.
 *
 */
__attribute__ ((aligned(1024), section(".vector")))
EXC_ENTRY exc_entry_table[NUM_EXC_ALL];
/**
 * \var exc_int_handler_table
 * \brief the cpu exception and interrupt exception handler table
 * called in exc_entry_default and exc_entry_int
 */
EXC_HANDLER exc_int_handler_table[NUM_EXC_ALL];

/**
 * \var exc_nest_count
 * \brief the counter for exc/int processing, =0 no int/exc
 * >1 in int/exc processing
 * @}
 */
unsigned int exc_nest_count;

/**
 * \ingroup ARC_HAL_EXCEPTION_CPU
 * \brief  default cpu exception handler
 * \param exc_frame pointer to the exception frame
 */
static void exc_handler_default(void *exc_frame)
{
	exc_frame = exc_frame;
	Asm("flag 1");
}

/**
 * \ingroup ARC_HAL_EXCEPTION_CPU
 * \brief  install a CPU exception entry
 * \param[in] excno exception number
 * \param[in] entry the entry of exception to install
 */
int exc_entry_install(const unsigned int excno, EXC_ENTRY entry)
{
	unsigned int status;

	if (excno < NUM_EXC_ALL && entry != NULL) {
		status = cpu_lock_save();
		/* directly write to mem, as arc gets exception handler from mem not from cache */
		/* FIXME, here maybe icache is dirty, need to be invalidated */
		exc_entry_table[excno] = entry;

		if (_arc_aux_read(AUX_BCR_D_CACHE) > 0x2) {
		/* dcache is available */
			dcache_invalidate_line((uint32_t)&exc_entry_table[excno]);
			dcache_flush_line((uint32_t)&exc_entry_table[excno]);
		}

		if (_arc_aux_read(AUX_BCR_D_CACHE) > 0x2) {
		/* icache is available */
			icache_invalidate_line((uint32_t)&exc_entry_table[excno]);
		}
		cpu_unlock_restore(status);
		return 0;
	}
	return -1;
}

/**
 * \ingroup ARC_HAL_EXCEPTION_CPU
 * \brief  get the installed CPU exception entry
 * \param[in] excno exception number
 * \return the installed CPU exception entry
 */
EXC_ENTRY exc_entry_get(const unsigned int excno)
{
	if (excno < NUM_EXC_ALL) {
		return exc_entry_table[excno];
	}
	return NULL;
}

/**
 * \ingroup ARC_HAL_EXCEPTION_CPU
 * \brief  install an exception handler
 * \param[in] excno	exception number
 * \param[in] handler the handler of exception to install
 */
int exc_handler_install(const unsigned int excno, EXC_HANDLER handler)
{
	if (excno < NUM_EXC_CPU && handler != NULL) {
		exc_int_handler_table[excno] = handler;
		return 0;
	}

	return -1;
}

/**
 * \ingroup ARC_HAL_EXCEPTION_CPU
 * \brief  get the installed exception handler
 * \param[in] excno	exception number
 * \return the installed exception handler or NULL
 */
EXC_HANDLER exc_handler_get(const unsigned int excno)
{
	if (excno < NUM_EXC_CPU) {
		return exc_int_handler_table[excno];
	}

	return NULL;
}

/**
 * \ingroup ARC_HAL_EXCEPTION_INTERRUPT
 * \brief  default interrupt handler
 * \param[in] ptr	information for interrupt handler
 */
static void int_handler_default(void *ptr)
{
	ptr = ptr;
	Asm("flag 1");
}

/**
 * \ingroup ARC_HAL_EXCEPTION_CPU ARC_HAL_EXCEPTION_INTERRUPT
 * \brief  intialize the exception and interrupt handling
 */
void exc_int_init(void)
{
	int i;
	unsigned int status;

	status = cpu_lock_save();
	exc_entry_table[0] = _arc_reset;
	/* init cpu exceptions */
	for (i = 1; i < NUM_EXC_CPU; i++)
	{
		exc_entry_table[i] = exc_entry_default;
		exc_int_handler_table[i] = (EXC_HANDLER)exc_handler_default;
	}

	for (;i < NUM_EXC_ALL; i++)
	{
		exc_entry_table[i] = exc_entry_int;
		exc_int_handler_table[i] = (EXC_HANDLER)int_handler_default;
	}
	_arc_aux_write(AUX_IRQ_CTRL, 0);
	if (_arc_aux_read(AUX_BCR_D_CACHE) > 0x2) {
	/* dcache is available */
		dcache_invalidate();
		dcache_flush();
	}

	if (_arc_aux_read(AUX_BCR_I_CACHE) > 0x2) {
	/* icache is available */
		icache_invalidate();
	}
	cpu_unlock_restore(status);

}

/**
 * \ingroup ARC_HAL_EXCEPTION_INTERRUPT
 * \brief  install an interrupt handler
 * \param[in] intno	interrupt number
 * \param[in] handler interrupt handler to install
 */
int int_handler_install(const unsigned int intno, INT_HANDLER handler)
{
	/*!< \todo parameter check ? */
	if (intno >= NUM_EXC_CPU && intno < NUM_EXC_ALL && handler != NULL) {
		exc_int_handler_table[intno] = handler;
		return 0;
	}

	return -1;
}

/**
 * \ingroup ARC_HAL_EXCEPTION_INTERRUPT
 * \brief  get the installed an interrupt handler
 * \param[in] intno interrupt number
 * \return the installed interrupt handler or NULL
 */
INT_HANDLER int_handler_get(const unsigned int intno)
{
	if (intno >= NUM_EXC_CPU && intno < NUM_EXC_ALL) {
		return exc_int_handler_table[intno];
	}

	return NULL;
}