/* ------------------------------------------
 * Copyright (c) 2015, Synopsys, Inc. All rights reserved.

 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:

 * 1) Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.

 * 2) Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation and/or
 * other materials provided with the distribution.

 * 3) Neither the name of the Synopsys, Inc., nor the names of its contributors may
 * be used to endorse or promote products derived from this software without
 * specific prior written permission.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * \version 2015.05
 * \date 2014-06-17
 * \author Huaqi Fang(Huaqi.Fang@synopsys.com)
--------------------------------------------- */

/**
 * \defgroup	DEVICE_HAL_GPIO		GPIO Device HAL Interface
 * \ingroup	DEVICE_HAL_DEF
 * \brief	definitions for gpio device hardware layer(\ref dev_gpio.h)
 * \details	provide interfaces for gpio driver to implement
 *  Here is a diagram for the gpio interface.
 *
 *  \htmlonly
 *  <div class="imagebox">
 *      <div style="width: 600px">
 *          <img src="pic/dev_gpio_hal.jpg" alt="GPIO Device HAL Interface Diagram"/>
 *          <p>GPIO Device HAL Interface Diagram</p>
 *      </div>
 *  </div>
 *  \endhtmlonly
 *
 * @{
 *
 * \file
 * \brief	gpio device hardware layer definitions
 * \details	Provide common definitions for gpio device,
 * 	then the software developer can develop gpio driver
 * 	following these definitions, and the applications
 * 	can directly call this definition to realize functions
 *
 */

#ifndef _DEVICE_HAL_GPIO_H_
#define _DEVICE_HAL_GPIO_H_

#include "dev_common.h"

/**
 * \defgroup	DEVICE_HAL_GPIO_DEFDIR	GPIO Port Direction Definition
 * \ingroup	DEVICE_HAL_GPIO
 * \brief	Define macros to indicate gpio directions
 * @{
 */
/*
 * defines for gpio directions
 */
#define GPIO_DIR_INPUT				(0)		/*!< gpio works as input */
#define GPIO_DIR_OUTPUT				(1)		/*!< gpio works as output */
/** @} */

/**
 * \defgroup	DEVICE_HAL_GPIO_CTRLCMD	GPIO Device Control Command
 * \ingroup	DEVICE_HAL_GPIO
 * \brief	definitions for spi control command, used in \ref dev_gpio::gpio_control
 * @{
 */
/*
 * defines for system control commands of gpio
 * commands need by gpio_control::ctrl_cmd
 */
#define GPIO_CMD_CHG_MTHD_POLL			DEV_SET_SYSCMD(0x0)	/*!< ctrl command: change gpio method to poll with mask */
#define GPIO_CMD_CHG_MTHD_INT			DEV_SET_SYSCMD(0x1)	/*!< ctrl command: change gpio method to interrupt with mask  */
#define GPIO_CMD_CHG_DIR_INPUT			DEV_SET_SYSCMD(0x2)	/*!< ctrl command: change gpio direction to input with mask */
#define GPIO_CMD_CHG_DIR_OUTPUT			DEV_SET_SYSCMD(0x3)	/*!< ctrl command: change gpio direction to output with mask */
#define GPIO_CMD_CHG_INTINFO			DEV_SET_SYSCMD(0x4)	/*!< ctrl command: change interrupt type for each bit 	*/
#define GPIO_CMD_DMP_INFO			DEV_SET_SYSCMD(0x5)	/*!< ctrl command: dump gpio current information */
#define GPIO_CMD_INT_BIT_ENABLE			DEV_SET_SYSCMD(0x6)	/*!< ctrl command: enable select bit interrupt */
#define GPIO_CMD_INT_BIT_DISABLE		DEV_SET_SYSCMD(0x7)	/*!< ctrl command: disable select bit interrupt */
#define GPIO_CMD_INT_BIT_REGISTER		DEV_SET_SYSCMD(0x8)	/*!< ctrl command: register interrupt for each bit */
/* @} */

/**
 * \defgroup	DEVICE_HAL_GPIO_GETINFOCMD	GPIO Device Get Info Command
 * \ingroup	DEVICE_HAL_GPIO
 * \brief	definitions for gpio get info command, used in \ref dev_gpio::gpio_get_info
 * @{
 */
/*
 * defines for system command to get gpio info
 * commands need by gpio_get_info::cmd
 */
#define GPIO_CMD_GETINFO_ALL			DEV_SET_SYSCMD(0x0)	/*!< get info command: get all info of gpio */
#define GPIO_CMD_GETINFO_STATE			DEV_SET_SYSCMD(0x1)	/*!< get info command: get current working state(open?, error?, etc) */
#define GPIO_CMD_GETINFO_DIR			DEV_SET_SYSCMD(0x2)	/*!< get direction info */
#define GPIO_CMD_GETINFO_INTBIT_MTHD		DEV_SET_SYSCMD(0x3)	/*!< get int bit enable state */
/* @} */

/**
 * \defgroup	DEVICE_HAL_GPIO_INT_INFO_SET	GPIO Device Int Info Settings
 * \ingroup	DEVICE_HAL_GPIO
 * \brief	definition of gpio interrupt type
 * @{
 */
#define GPIO_INT_ACT_LOW			(0x00)
#define GPIO_INT_ACT_HIGH			(0x01)

#define GPIO_INT_LEVEL_TRIG			(0x00)
#define GPIO_INT_EDGE_TRIG			(0x01)

#define GPIO_INT_NO_DEBOUNCE			(0x00)
#define GPIO_INT_DEBOUNCE			(0x01)

typedef struct dev_gpio_int_info {
	uint32_t int_bit_mask;		/*!< interrupt bit mask */
	uint32_t int_type;		/*!< level sensitive or edge sensitive */
	uint32_t int_level;		/*!< active high or low */
	uint32_t int_edge;		/*!< rising edge or falling edge */
	uint32_t int_debounce;		/*!< enable or disable debounce logic */
} DEV_GPIO_INT_INFO, * DEV_GPIO_INT_INFO_PTR;

typedef void (*DEV_GPIO_HANDLER) (void *ptr);

/** interrupt handler for each port bit */
typedef struct dev_gpio_bit_isr {
	uint32_t int_bit_ofs;			/*!< int bit offset */
   	DEV_GPIO_HANDLER int_bit_handler;	/*!< interrupt handler  */
} DEV_GPIO_BIT_ISR, * DEV_GPIO_BIT_ISR_PTR;
/* @} */

/**
 * \defgroup	DEVICE_HAL_GPIO_DEVSTRUCT	GPIO Device Structure
 * \ingroup	DEVICE_HAL_GPIO
 * \brief	contains definitions of gpio device structure.
 * \details	this structure will be used in user implemented code, which was called
 * 	Device Driver Implement Layer for gpio to realize in user code.
 * @{
 */
/**
 * \brief	gpio information struct definition
 * \details	informations about gpio open state, working state,
 * 	gpio registers, working method, interrupt number
 * \note	Only available for gpio with max 32bits
 */
typedef struct dev_gpio_info {
	void *gpio_regs;	/*!< gpio registers struct */
	void *gpio_ctrl;	/*!< gpio control related */
	uint32_t opn_flg:1;	/*!< indicate gpio open state,
					1: opened, 0: closed */
	uint32_t err_flg:1;	/*!< indicate gpio error state,
					1: error,  0: good */
	uint32_t direction;	/*!< each bit direction of this GPIO */
	uint32_t method;	/*!< int/poll method for each bit of GPIO */
	uint32_t intno;		/*!< interrupt number */
} DEV_GPIO_INFO, * DEV_GPIO_INFO_PTR;

/**
 * \brief	gpio device interface definition
 * \details	define gpio device interface, like gpio information structure,
 * 	fuctions to get gpio info, open/close/control gpio, send/receive data by gpio
 * \note	all this details are implemented by user in user porting code
 */
typedef struct dev_gpio {
	DEV_GPIO_INFO gpio_info;					/*!< gpio device information */
	int32_t (*gpio_get_info) (uint32_t cmd, void *rinfo);		/*!< get gpio information */
	int32_t (*gpio_open) (uint32_t dir, uint32_t method);		/*!< open gpio device(poll/int)	*/
	int32_t (*gpio_close) (void);					/*!< close gpio device */
	int32_t (*gpio_control) (uint32_t ctrl_cmd, void *param);	/*!< control gpio device */
	int32_t (*gpio_write) (uint32_t val, uint32_t mask);		/*!< send data by gpio device */
	int32_t (*gpio_read) (uint32_t *val, uint32_t mask);		/*!< read data from gpio device(blocked) */
} DEV_GPIO, * DEV_GPIO_PTR;

/**
 * \fn	int32_t (* dev_gpio::gpio_get_info) (uint32_t cmd, void *rinfo)
 * \details	get gpio information through different command codes.
 * 	you can pass \ref cmd to this function, and get gpio info you required in \ref rinfo
 * \param[in]	cmd	\ref DEVICE_HAL_GPIO_GETINFOCMD "command code to get gpio information"
 * \param[out]	rinfo	returned gpio information that required by command code
 * \retval	0	success
 * \retval	<0	failed with different error code (<0)
 * \note	need to implemented by user in user code
 */

/**
 * \fn		int32_t (* dev_gpio::gpio_open) (uint32_t dir, uint32_t method)
 * \details	open an gpio device with selected method(interrupt or poll) and
 * 					direction(in or out)  for each bit
 * \param[in]	dir	initial direction(\ref GPIO_DIR_INPUT or \ref GPIO_DIR_OUTPUT) for each bit
 * \param[in]	method	working method (\ref DEV_INTERRUPT_METHOD or \ref DEV_INTERRUPT_METHOD) for each bit
 * \retval	0	success
 * \retval	<0	failed with different error code (<0)
 * \note	need to implemented by user in user code
 */

/**
 * \fn		int32_t (* dev_gpio::gpio_close) (void)
 * \details	close an gpio device
 * \retval	0	success
 * \retval	<0	failed with different error code (<0)
 * \note	need to implemented by user in user code
 */

/**
 * \fn		int32_t (* dev_gpio::gpio_control) (uint32_t ctrl_cmd, void *param)
 * \details	control an gpio device by \ref ctrl_cmd, with passed \ref param.
 * 	you can define you custom command through this, such as
 * 	change working method of each gpio bit, change gpio pin direction for each bit, etc
 * \param[in]		ctrl_cmd	\ref DEVICE_HAL_GPIO_CTRLCMD "control command", to change or get some thing related to gpio
 * \param[in,out]	param		parameters that maybe argument of the command, or return values of the command
 * \retval		0		success
 * \retval		<0		failed with different error code (<0)
 * \note		need to implemented by user in user code
 */

/**
 * \fn		int32_t (* dev_gpio::gpio_write) (uint32_t val, uint32_t mask)
 * \details	write gpio with \ref val and mask some bit in order not to change their value.
 * \param[in]	val	the data that need to write to gpio
 * \param[in]	mask	gpio bit mask
 * \retval	0	gpio was successfully written
 * \retval	<0	failed with different error code (<0)
 * \note	need to implemented by user in user code
 */

/**
 * \fn		int32_t (* dev_gpio::gpio_read) (uint32_t *val, uint32_t mask)
 * \details	receive \ref data of defined \ref len through gpio.
 * \param[out]	val	pointer to data need to read from gpio
 * \param[in]	mask	gpio bit mask
 * \retval	0	gpio value was successfully read
 * \retval	<0	failed with different error code (<0)
 * \note	need to implemented by user in user code
 */

/** @} */

/**
 * \brief	get an \ref dev_gpio "gpio device" by gpio device id.
 * 	For how to use gpio device hal refer to \ref dev_gpio "Functions in gpio device structure"
 * \param[in]	gpio_id	id of gpio, defined by user
 * \retval	!NULL	pointer to an \ref dev_gpio "gpio device structure"
 * \retval	NULL	failed to find the gpio device by \ref gpio_id
 * \note	need to implemented by user in user code
 */
extern DEV_GPIO_PTR gpio_get_dev(int32_t gpio_id);

/** @} */
#endif /* _DEVICE_HAL_GPIO_H_ */
