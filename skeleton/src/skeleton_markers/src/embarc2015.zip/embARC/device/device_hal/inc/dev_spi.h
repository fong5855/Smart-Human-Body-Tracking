/* ------------------------------------------
 * Copyright (c) 2015, Synopsys, Inc. All rights reserved.

 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:

 * 1) Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.

 * 2) Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation and/or
 * other materials provided with the distribution.

 * 3) Neither the name of the Synopsys, Inc., nor the names of its contributors may
 * be used to endorse or promote products derived from this software without
 * specific prior written permission.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * \version 2015.05
 * \date 2014-06-16
 * \author Huaqi Fang(Huaqi.Fang@synopsys.com)
--------------------------------------------- */

/**
 * \defgroup	DEVICE_HAL_SPI	SPI Device HAL Interface
 * \ingroup	DEVICE_HAL_DEF
 * \brief	definitions for spi device hardware layer(\ref dev_spi.h)
 * \details	provide interfaces for spi driver to implement
 *  Here is a diagram for the spi interface.
 *
 *  \htmlonly
 *  <div class="imagebox">
 *      <div style="width: 600px">
 *          <img src="pic/dev_spi_hal.jpg" alt="SPI Device HAL Interface Diagram"/>
 *          <p>SPI Device HAL Interface Diagram</p>
 *      </div>
 *  </div>
 *  \endhtmlonly
 *
 * @{
 *
 * \file
 * \brief	spi device hardware layer definitions
 * \details	provide common definitions for spi device,
 * 	then software developer can develop spi driver
 * 	following this definitions, and the applications
 * 	can directly call this definition to realize fuctions
 */

#ifndef _DEVICE_HAL_SPI_H_
#define _DEVICE_HAL_SPI_H_

#include "dev_common.h"

/**
 * \defgroup	DEVICE_HAL_SPI_CTRLCMD	SPI Device Control Command
 * \ingroup	DEVICE_HAL_SPI
 * \brief	definitions for spi control command, used in \ref dev_spi::spi_control
 * @{
 */
/*
 * defines for system control commands of spi
 * commands need by spi_control::ctrl_cmd
 */
#define SPI_CMD_CHG_FREQ			DEV_SET_SYSCMD(0x0)		/*!< ctrl command: change spi working frequency(Hz) */
#define SPI_CMD_CHG_MTHD			DEV_SET_SYSCMD(0x1)		/*!< ctrl command: change spi working method(interrupt or poll) */
#define SPI_CMD_FLS_OUTP			DEV_SET_SYSCMD(0x2)		/*!< ctrl command: flush spi output */
#define SPI_CMD_DMP_INFO			DEV_SET_SYSCMD(0x3)		/*!< ctrl command: dump spi current information */
#define SPI_CMD_ENA_DEV				DEV_SET_SYSCMD(0x4)		/*!< ctrl command: enable spi device */
#define SPI_CMD_DIS_DEV				DEV_SET_SYSCMD(0x5)		/*!< ctrl command: disbale spi device */
#define SPI_CMD_SEL_DEV				DEV_SET_SYSCMD(0x6)		/*!< ctrl command: select an slave spi device */
#define SPI_CMD_DSEL_DEV			DEV_SET_SYSCMD(0x7)		/*!< ctrl command: deselect an slave spi device */
#define SPI_CMD_CHG_CLKMODE			DEV_SET_SYSCMD(0x8)		/*!< ctrl command: change spi device \ref DEVICE_HAL_SPI_CLK_PHA_POL "serial clock polarity and phase" */
#define SPI_CMD_CHG_DFS				DEV_SET_SYSCMD(0x9)		/*!< ctrl command: change spi device data frame size */
#define SPI_CMD_CHG_MODE			DEV_SET_SYSCMD(0x10)		/*!< ctrl command: change spi working mode, master or slave */
#define SPI_CMD_TRANSFER			DEV_SET_SYSCMD(0x11)		/*!< ctrl command: read and write data */
#define SPI_CMD_SET_DUMMY_BYTE			DEV_SET_SYSCMD(0x12)		/*!< ctrl command: set the dummy byte when transfer */
/** @} */

/**
 * \defgroup	DEVICE_HAL_SPI_GETINFOCMD	SPI Device Get Info Command
 * \ingroup	DEVICE_HAL_SPI
 * \brief	definitions for spi get info command, used in \ref dev_spi::spi_get_info
 * @{
 */
/*
 * defines for system command to get spi info
 * commands need by spi_get_info::cmd
 */
#define SPI_CMD_GETINFO_ALL			DEV_SET_SYSCMD(0x0)		/*!< get info command: get all info of spi */
#define SPI_CMD_GETINFO_FREQ			DEV_SET_SYSCMD(0x1)		/*!< get info commnad: get current working frequence(Hz) */
#define SPI_CMD_GETINFO_STATE			DEV_SET_SYSCMD(0x2)		/*!< get info command: get current working state(open?, error?, etc) */
/** @} */

/**
 * \defgroup	DEVICE_HAL_SPI_CLK_PHA_POL	SPI Clock Phase and Polarity
 * \ingroup	DEVICE_HAL_SPI
 * \brief	marcos to define spi clock PHAse and POLoarity
 * @{
 */
#define SPI_CLK_PHA_OFS				(0)
#define SPI_CLK_PHA_STA				(0x1 <<(SPI_CLK_PHA_OFS))
#define SPI_CLK_PHA_MID				(0x0 <<(SPI_CLK_PHA_OFS))

#define SPI_CLK_POL_OFS				(1)
#define SPI_CLK_POL_HIGH			(0x1 <<(SPI_CLK_POL_OFS))
#define SPI_CLK_POL_LOW				(0x0 <<(SPI_CLK_POL_OFS))

#define SPI_CLK_MODE_0				(SPI_CLK_POL_LOW|SPI_CLK_PHA_MID)
#define SPI_CLK_MODE_1				(SPI_CLK_POL_LOW|SPI_CLK_PHA_STA)
#define SPI_CLK_MODE_2				(SPI_CLK_POL_HIGH|SPI_CLK_PHA_MID)
#define SPI_CLK_MODE_3				(SPI_CLK_POL_HIGH|SPI_CLK_PHA_STA)
/** @} */

/**
 * \defgroup	DEVICE_HAL_SPI_DEVSTRUCT	SPI Device Structure
 * \ingroup	DEVICE_HAL_SPI
 * \brief	contains definitions of spi device structure.
 * \details	this structure will be used in user implemented code, which was called
 * 	Device Driver Implement Layer for spi to realize in user code.
 * @{
 */
/**
 * \brief	spi information struct definition
 * \details	informations about spi open state, working state,
 * 	frequence, spi registers, working method, interrupt number
 */
typedef struct dev_spi_info {
	void *spi_regs;		/*!< spi registers struct */
	void *spi_ctrl;		/*!< spi control related */
	uint32_t opn_flg:1;	/*!< indicate spi open state, 1: opened, 0: closed */
	uint32_t err_flg:1;	/*!< indicate spi error state, 1: error, 0: good */
	uint32_t freq;		/*!< spi working frequence */
	uint32_t mode;		/*!< spi working mode (master/slave) */
	uint32_t clock_mode;	/*!< spi clock phase and polarity
					bit 0 is clock phase,
					bit 1 is clock polarity */
	uint32_t method;	/*!< int/poll method */
	uint32_t intno;		/*!< interrupt number */
	uint32_t fifo_len;	/*!< Fifo length */
	uint8_t dummy_wr_byte;	/*!< dummy write byte when send and receive */
} DEV_SPI_INFO, * DEV_SPI_INFO_PTR;

typedef struct dev_spi_transfer DEV_SPI_TRANSFER, *DEV_SPI_TRANSFER_PTR;
/**
 * \brief	spi read and write data structure used by \ref SPI_CMD_TRANSFER
 * 	spi write then read data
 */
struct dev_spi_transfer {
	DEV_SPI_TRANSFER *next;
	void *snd_buf;		/*!< spi send buffer */
	void *rcv_buf;		/*!< spi receive buffer */
	uint32_t snd_cnt;	/*!< spi send count */
	uint32_t rcv_cnt;	/*!< spi receive count */
	uint32_t rcv_ofs;	/*!< spi receive offset */
	uint32_t xfer_cnt;	/*!< spi transfer_cnt */
} ;

/**
 * \brief	spi device interface definition
 * \details	define spi device interface, like spi information structure,
 * 	fuctions to get spi info, open/close/control spi, send/receive data by spi
 * \note	all this details are implemented by user in user porting code
 */
typedef struct dev_spi {
	DEV_SPI_INFO spi_info;							/*!< spi device information */
	int32_t (*spi_get_info) (uint32_t cmd, void *rinfo);			/*!< get spi information */
	int32_t (*spi_open) (uint32_t freq, uint32_t mode, uint32_t method);	/*!< open spi device(poll/int, master/slave) with freq */
	int32_t (*spi_close) (void);						/*!< close spi device */
	int32_t (*spi_control) (uint32_t ctrl_cmd, void *param);		/*!< control spi device */
	int32_t (*spi_write) (const void *data, uint32_t len);			/*!< send data by spi device */
	int32_t (*spi_read) (void *data, uint32_t len);				/*!< read data from spi device(blocked) */
} DEV_SPI, * DEV_SPI_PTR;

/**
 * \fn		int32_t (* dev_spi::spi_get_info) (uint32_t cmd, void *rinfo)
 * \details	get spi information through different command codes.
 * 	you can pass \ref cmd to this function, and get spi info you required in \ref rinfo
 * \param[in]	cmd	\ref DEVICE_HAL_SPI_GETINFOCMD "command code to get spi information"
 * \param[out]	rinfo	returned spi information that required by command code
 * \retval	0	success
 * \retval	<0	failed with different error code (<0)
 * \note	need to implemented by user in user code
 */

/**
 * \fn		int32_t (* dev_spi::spi_open) (uint32_t freq, uint32_t mode, uint32_t method)
 * \details	open an spi device with selected method (interrupt or poll) with defined frequence,
 * 	working in master or slave mode
 * \param[in]	freq	initial frequence of spi
 * \param[in]	mode	working mode (\ref DEV_MASTER_MODE "master" or \ref DEV_SLAVE_MODE "slave")
 * \param[in]	method	\ref DEV_INTERRUPT_METHOD or \ref DEV_INTERRUPT_METHOD
 * \retval	0	success
 * \retval	<0	failed with different error code (<0)
 * \note	need to implemented by user in user code
 */

/**
 * \fn		int32_t (* dev_spi::spi_close) (void)
 * \details	close an spi device
 * \retval	0	success
 * \retval	<0	failed with different error code (<0)
 * \note	need to implemented by user in user code
 */

/**
 * \fn		int32_t (* dev_spi::spi_control) (uint32_t ctrl_cmd, void *param)
 * \details	control an spi device by \ref ctrl_cmd, with passed \ref param.
 * 	you can define you custom command through this, such as
 * 	change frequence, change working method, flush output, etc
 * \param[in]		ctrl_cmd	\ref DEVICE_HAL_SPI_CTRLCMD "control command", to change or get some thing related to spi
 * \param[in,out]	param		parameters that maybe argument of the command, or return values of the command
 * \retval		0		success
 * \retval		<0		failed with different error code (<0)
 * \note		need to implemented by user in user code
 */

/**
 * \fn		int32_t (* dev_spi::spi_write) (const void *data, uint32_t len)
 * \details	send \ref data through spi with defined \ref len.
 * \param[in]	data	pointer to data need to send by spi
 * \param[in]	len	length of data to be sent
 * \retval	>=0	byte count that was successfully sent
 * \retval	<0	failed with different error code (<0)
 * \note	need to implemented by user in user code
 */

/**
 * \fn		int32_t (* dev_spi::spi_read) (void *data, uint32_t len)
 * \details	receive \ref data of defined \ref len through spi.
 * \param[out]	data	pointer to data need to received by spi
 * \param[in]	len	length of data to be received
 * \retval	>=0	byte count that was successfully received
 * \retval	<0	failed with different error code (<0)
 * \note	need to implemented by user in user code
 */

/** @} */

/**
 * \brief	get an \ref dev_spi "spi device" by spi device id.
 * 	For how to use spi device hal refer to \ref dev_spi "Functions in spi device structure"
 * \param[in]	spi_id	id of spi, defined by user
 * \retval	!NULL	pointer to an \ref dev_spi "spi device structure"
 * \retval	NULL	failed to find the spi device by \ref spi_id
 * \note	need to implemented by user in user code
 */
extern DEV_SPI_PTR spi_get_dev(int32_t spi_id);

/** @} */
#endif /* _DEVICE_HAL_SPI_H_ */
