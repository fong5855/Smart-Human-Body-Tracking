/* ------------------------------------------
 * Copyright (c) 2015, Synopsys, Inc. All rights reserved.

 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:

 * 1) Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.

 * 2) Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation and/or
 * other materials provided with the distribution.

 * 3) Neither the name of the Synopsys, Inc., nor the names of its contributors may
 * be used to endorse or promote products derived from this software without
 * specific prior written permission.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * \version 2015.05
 * \date 2014-06-16
 * \author Huaqi Fang(Huaqi.Fang@synopsys.com)
--------------------------------------------- */

/**
 * \defgroup	DEVICE_HAL_UART		UART Device HAL Interface
 * \ingroup	DEVICE_HAL_DEF
 * \brief	definitions for uart device hardware layer(\ref dev_uart.h)
 * \details	provide interfaces for uart driver to implement.
 *  Here is a diagram for the uart interface.
 *
 *  \htmlonly
 *  <div class="imagebox">
 *      <div style="width: 600px">
 *          <img src="pic/dev_uart_hal.jpg" alt="UART Device HAL Interface Diagram"/>
 *          <p>UART Device HAL Interface Diagram</p>
 *      </div>
 *  </div>
 *  \endhtmlonly
 *
 * @{
 *
 * \file
 * \brief	uart device hardware layer definitions
 * \details	provide common definitions for uart device,
 * 	then software developer can develop uart driver
 * 	following this definitions, and the applications
 * 	can directly call this definition to realize fuctions
 *
 */

#ifndef _DEVICE_HAL_UART_H_
#define _DEVICE_HAL_UART_H_

#include "dev_common.h"

/**
 * \defgroup	DEVICE_HAL_UART_BAUD	UART Device Baudrate Definitions
 * \ingroup	DEVICE_HAL_UART
 * \brief	macros for uart baudrate.
 * \details	definitions for baudrate from 4800 to 115200bps.
 * @{
 */
/*
 * defines for uart baudrates
 */
#define UART_BAUDRATE_4800			(4800)		/*!< uart baudrate 4800bps */
#define UART_BAUDRATE_9600			(9600)		/*!< uart baudrate 9600bps */
#define UART_BAUDRATE_14400			(14400)		/*!< uart baudrate 14400bps */
#define UART_BAUDRATE_19200			(19200)		/*!< uart baudrate 19200bps */
#define UART_BAUDRATE_38400			(38400)		/*!< uart baudrate 38400bps */
#define UART_BAUDRATE_57600			(57600)		/*!< uart baudrate 57600bps */
#define UART_BAUDRATE_115200			(115200)	/*!< uart baudrate 115200bps */
/** @} */

/**
 * \defgroup	DEVICE_HAL_UART_IOCTL	UART Device IO Control Settings
 * \ingroup	DEVICE_HAL_UART
 * \brief	macros for uart io ctrl.
 * \details	definitions for how to control the send & receive behavior
 * @{
 */
#define UART_IOCTL_NULL				(0U)		/*!< NULL */
#define UART_IOCTL_ECHO				(0x0001U)	/*!< enable echo back */
#define UART_IOCTL_CRLF				(0x0010U)	/*!< add CR before LF */
#define UART_IOCTL_FCSND			(0x0100U)	/*!< enable send flow control */
#define UART_IOCTL_FCANY			(0x0200U)	/*!< restart to send whatever char is received */
#define UART_IOCTL_FCRCV			(0x0400U)	/*!< enable receive flow control */
/** @} */

/**
 * \defgroup	DEVICE_HAL_UART_CTRLCMD		UART Device Control Command
 * \ingroup	DEVICE_HAL_UART
 * \brief	definitions for uart control command, used in \ref dev_uart::uart_control
 * \details	these commands defined here can be used in user code directly.
 * @{
 */
/*
 * defines for system control commands of uart
 * commands need by uart_control::ctrl_cmd
 */
#define UART_CMD_CHG_BAUD			DEV_SET_SYSCMD(0x0)	/*!< ctrl command: change uart baudrate */
#define UART_CMD_CHG_MTHD			DEV_SET_SYSCMD(0x1)	/*!< ctrl command: change uart working method(interrupt or poll) */
#define UART_CMD_FLS_OUTP			DEV_SET_SYSCMD(0x2)	/*!< ctrl command: flush uart output */
#define UART_CMD_DMP_INFO			DEV_SET_SYSCMD(0x3)	/*!< ctrl command: dump uart current information */
#define UART_CMD_CHG_IOCTL			DEV_SET_SYSCMD(0x4)	/*!< ctrl command: change uart \ref DEVICE_HAL_UART_IOCTL "send and receive settings" */
#define UART_CMD_SET_READ_MODE			DEV_SET_SYSCMD(0x5)	/*!< ctrl command: set uart read mode, default zero for block read, non-zero for non-block read */
/** @} */

/**
 * \defgroup	DEVICE_HAL_UART_GETINFOCMD	UART Device Get Info Command
 * \ingroup	DEVICE_HAL_UART
 * \brief	definitions for uart get info command, used in \ref dev_uart::uart_get_info
 * \details	these commands defined here can be used in user code directly.
 * @{
 */
/*
 * defines for system command to get uart info
 * commands need by uart_get_info::cmd
 */
#define UART_CMD_GETINFO_ALL			DEV_SET_SYSCMD(0x0)	/*!< get info command: get all info of uart */
#define UART_CMD_GETINFO_BAUD			DEV_SET_SYSCMD(0x1)	/*!< get info commnad: get current working baudrate */
#define UART_CMD_GETINFO_STATE			DEV_SET_SYSCMD(0x2)	/*!< get info command: get current working state(open?, error?, etc) */
/** @} */

/**
 * \defgroup	DEVICE_HAL_UART_DEVSTRUCT	UART Device Structure
 * \ingroup	DEVICE_HAL_UART
 * \brief	contains definitions of uart device structure.
 * \details	this structure will be used in user implemented code, which was called
 * 	Device Driver Implement Layer for uart to realize in user code.
 * @{
 */
/**
 * \brief	uart information struct definition
 * \details	informations about uart open state, working state,
 * 	baurate, uart registers, working method, interrupt number
 */
typedef struct dev_uart_info {
	void *uart_regs;	/*!< uart registers struct */
	void *uart_ctrl;	/*!< uart control related */
	uint32_t opn_flg:1;	/*!< indicate uart open state, 1: opened, 0: closed */
	uint32_t err_flg:1;	/*!< indicate uart error state 1: error,  0: good */
	uint32_t baudrate;	/*!< uart baud rate */
	uint32_t method;	/*!< int/poll method */
	uint32_t intno;		/*!< interrupt number */
	uint32_t ioctl;		/*!< uart io control */
	uint32_t read_mode;	/*!< uart read mode(block or non-block) */
} DEV_UART_INFO, * DEV_UART_INFO_PTR;


/**
 * \brief	uart device interface definition
 * \details	define uart device interface, like uart information structure,
 * 	functions to get uart info, open/close/control uart, send/receive data by uart
 * \note	all this details are implemented by user in user porting code
 */
typedef struct dev_uart {
	DEV_UART_INFO uart_info;				/*!< uart device information */
	int32_t (*uart_get_info) (uint32_t cmd, void *rinfo);	/*!< get uart information */
	int32_t (*uart_open) (uint32_t baud, uint32_t method);	/*!< open uart device(poll/int) */
	int32_t (*uart_close) (void);				/*!< close uart device */
	int32_t (*uart_control) (uint32_t ctrl_cmd, void *param);	/*!< control uart device */
	int32_t (*uart_write) (const void *data, uint32_t len);	/*!< send data by uart device */
	int32_t (*uart_read) (void *data, uint32_t len);	/*!< read data from uart device(blocked) */
} DEV_UART, * DEV_UART_PTR;

/**
 * \fn		int32_t (* dev_uart::uart_get_info) (uint32_t cmd, void *rinfo)
 * \details	get uart information through different command codes.
 * 	you can pass \ref cmd to this function, and get uart info you required in \ref rinfo
 * \param[in]	cmd	\ref DEVICE_HAL_UART_GETINFOCMD "command code to get uart information"
 * \param[out]	rinfo	returned uart information that required by command code
 * \retval	0	success
 * \retval	<0	failed with different error code (<0)
 * \note	need to implemented by user in user code
 */

/**
 * \fn		int32_t (* dev_uart::uart_open) (uint32_t baud, uint32_t method)
 * \details	open an uart device with selected method (interrupt or poll) with defined baudrate
 * \param[in]	baud	\ref DEVICE_HAL_UART_BAUD "initial baudrate of uart"
 * \param[in]	method	\ref DEV_INTERRUPT_METHOD or \ref DEV_INTERRUPT_METHOD
 * \retval	0	success
 * \retval	<0	failed with different error code (<0)
 * \note	need to implemented by user in user code
 */

/**
 * \fn		int32_t (* dev_uart::uart_close) (void)
 * \details	close an uart device
 * \retval	0	success
 * \retval	<0	failed with different error code (<0)
 * \note	need to implemented by user in user code
 */

/**
 * \fn		int32_t (* dev_uart::uart_control) (uint32_t ctrl_cmd, void *param)
 * \details	control an uart device by \ref ctrl_cmd, with passed \ref param.
 * 	you can define you custom command through this, such as
 * 	change baudrate, change working method, flush output, etc
 * \param[in]		ctrl_cmd	\ref DEVICE_HAL_UART_CTRLCMD "control command", to change or get some thing related to uart
 * \param[in,out]	param		parameters that maybe argument of the command, or return values of the command
 * \retval		0		success
 * \retval		<0		failed with different error code (<0)
 * \note		need to implemented by user in user code
 */

/**
 * \fn		int32_t (* dev_uart::uart_write) (const void *data, uint32_t len)
 * \details	send \ref data through uart with defined \ref len.
 * \param[in]	data	pointer to data need to send by uart
 * \param[in]	len	length of data to be sent
 * \retval	>=0	byte count that was successfully sent
 * \retval	<0	failed with different error code (<0)
 * \note	need to implemented by user in user code
 */

/**
 * \fn		int32_t (* dev_uart::uart_read) (void *data, uint32_t len)
 * \details	receive \ref data of defined \ref len through uart.
 * \param[out]	data	pointer to data need to received by uart
 * \param[in]	len	length of data to be received
 * \retval	>=0	byte count that was successfully received
 * \retval	<0	failed with different error code (<0)
 * \note	need to implemented by user in user code
 */
/** @} */

/**
 * \brief	get an \ref dev_uart "uart device" by uart device id.
 * 	For how to use uart device hal refer to \ref dev_uart "Functions in uart device structure"
 * \param[in]	uart_id		id of uart, defined by user
 * \retval	!NULL		pointer to an \ref dev_uart "uart device structure"
 * \retval	NULL		failed to find the uart device by \ref uart_id
 * \note	need to implemented by user in user code
 */
extern DEV_UART_PTR uart_get_dev(int32_t uart_id);

/** @} */
#endif /* _DEVICE_HAL_UART_H_ */
