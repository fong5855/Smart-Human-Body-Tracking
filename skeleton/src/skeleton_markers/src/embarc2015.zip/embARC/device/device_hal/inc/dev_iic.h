/* ------------------------------------------
 * Copyright (c) 2015, Synopsys, Inc. All rights reserved.

 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:

 * 1) Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.

 * 2) Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation and/or
 * other materials provided with the distribution.

 * 3) Neither the name of the Synopsys, Inc., nor the names of its contributors may
 * be used to endorse or promote products derived from this software without
 * specific prior written permission.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * \version 2015.05
 * \date 2014-06-16
 * \author Huaqi Fang(Huaqi.Fang@synopsys.com)
--------------------------------------------- */

/**
 * \defgroup	DEVICE_HAL_IIC	IIC Device HAL Interface
 * \ingroup	DEVICE_HAL_DEF
 * \brief	definitions for iic device hardware layer(\ref dev_iic.h)
 * \details	provide interfaces for iic driver to implement
 *  Here is a diagram for the iic interface.
 *
 *  \htmlonly
 *  <div class="imagebox">
 *      <div style="width: 600px">
 *          <img src="pic/dev_iic_hal.jpg" alt="IIC Device HAL Interface Diagram"/>
 *          <p>IIC Device HAL Interface Diagram</p>
 *      </div>
 *  </div>
 *  \endhtmlonly
 *
 * @{
 *
 * \file
 * \brief	iic device hardware layer definitions
 * \details	provide common definitions for iic device,
 * 	then software developer can develop iic driver
 * 	following this definitions, and the applications
 * 	can directly call this definition to realize fuctions
 */

#ifndef _DEVICE_HAL_IIC_H_
#define _DEVICE_HAL_IIC_H_

#include "dev_common.h"

/**
 * \defgroup	DEVICE_HAL_IIC_SPEED	IIC Speed Definition
 * \ingroup	DEVICE_HAL_IIC
 * \brief	Define macros to indicate different iic speed.
 * \details	Here provide three different speed macro, from standard, fast to high
 * @{
 */
/*
 * defines for iic baudrates
 */
#define IIC_SPEED_STANDARD		(0x1)		/*!< iic speed : standard mode(0-100kbits/s) */
#define IIC_SPEED_FAST			(0x2)		/*!< iic speed : fast mode(100-400kbits/s) */
#define IIC_SPEED_HIGH			(0x3)		/*!< iic speed : high mode(<=3.14Mbits/s) */
/** @} */


/**
 * \defgroup	DEVICE_HAL_IIC_CTRLCMD	IIC Device Control Command
 * \ingroup	DEVICE_HAL_IIC
 * \brief	definitions for iic control command, used in \ref dev_iic::iic_control
 * @{
 */
/*
 * defines for system control commands of iic
 * commands need by iic_control::ctrl_cmd
 */
#define IIC_CMD_CHG_SPEED		DEV_SET_SYSCMD(0x0)	/*!< ctrl command: change iic speed */
#define IIC_CMD_CHG_MTHD		DEV_SET_SYSCMD(0x1)	/*!< ctrl command: change iic working method(interrupt or poll) */
#define IIC_CMD_FLS_OUTP		DEV_SET_SYSCMD(0x2)	/*!< ctrl command: flush iic output */
#define IIC_CMD_DMP_INFO		DEV_SET_SYSCMD(0x3)	/*!< ctrl command: dump iic current information */
#define IIC_CMD_CHG_MODE		DEV_SET_SYSCMD(0x4)	/*!< ctrl command: change iic working mode, master or slave */
#define IIC_CMD_SET_TARADDR		DEV_SET_SYSCMD(0x5)	/*!< ctrl command: change iic selected target slave address */
#define IIC_CMD_SET_SLVADDR		DEV_SET_SYSCMD(0x6)	/*!< ctrl command: change iic slave address when working as slave device */
#define IIC_CMD_SET_WRITEMODE		DEV_SET_SYSCMD(0x7)	/*!< ctrl command: call before write to set the write end mode, STOP or RESTART for read */
/** @} */

/**
 * \defgroup	DEVICE_HAL_IIC_GETINFOCMD	IIC Device Get Info Command
 * \ingroup	DEVICE_HAL_IIC
 * \brief	definitions for iic get info command, used in \ref dev_iic::iic_get_info
 * @{
 */
/*
 * defines for system command to get iic info
 * commands need by iic_get_info::cmd
 */
#define IIC_CMD_GETINFO_ALL		DEV_SET_SYSCMD(0x0)	/*!< get info command: get all info of iic */
#define IIC_CMD_GETINFO_SPEED		DEV_SET_SYSCMD(0x1)	/*!< get info commnad: get current working speed */
#define IIC_CMD_GETINFO_STATE		DEV_SET_SYSCMD(0x2)	/*!< get info command: get current working state(open:bit 0, error:bit 1, etc) */
/** @} */

/**
 * \defgroup	DEVICE_HAL_IIC_WRITEMODE	IIC SET WRITE MODE
 * \ingroup	DEVICE_HAL_IIC_CTRLCMD
 * \brief	definitions for iic write mode
 * \details
 * 	this is used before write data, it will control next mode to be write or read
 * 	if next mode is write : then set to be STOP
 * 	if next mode is read : then set to be RESTART
 * @{
 */
#define IIC_WRITE_MODE_STOP		(0)
#define IIC_WRITE_MODE_RESTART		(1)
/** @} */

/**
 * \defgroup	DEVICE_HAL_IIC_DEVSTRUCT	IIC Device Structure
 * \ingroup	DEVICE_HAL_IIC
 * \brief	contains definitions of iic device structure.
 * \details	this structure will be used in user implemented code, which was called
 *     Device Driver Implement Layer for iic to realize in user code.
 * @{
 */
/**
 * \brief	iic information struct definition
 * \details	informations about iic open state, working state,
 * 	baurate, iic registers, working method, interrupt number
 */
typedef struct dev_iic_info {
	void *iic_regs;			/*!< iic registers struct */
	void *iic_ctrl;			/*!< iic control related */
	uint32_t opn_flg:1;		/*!< indicate iic open state.
						1: opened, 0: closed */
	uint32_t err_flg:1;		/*!< indicate iic error state.
						1: error,  0: good */
	uint32_t speed;			/*!< iic speed */
	uint32_t mode;			/*!< iic working mode(master/slave) */
	uint32_t slv_addr;		/*!< slave address when working as slave iic device */
	uint32_t tar_addr;		/*!< selected slave target address */
	uint32_t method;		/*!< int/poll method */
	uint32_t intno;			/*!< interrupt number */
} DEV_IIC_INFO, * DEV_IIC_INFO_PTR;


/**
 * \brief	iic device interface definition
 * \details	define iic device interface, like iic information structure,
 * 	fuctions to get iic info, open/close/control iic, send/receive data by iic
 * \note	all this details are implemented by user in user porting code
 */
typedef struct dev_iic {
	DEV_IIC_INFO iic_info;					/*!< iic device information */
	int32_t (*iic_get_info) (uint32_t cmd, void *rinfo);	/*!< get iic information */
	int32_t (*iic_open) (uint32_t speed, uint32_t mode, uint32_t method);	/*!< open iic device(poll/int, master/slave) with speed */
	int32_t (*iic_close) (void);				/*!< close iic device */
	int32_t (*iic_control) (uint32_t ctrl_cmd, void *param);/*!< control iic device */
	int32_t (*iic_write) (const void *data, uint32_t len);	/*!< send data by iic device */
	int32_t (*iic_read) (void *data, uint32_t len);		/*!< read data from iic device(blocked) */
} DEV_IIC, * DEV_IIC_PTR;

/**
 * \fn		int32_t (* dev_iic::iic_get_info) (uint32_t cmd, void *rinfo)
 * \details	get iic information through different command codes.
 * 	you can pass \ref cmd to this function, and get iic info you required in \ref rinfo
 * \param[in]	cmd	\ref DEVICE_HAL_IIC_GETINFOCMD "command code to get iic information"
 * \param[out]	rinfo	returned iic information that required by command code, must not be NULL
 * \retval	0	success
 * \retval	<0	failed with different error code (<0)
 * \note	need to implemented by user in user code
 */

/**
 * \fn		int32_t (* dev_iic::iic_open) (uint32_t speed, uint32_t mode, uint32_t method)
 * \details	open an iic device with selected method (interrupt or poll) with defined \ref speed mode,
 * 	working in master or slave mode
 * \param[in]	speed	\ref DEVICE_HAL_IIC_SPEED "initial speed of iic"
 * \param[in]	mode	working mode (\ref DEV_MASTER_MODE "master" or \ref DEV_SLAVE_MODE "slave")
 * \param[in]	method	\ref DEV_INTERRUPT_METHOD or \ref DEV_INTERRUPT_METHOD
 * \retval	0	success
 * \retval	<0	failed with different error code (<0)
 * \note	need to implemented by user in user code
 */

/**
 * \fn		int32_t (* dev_iic::iic_close) (void)
 * \details	close an iic device
 * \retval	0	success
 * \retval	<0	failed with different error code (<0)
 * \note	need to implemented by user in user code
 */

/**
 * \fn		int32_t (* dev_iic::iic_control) (uint32_t ctrl_cmd, void *param)
 * \details	control an iic device by \ref ctrl_cmd, with passed \ref param.
 * 	you can define you custom command through this, such as
 * 	change baudrate, change working method, flush output, etc
 * \param[in]		ctrl_cmd	\ref DEVICE_HAL_IIC_CTRLCMD "control command", to change or get some thing related to iic
 * \param[in,out]	param		parameters that maybe argument of the command,
 * 					or return values of the command, must not be NULL
 * \retval	0	success
 * \retval	<0	failed with different error code (<0)
 * \note	need to implemented by user in user code
 */

/**
 * \fn		int32_t (* dev_iic::iic_write) (const void *data, uint32_t len)
 * \details	send \ref data through iic with defined \ref len to slave device which slave address is \ref slv_addr.
 * \param[in]	data	pointer to data need to send by iic
 * \param[in]	len	length of data to be sent
 * \retval	>=0	byte count that was successfully sent
 * \retval	<0	failed with different error code (<0)
 * \note	need to implemented by user in user code
 */

/**
 * \fn		int32_t (* dev_iic::iic_read) (void *data, uint32_t len)
 * \details	receive \ref data of defined \ref len through iic from slave device which slave address is \ref slv_addr.
 * \param[out]	data	pointer to data need to received by iic
 * \param[in]	len	length of data to be received
 * \retval	>=0	byte count that was successfully received
 * \retval	<0	failed with different error code (<0)
 * \note	need to implemented by user in user code
 */
/** @} */

/**
 * \brief	get an \ref dev_iic "iic device" by iic device id.
 * 	For how to use iic device hal refer to \ref dev_iic "Functions in iic device structure"
 * \param[in]	iic_id	id of iic, defined by user
 * \retval	!NULL	pointer to an \ref dev_iic "iic device structure"
 * \retval	NULL	failed to find the iic device by \ref iic_id
 * \note	need to implemented by user in user code
 */
extern DEV_IIC_PTR iic_get_dev(int32_t iic_id);

/** @} */
#endif /* _DEVICE_HAL_IIC_H_ */
