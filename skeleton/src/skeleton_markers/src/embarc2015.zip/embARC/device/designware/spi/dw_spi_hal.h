/* ------------------------------------------
 * Copyright (c) 2015, Synopsys, Inc. All rights reserved.

 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:

 * 1) Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.

 * 2) Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation and/or
 * other materials provided with the distribution.

 * 3) Neither the name of the Synopsys, Inc., nor the names of its contributors may
 * be used to endorse or promote products derived from this software without
 * specific prior written permission.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * \version 2015.05
 * \date 2014-06-25
 * \author Huaqi Fang(Huaqi.Fang@synopsys.com)
--------------------------------------------- */

/**
 * \file
 * \ingroup	DEVICE_DW_SPI
 * \brief	DesignWare SPI driver hardware description related header file
 * \details	detailed hardware related definitions of DesignWare SPI driver
 */

#ifndef _DEVICE_DW_SPI_HAL_H_
#define _DEVICE_DW_SPI_HAL_H_

/* DW APB SPI bit definitions */

/**
 * \name	DesignWare SPI HAL CTRL0 Macros
 * \brief	DesignWare SPI hal ctrl0 macros,
 * 	include dfs, scph, scppl, tmod, etc
 * @{
 */
/* Data Frame Size Macros */
#define DW_SPI_CTRLR0_DFS_4			(0x3)
#define DW_SPI_CTRLR0_DFS_5			(0x4)
#define DW_SPI_CTRLR0_DFS_6			(0x5)
#define DW_SPI_CTRLR0_DFS_7			(0x6)
#define DW_SPI_CTRLR0_DFS_8			(0x7)
#define DW_SPI_CTRLR0_DFS_9			(0x8)
#define DW_SPI_CTRLR0_DFS_10			(0x9)
#define DW_SPI_CTRLR0_DFS_11			(0xA)
#define DW_SPI_CTRLR0_DFS_12			(0xB)
#define DW_SPI_CTRLR0_DFS_13			(0xC)
#define DW_SPI_CTRLR0_DFS_14			(0xD)
#define DW_SPI_CTRLR0_DFS_15			(0xE)
#define DW_SPI_CTRLR0_DFS_16			(0xF)

#define DW_SPI_CTRLR0_DFS_MASK_SET		(0xfff0)
#define DW_SPI_CTRLR0_DFS_MASK_CLEAR		(0xf)

#define DW_SPI_CTRLR0_TMOD_MASK_SET		(0xFCFF)
#define DW_SPI_CTRLR0_FRF_MOTOROLA		(0x0)
#define DW_SPI_CTRLR0_FRF_TI			(0x10)
#define DW_SPI_CTRLR0_FRF_MICROWIRE		(0x20)
#define DW_SPI_CTRLR0_SCPH_HIGH			(0x40)
#define DW_SPI_CTRLR0_SCPH_LOW			(0)
#define DW_SPI_CTRLR0_SCPOL_HIGH		(0x80)
#define DW_SPI_CTRLR0_SCPOL_LOW			(0)
#define DW_SPI_CTRLR0_SC_OFS			(6)
#define DW_SPI_CTRLR0_TMOD_MASK			((0x100) | (CTRLR0_SCPOL_HIGH))
/** @} */

/**
 * \name	DesignWare SPI HAL ISR Flags
 * \brief	DesignWare SPI hal Interrupt Status Flags
 * @{
 */
#define DW_SPI_TX_OVERFLOW_ERROR		(0X2)
#define DW_SPI_RX_UNDERFLOW_ERROR		(0X4)
#define DW_SPI_RX_OVERFLOW_ERROR		(0X8)

#define DW_SPI_ISR_RX_FIFO_INT_MASK		(0X10)
#define DW_SPI_ISR_TX_FIFO_INT_MASK		(0X1)
#define DW_SPI_ISR_TX_OVERFLOW_INT_MASK		(0X2)
#define DW_SPI_ISR_RX_UNDERFLOW_INT_MASK	(0X4)
#define DW_SPI_ISR_RX_OVERFLOW_INT_MASK		(0X8)
/** @} */

/**
 * \name	DesignWare SPI HAL SR Flags
 * \brief	DesignWare SPI hal Status Flags
 * @{
 */
#define DW_SPI_SLV_TX_ERROR			(0X20)
#define DW_SPI_SSI_SR_TXE			(0x20)
#define DW_SPI_SSI_SR_RFF			(0x10)
#define DW_SPI_SSI_SR_RFNE			(0x8)
#define DW_SPI_SSI_SR_TFE			(0x4)
#define DW_SPI_SSI_SR_TFNF			(0x2)
#define DW_SPI_SSI_SR_BUSY			(0x1)
/** @} */

/**
 * \name	DesignWare SPI HAL Transmit Mode Macros
 * \brief	DesignWare SPI hal transmit mode macros
 * @{
 */
#define DW_SPI_SPI_TRANSMIT_RECEIVE_MODE	(0x0)
#define DW_SPI_SPI_TRANSMIT_ONLY_MODE		(0x1)
#define DW_SPI_SPI_RECEIVE_ONLY_MODE		(0x2)
#define DW_SPI_SPI_EEPROM_READ_ONLY_MODE	(0x3)
#define DW_SPI_SPI_TRANS_MODE_OFS		(8)
/** @} */

/**
 * \name	DesignWare SPI HAL SSI Enable Macros
 * \brief	DesignWare SPI hal ssi enable macros
 * @{
 */
/* Macros */
#define DW_SPI_SSI_ENABLE			(1)	/*!< SSI Enable */
#define DW_SPI_SSI_DISABLE			(0)	/*!< SSI Disable */
/** @} */

/**
 * \name	DesignWare SPI HAL IMR Macros
 * \brief	DesignWare SPI hal interrupt mask macros
 * @{
 */
#define DW_SPI_IMR_ENABLE_RX_INT		(0x1C)
#define DW_SPI_IMR_ENABLE_TX_INT		(0x3)
#define DW_SPI_SSI_ENABLE_INT			(0x1f)
#define DW_SPI_SSI_DISABLE_INT			(0x0)
/** @} */

#define DW_SPI_SSI_IDLE				(1)
#define DW_SPI_SPI_TRANSMIT			(1)
#define DW_SPI_SPI_RECEIVE			(2)
#define DW_SPI_SSI_MASTER			(1)
#define DW_SPI_SSI_SLAVE			(0)

#define DW_SPI_MAX_FIFO_LENGTH			(256)
#define DW_SPI_MIN_FIFO_LENGTH			(2)

#endif /* _DEVICE_DW_SPI_HAL_H_ */