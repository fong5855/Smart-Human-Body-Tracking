/* ------------------------------------------
 * Copyright (c) 2015, Synopsys, Inc. All rights reserved.

 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:

 * 1) Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.

 * 2) Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation and/or
 * other materials provided with the distribution.

 * 3) Neither the name of the Synopsys, Inc., nor the names of its contributors may
 * be used to endorse or promote products derived from this software without
 * specific prior written permission.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * \version 2015.05
 * \date 2014-06-30
 * \author Huaqi Fang(Huaqi.Fang@synopsys.com)
--------------------------------------------- */

/**
 * \file
 * \ingroup	DEVICE_DW_IIC
 * \brief	DesignWare IIC driver hardware description related header file
 * \details	detailed hardware related definitions of DesignWare IIC driver
 */

#ifndef _DEVICE_DW_IIC_HAL_H_
#define _DEVICE_DW_IIC_HAL_H_

#include "dw_iic_hal_cfg.h"

/* DW APB IIC bit definitions */

/* Data Frame Size Macros */
#define DW_IC_SS_SCL_HIGH_COUNT		(0x0190)
#define DW_IC_SS_SCL_LOW_COUNT		(0x01d6)
#define DW_IC_FS_SCL_HIGH_COUNT		(0x003c)
#define DW_IC_FS_SCL_LOW_COUNT		(0x0082)

#define ENABLE_I2C			(1)
#define DISABLE_I2C			(0)

#define I2C_INT_DSB			(0x0) /*!< disable all iic interrupt */

#define ENB_MASTER_MODE			((1<<6)|(1))
#define XMT_DMA_ENB			(0x02)
#define RCV_DMA_ENB			(1)
#define DW_I2C_STOP_CMD			(0x200)
#define DW_I2C_READ_CMD			(0x100)

#define DW_I2C_RESTART_BIT		(1<<10)
#define DW_I2C_STOP_BIT			(1<<9)


/* DW_APB I2C IP Config Dependencies. */
#if DW_I2C_ALLOW_RESTART
#define IC_RESTART_EN		(1 << 5)
#else
#define IC_RESTART_EN		(0x00)
#endif

#if DW_I2C_MST_10_BIT_ADDR_SUPPORT
#define MST_10_BIT_ADDR_MODE	(1 << 4)
#define IC_10BITADDR_MASTER	(1 << 12)
#else
#define MST_10_BIT_ADDR_MODE	(0x00)
#define IC_10BITADDR_MASTER	(0x00)
#endif

#if DW_I2C_SPECIAL_START_BYTE
#define TAR_SPECIAL		(1 << 11)
#define TAR_GO_OR_START		(1 << 12)
#else
#define TAR_SPECIAL		(0x00)
#define TAR_GO_OR_START		(0x00)
#endif

#if DW_I2C_SLV_10_BIT_ADDR_SUPPORT
#define SLV_10_BIT_ADDR_MODE	(1 << 3)
#else
#define SLV_10_BIT_ADDR_MODE	(0x00)
#endif

/* DW_APB I2C (DW_IC_STATUS) Status Register Fields. */
#define I2C_STATUS_ACTIVITY	(0x01)
#define I2C_STATUS_TFNF		(0x02) /* (1 << 1) */
#define I2C_STATUS_TFE		(0x04) /* (1 << 2) */
#define I2C_STATUS_RFNE		(0x08) /* (1 << 3) */
#define I2C_STATUS_RFF		(0x10) /* (1 << 4) */
#define I2C_STATUS_MASTER_ACT	(0x20) /* (1 << 5) */
#define I2C_STATUS_SLAVE_ACT	(0x40) /* (1 << 6) */
/** @} */

/* Interrupt Register Fields */
#define R_GEN_CALL		(1 << 11)
#define R_START_DET		(1 << 10)
#define R_STOP_DET		(1 << 9)
#define R_ACTIVITY		(1 << 8)
#define R_RX_DONE		(1 << 7)
#define R_TX_ABRT		(1 << 6)
#define R_RD_REQ		(1 << 5)
#define R_TX_EMPTY		(1 << 4)
#define R_TX_OVER		(1 << 3)
#define R_RX_FULL		(1 << 2)
#define R_RX_OVER		(1 << 1)
#define R_RX_UNDER		(1 << 0)

#endif /* _DEVICE_DW_IIC_HAL_H_ */
