/* ------------------------------------------
 * Copyright (c) 2015, Synopsys, Inc. All rights reserved.

 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:

 * 1) Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.

 * 2) Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation and/or
 * other materials provided with the distribution.

 * 3) Neither the name of the Synopsys, Inc., nor the names of its contributors may
 * be used to endorse or promote products derived from this software without
 * specific prior written permission.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * \version 2015.05
 * \date 2014-06-30
 * \author Huaqi Fang(Huaqi.Fang@synopsys.com)
--------------------------------------------- */

/**
 * \defgroup	DEVICE_DW_IIC	Designware IIC Driver
 * \ingroup	DEVICE_DW
 * \brief	Designware IIC Driver Implementation
 */

/**
 * \file
 * \brief	Designware iic driver
 * \note	Currently only support master mode in pull method
 *	when use try to open it, it will return E_ILUSE
 * \todo	Add support for interrupt mode and slave mode
 * \ingroup	DEVICE_DW_IIC
 */

#include <stddef.h>
#include <stdbool.h> /** true or false definitions */

#include "embARC_toolchain.h"
#include "embARC_error.h"

#include "arc_exception.h"

#include "dw_iic_hal.h"
#include "dw_iic.h"

/**
 * \defgroup	DEVICE_DW_IIC_DEFINES	DesignWare IIC Driver Macros
 * \ingroup	DEVICE_DW_IIC
 * \brief	DesignWare IIC driver macros used in iic driver
 * @{
 */
/** check expressions used in DesignWare IIC driver implemention */
#define DW_IIC_CHECK_EXP(EXPR, ERROR_CODE)		CHECK_EXP(EXPR, ercd, ERROR_CODE, error_exit)


/** @} */

/** DesignWare IIC Functions Declaration */
static int32_t dw_iic_init (DW_IIC_REG *iic_reg_ptr, uint32_t speed_mode, uint32_t slv_addr);
static int32_t dw_iic_chkerr(DEV_IIC_INFO *iic_info_ptr);
static void dw_iic_reconfigure(DEV_IIC_INFO *iic_info_ptr);

/**
 * \defgroup	DEVICE_DW_IIC_IMPLEMENT	DesignWare IIC Driver Function API Implement
 * \ingroup	DEVICE_DW_IIC
 * \brief	implement device hal iic api with DesignWare IIC
 * @{
 */
/**
 * \brief	DesignWare IIC get information by commands
 * \param[in]	iic_info_ptr	iic information structure pointer
 * \param[in]	cmd		command used by this function
 * \param[out]	rinfo		information return of this command
 * \retval
 */
int32_t dw_iic_get_info (DEV_IIC_INFO *iic_info_ptr, uint32_t cmd, void *rinfo)
{
	int32_t ercd = E_OK;

	DW_IIC_CHECK_EXP(iic_info_ptr!=NULL, E_PAR);
	DW_IIC_CHECK_EXP(rinfo!=NULL, E_PAR);

	switch (cmd) {
		case IIC_CMD_GETINFO_ALL:
			*((DEV_IIC_INFO **)rinfo) = iic_info_ptr;
			break;
		case IIC_CMD_GETINFO_SPEED:
			*((uint32_t *)rinfo) = iic_info_ptr->speed;
			break;
		case IIC_CMD_GETINFO_STATE:
			*((uint32_t *)rinfo) = iic_info_ptr->opn_flg | (iic_info_ptr->err_flg<<1);
			break;
		default:
			ercd = E_ILUSE;
			break;
	}

error_exit:
	return ercd;
}

/**
 * \brief	open a designware iic device
 * \param[in]	iic_info_ptr	iic information structure pointer
 * \param[in]	speed		iic working speed
 * \param[in]	mode		iic working mode (master or slave)
 * \param[in]	method		working method(int or poll)
 * \retval	E_OK		open iic successfully
 * \retval	E_PAR		arguments passed was wrong
 * \retval	E_OPNED		iic was already opened
 * \retval	E_OBJ		iic has something error
 * \retval	E_ILUSE		iic open method or mode not supported
 * \retval	<0		other error code not defined here
 */
int32_t dw_iic_open (DEV_IIC_INFO *iic_info_ptr, uint32_t speed, uint32_t mode, uint32_t method)
{
	int32_t ercd = E_OK;		/** error code to return, default E_OK */
	DW_IIC_REG *iic_reg_ptr;	/** iic register structure */
	DW_IIC_CTRL *iic_ctrl_ptr;	/** iic control structure */

	/** check if iic structure available */
	DW_IIC_CHECK_EXP(iic_info_ptr!=NULL, E_PAR);
	/** check if input mode is valid */
	DW_IIC_CHECK_EXP((mode==DEV_MASTER_MODE)||(mode==DEV_SLAVE_MODE), E_PAR);

	/** check if input method is valid */
	DW_IIC_CHECK_EXP((method==DEV_INTERRUPT_METHOD)||(method==DEV_POLL_METHOD), E_PAR);
	/** check if iic was closed, not opened before */
	DW_IIC_CHECK_EXP(iic_info_ptr->opn_flg==DEV_CLOSED, E_OPNED);
	/** check if iic was working good, not error */
	DW_IIC_CHECK_EXP(iic_info_ptr->err_flg==DEV_GOOD, E_OBJ);

	/** check if open method is supported */
	DW_IIC_CHECK_EXP(((method==DEV_POLL_METHOD)&&(mode==DEV_MASTER_MODE)), E_ILUSE);

	/** convert iic regbase to iic reg structure format */
	iic_reg_ptr = (DW_IIC_REG_PTR)(iic_info_ptr->iic_regs);

	/** convert to iic control structure */
	iic_ctrl_ptr = (DW_IIC_CTRL_PTR)(iic_info_ptr->iic_ctrl);

	/** init iic */
	if ((speed == IIC_SPEED_STANDARD) || \
		(speed == IIC_SPEED_FAST) || \
		(speed == IIC_SPEED_HIGH)) {
		iic_info_ptr->speed = speed;
	} else {
		ercd = E_PAR;
		goto error_exit;
	}

	dw_iic_init(iic_reg_ptr, speed, iic_info_ptr->slv_addr);

	iic_ctrl_ptr->iic_state = I2C_STATE_READY;
	/**
	 * iic interrupt related init
	 */
	/** install iic interrupt into system */
	int_handler_install(iic_info_ptr->intno, iic_ctrl_ptr->dw_iic_int_handler);
	if (method == DEV_INTERRUPT_METHOD) {
		iic_info_ptr->method = DEV_INTERRUPT_METHOD;
		int_enable(iic_info_ptr->intno); /** enable iic interrupt */
	} else { /** iic poll method setup */
		iic_info_ptr->method = DEV_POLL_METHOD;
	}
	iic_info_ptr->mode = mode;	/** set working mode */

	iic_info_ptr->opn_flg = DEV_OPENED;

error_exit:
	return ercd;
}

/**
 * \brief	Close a DesignWare IIC device
 * \param[in]	iic_info_ptr	iic infomation structure pointer
 * \retval	E_OK		close iic successfully
 * \retval	E_PAR		arguments passed was wrong
 * \retval	E_CLSED		iic was already closed
 * \retval	E_OBJ		iic has something error
 * \retval	<0		other error code not defined here
 */
int32_t dw_iic_close (DEV_IIC_INFO *iic_info_ptr)
{
	int32_t ercd = E_OK;		/** error code to return, default E_OK */
	DW_IIC_REG *iic_reg_ptr;	/** iic register structure */

	/** check if iic structure available */
	DW_IIC_CHECK_EXP(iic_info_ptr!=NULL, E_PAR);
	/** check if iic was opened, not closed before */
	DW_IIC_CHECK_EXP(iic_info_ptr->opn_flg==DEV_OPENED, E_CLSED);

	/** convert iic regbase to iic reg structure format */
	iic_reg_ptr = (DW_IIC_REG_PTR)(iic_info_ptr->iic_regs);

	/* disable iic interrupt */
	int_disable(iic_info_ptr->intno);
	/** disable all iic interrupt after disable iic interrupt */
	iic_reg_ptr->IC_INTR_MASK = I2C_INT_DSB;

	/**
	 * \todo may need to flush iic output here
	 * \todo may need to do software reset after flush
	 */
	/** set iic open flag to DEV_CLOSED */
	iic_info_ptr->opn_flg = DEV_CLOSED;
	/** clear iic error flag */
	iic_info_ptr->err_flg = DEV_GOOD;

	iic_info_ptr->tar_addr = 0;

error_exit:
	return ercd;
}

/**
 * \brief	control iic by ctrl command
 * \param[in]	iic_info_ptr	iic infomation structure pointer
 * \param[in]	ctrl_cmd	control command code to do specific iic work
 * \param[in,out]	param	parameters used to control iic or return something
 * \retval	E_OK		close iic successfully
 * \retval	E_PAR		arguments passed was wrong
 * \retval	E_OBJ		iic has something error, nothing can be done
 * \retval	E_CLSED		iic was closed, not available for control
 * \retval	<0		other error code not defined here
 */
int32_t dw_iic_control (DEV_IIC_INFO *iic_info_ptr, uint32_t ctrl_cmd, void *param)
{
	int32_t ercd = E_OK;	/** error code to return, default E_OK */
	uint32_t val32;		/** to receive unsigned int value */

	DW_IIC_REG *iic_reg_ptr;	/** iic register structure */
	DW_IIC_CTRL *iic_ctrl_ptr;	/** iic control structure */

	/** check if iic structure available */
	DW_IIC_CHECK_EXP(iic_info_ptr!=NULL, E_PAR);
	/** check if iic was opened to do following things */
	DW_IIC_CHECK_EXP(iic_info_ptr->opn_flg==DEV_OPENED, E_CLSED);
	/** check if iic was working good, not error */
	DW_IIC_CHECK_EXP(iic_info_ptr->err_flg==DEV_GOOD, E_OBJ);

	/** param must be valid */
	DW_IIC_CHECK_EXP(param!=NULL, E_PAR);

	/** convert iic regbase to iic reg structure format */
	iic_reg_ptr = (DW_IIC_REG_PTR)(iic_info_ptr->iic_regs);
	/** convert iic control address to iic control structure format */
	iic_ctrl_ptr = (DW_IIC_CTRL_PTR)(iic_info_ptr->iic_ctrl);

	switch (ctrl_cmd) {
		/**
		 * \todo may need work to do change baudrate.
		 * if need to disable and re-enable iic
		 */
		case IIC_CMD_CHG_SPEED:
			val32 = *((int32_t *)param);
			if ((val32 == IIC_SPEED_STANDARD) \
				|| (val32 == IIC_SPEED_FAST) \
				|| (val32 == IIC_SPEED_HIGH)) { /** check speed format */
				//while (iic_reg_ptr->IC_STATUS & I2C_STATUS_ACTIVITY);
				if (iic_ctrl_ptr->iic_state == I2C_STATE_READY) {
					iic_info_ptr->speed = val32;
					dw_iic_reconfigure(iic_info_ptr);
				} else {
					ercd = E_OBJ;
				}
			} else {
				ercd = E_PAR;
			}
			break;
		case IIC_CMD_CHG_MTHD:
			// val32 = *((int32_t *)param);
			// if (val32 != DEV_INTERRUPT_METHOD) { /** when not interrupt method default poll */
			//	val32 = DEV_POLL_METHOD;
			// }
			// if (iic_ctrl_ptr->iic_state == I2C_STATE_READY) {
			//	iic_info_ptr->method = val32;
			//	dw_iic_reconfigure(iic_info_ptr);
			// }
			ercd = E_ILUSE; /* not supported now */
			break;
		case IIC_CMD_CHG_MODE:
			// val32 = *((int32_t *)param);
			// if (val32 != DEV_INTERRUPT_METHOD) { /** when not interrupt method default poll */
			//	val32 = DEV_POLL_METHOD;
			// }
			// if (iic_ctrl_ptr->iic_state == I2C_STATE_READY) {
			//	iic_info_ptr->method = val32;
			//	dw_iic_reconfigure(iic_info_ptr);
			// }
			ercd = E_ILUSE; /* not supported now */
			break;
		case IIC_CMD_SET_TARADDR:
			val32 = *((int32_t *)param);
			if (iic_ctrl_ptr->iic_state == I2C_STATE_READY) {
				iic_info_ptr->tar_addr = val32;
				dw_iic_reconfigure(iic_info_ptr);
			} else {
				ercd = E_OBJ;
			}
			break;
		case IIC_CMD_SET_SLVADDR:
			val32 = *((int32_t *)param);
			if (iic_ctrl_ptr->iic_state == I2C_STATE_READY) {
				iic_reg_ptr->IC_ENABLE = DISABLE_I2C;
				iic_info_ptr->slv_addr = val32;
				iic_reg_ptr->IC_SAR = val32;
				iic_reg_ptr->IC_ENABLE = ENABLE_I2C;
			} else {
				ercd = E_OBJ;
			}
			break;
		case IIC_CMD_FLS_OUTP:
			while (iic_reg_ptr->IC_STATUS & I2C_STATUS_ACTIVITY);
			iic_ctrl_ptr->iic_state = I2C_STATE_READY;
			break;
		case IIC_CMD_SET_WRITEMODE:
			val32 = *((int32_t *)param);
			if (iic_ctrl_ptr->iic_state == I2C_STATE_READY) {
				if (val32 == IIC_WRITE_MODE_STOP) {
					iic_ctrl_ptr->write_mode = IIC_WRITE_MODE_STOP;
				} else if (val32 == IIC_WRITE_MODE_RESTART) {
					iic_ctrl_ptr->write_mode = IIC_WRITE_MODE_RESTART;
				} else {
					ercd = E_PAR;
				}
			} else {
				ercd = E_OBJ;
			}
			break;
		/**
		 * \todo need to realize dump iic information,
		 *  may directly return to the para
		 */
		case IIC_CMD_DMP_INFO:
			ercd = E_ILUSE;
			break;
		default:
			ercd = E_ILUSE;
			break;
	}

error_exit:
	return ercd;
}

/**
 * \brief	send data through DesignWare IIC
 * \param[in]	iic_info_ptr	iic infomation structure pointer
 * \param[in]	data		data that need to send (data must be char type)
 * \param[in]	len		data length need to send
 * \retval	>=0		data have been sent
 * \retval	E_PAR		arguments passed was wrong
 * \retval	E_OBJ		iic has something error, nothing can be done
 * \retval	E_CLSED		iic was closed, not available for control
 * \retval	<0		other error code not defined here
 */
int32_t dw_iic_write (DEV_IIC_INFO *iic_info_ptr, const void *data, uint32_t len)
{
	int32_t ercd = E_OK;	/** error code to return, default E_OK */
	const char *p_charbuf = (const char *)data;	/** convert void buffer to char buffer */
	int32_t write_mode_bit = 0;

	DW_IIC_REG *iic_reg_ptr;	/** iic register structure */
	DW_IIC_CTRL *iic_ctrl_ptr;	/** iic control structure */

	/** check if iic structure available */
	DW_IIC_CHECK_EXP(iic_info_ptr!=NULL, E_PAR);
	/** check if iic was opened to do following things */
	DW_IIC_CHECK_EXP(iic_info_ptr->opn_flg==DEV_OPENED, E_CLSED);
	/** check if iic was working good, not error */
	DW_IIC_CHECK_EXP(iic_info_ptr->err_flg==DEV_GOOD, E_OBJ);

	/** check if length must bigger than 0 */
	DW_IIC_CHECK_EXP(len>0, E_PAR);

	/** convert iic regbase to iic reg structure format */
	iic_reg_ptr = (DW_IIC_REG_PTR)(iic_info_ptr->iic_regs);
	/** convert iic control address to iic control structure format */
	iic_ctrl_ptr = (DW_IIC_CTRL_PTR)(iic_info_ptr->iic_ctrl);

	iic_ctrl_ptr->iic_state = I2C_STATE_TRANSMIT;
	iic_ctrl_ptr->iic_snd_buf = data;
	iic_ctrl_ptr->iic_snd_len = len;
	iic_ctrl_ptr->iic_snd_idx = 0;

	if (iic_ctrl_ptr->write_mode == IIC_WRITE_MODE_STOP) {
		write_mode_bit = DW_I2C_STOP_BIT;
	} else if (iic_ctrl_ptr->write_mode == IIC_WRITE_MODE_RESTART) {
		write_mode_bit = DW_I2C_RESTART_BIT;
	} else {
		write_mode_bit = DW_I2C_STOP_BIT;
	}
	if (iic_info_ptr->method == DEV_INTERRUPT_METHOD) { /* Interrupt Method Send */
		/** \todo need to realize iic send in interrupt method */

	} else { /* Poll Method Send */
		if (iic_info_ptr->mode == DEV_MASTER_MODE) { /* master mode */
			while (iic_ctrl_ptr->iic_snd_idx < iic_ctrl_ptr->iic_snd_len) {
				if (iic_reg_ptr->IC_STATUS & I2C_STATUS_TFNF) {
					if (iic_ctrl_ptr->iic_snd_idx == (iic_ctrl_ptr->iic_snd_len - 1)) {
						/** last byte send stop */
						iic_reg_ptr->IC_DATA_CMD = ((uint32_t)(p_charbuf[iic_ctrl_ptr->iic_snd_idx])) | (write_mode_bit);
					} else {
						iic_reg_ptr->IC_DATA_CMD = p_charbuf[iic_ctrl_ptr->iic_snd_idx];
					}
					iic_ctrl_ptr->iic_snd_idx ++;
				}
				if (dw_iic_chkerr(iic_info_ptr) != 0) {
					break;
				}
			}
		} else { /* slave mode */
			while (iic_ctrl_ptr->iic_snd_idx < (iic_ctrl_ptr->iic_snd_len)) {
				if (iic_reg_ptr->IC_RAW_INTR_STAT & R_RD_REQ) {
					iic_reg_ptr->IC_DATA_CMD = p_charbuf[iic_ctrl_ptr->iic_snd_idx];
					iic_ctrl_ptr->iic_snd_idx ++;
				}
			}
		}
		ercd = iic_ctrl_ptr->iic_snd_idx;
	}
	iic_ctrl_ptr->iic_state = I2C_STATE_READY;

error_exit:
	return ercd;
}

/**
 * \brief	read data through DesignWare IIC
 * \param[in]	iic_info_ptr	iic infomation structure pointer
 * \param[out]	data		data that need to read (data must be char type)
 * \param[in]	len		data count need to read
 * \retval	>=0		data have been read
 * \retval	E_PAR		arguments passed was wrong
 * \retval	E_OBJ		iic has something error, nothing can be done
 * \retval	E_CLSED		iic was closed, not available for control
 * \retval	<0		other error code not defined here
 */
int32_t dw_iic_read (DEV_IIC_INFO *iic_info_ptr, void *data, uint32_t len)
{
	int32_t ercd = E_OK;		/** error code to return, default E_OK */
	char *p_charbuf = (char *)data;	/** convert void buffer to char buffer */

	int32_t error = 0;
	int32_t break_loop_flag = 0;	/** break loop */

	DW_IIC_REG *iic_reg_ptr;	/** iic register structure */
	DW_IIC_CTRL *iic_ctrl_ptr;	/** iic control structure */


	/** check if iic structure available */
	DW_IIC_CHECK_EXP(iic_info_ptr!=NULL, E_PAR);
	/** check if iic was opened to do following things */
	DW_IIC_CHECK_EXP(iic_info_ptr->opn_flg==DEV_OPENED, E_CLSED);
	/** check if iic was working good, not error */
	DW_IIC_CHECK_EXP(iic_info_ptr->err_flg==DEV_GOOD, E_OBJ);
	/** check if length must bigger than 0 */
	DW_IIC_CHECK_EXP(len>0, E_PAR);

	/** convert iic regbase to iic reg structure format */
	iic_reg_ptr = (DW_IIC_REG_PTR)(iic_info_ptr->iic_regs);
	/** convert iic control address to iic control structure format */
	iic_ctrl_ptr = (DW_IIC_CTRL_PTR)(iic_info_ptr->iic_ctrl);

	iic_ctrl_ptr->iic_state = I2C_STATE_RECEIVE;
	iic_ctrl_ptr->iic_rcv_buf = data;
	iic_ctrl_ptr->iic_rcv_len = len;
	iic_ctrl_ptr->iic_rcv_idx = 0;
	iic_ctrl_ptr->iic_snd_len = len;
	iic_ctrl_ptr->iic_snd_idx = 0;

	if (iic_info_ptr->method == DEV_INTERRUPT_METHOD) { /* Interrupt Method Receive */
		/** \todo need to realize iic receive in interrupt method */

	} else { /* Poll Method Receive */
		while (!break_loop_flag) { /** need to receive */
			if (iic_info_ptr->mode == DEV_MASTER_MODE) {
				while ((iic_ctrl_ptr->iic_snd_len > iic_ctrl_ptr->iic_snd_idx) && \
					(iic_reg_ptr->IC_STATUS & I2C_STATUS_TFNF)) {
					if ((iic_ctrl_ptr->iic_snd_len-1) == iic_ctrl_ptr->iic_snd_idx) {
						/* last byte send stop */
						iic_reg_ptr->IC_DATA_CMD = DW_I2C_READ_CMD | DW_I2C_STOP_CMD;
					} else {
						iic_reg_ptr->IC_DATA_CMD = DW_I2C_READ_CMD;
					}
					iic_ctrl_ptr->iic_snd_idx ++;
					if (dw_iic_chkerr(iic_info_ptr) != 0) {
						error = 1;
						break;
					}
				}
			}
			while ((iic_ctrl_ptr->iic_rcv_len > iic_ctrl_ptr->iic_rcv_idx) && \
				(iic_reg_ptr->IC_STATUS & I2C_STATUS_RFNE)) { /* not empty to receive data */
				p_charbuf[iic_ctrl_ptr->iic_rcv_idx] = iic_reg_ptr->IC_DATA_CMD;
				iic_ctrl_ptr->iic_rcv_idx ++;
				if (dw_iic_chkerr(iic_info_ptr) != 0) {
					error = 1;
					break;
				}
			}
			if ((iic_ctrl_ptr->iic_rcv_len == iic_ctrl_ptr->iic_rcv_idx) || (error)) {
				break_loop_flag = 1; /* end the loop */
			}
		}
		ercd = iic_ctrl_ptr->iic_rcv_idx;
	}
	iic_ctrl_ptr->iic_state = I2C_STATE_READY;

error_exit:
	return ercd;
}

/**
 * \brief	DesignWare IIC interrupt processing routine
 * \param[in]	iic_info_ptr	DEV_IIC_INFO *iic_info_ptr
 * \param[in]	ptr		extra information
 */
void dw_iic_isr(DEV_IIC_INFO *iic_info_ptr, void *ptr)
{


error_exit:
	return;
}
/** @} */ /* DEVICE_DW_IIC_IMPLEMENT */

/**
 * \brief	init designware iic with selected baud
 * \param[in]	iic_reg_ptr	iic register structure pointer
 * \param[in]	speed_mode	iic speed mode(standard/fast/high)
 * \param[in]	slv_addr	slave address when working as slave device
 * \retval	E_OK		init success
 * \retval	E_PAR		arguments passed was wrong
 * \retval	<0		other error code not defined here
 */
static int32_t dw_iic_init (DW_IIC_REG *iic_reg_ptr, uint32_t speed_mode, uint32_t slv_addr)
{
	int32_t ercd = E_OK;	/** error code to return, default E_OK */
	uint32_t iic_con = 0;

	/** check if iic register structure available */
	DW_IIC_CHECK_EXP(iic_reg_ptr!=NULL, E_PAR);

	/** disable iic operations, then program iic control regs is possible */
	iic_reg_ptr->IC_ENABLE = DISABLE_I2C;

	/** disable all iic interrupt */
	iic_reg_ptr->IC_INTR_MASK = I2C_INT_DSB;

	/** set iic configuration */
	iic_con = ENB_MASTER_MODE | (speed_mode << 1)| MST_10_BIT_ADDR_MODE
			| SLV_10_BIT_ADDR_MODE | IC_RESTART_EN;
	iic_reg_ptr->IC_CON = iic_con;

	/** set iic clock frequency configuration */
	iic_reg_ptr->IC_SS_SCL_HCNT = DW_IC_SS_SCL_HIGH_COUNT;
	iic_reg_ptr->IC_SS_SCL_LCNT = DW_IC_SS_SCL_LOW_COUNT;
	iic_reg_ptr->IC_FS_SCL_HCNT = DW_IC_FS_SCL_HIGH_COUNT;
	iic_reg_ptr->IC_FS_SCL_LCNT = DW_IC_FS_SCL_LOW_COUNT;

	/** set iic slave address */
	iic_reg_ptr->IC_SAR = slv_addr;

	/** fifo threshold tigger setting */
	iic_reg_ptr->IC_TX_TL = DW_TX_FIFO_THRESHOLD;
	iic_reg_ptr->IC_RX_TL = DW_RX_FIFO_THRESHOLD;

	/** enable iic device */
	iic_reg_ptr->IC_ENABLE = ENABLE_I2C;
error_exit:
	return ercd;
}

static void dw_iic_reconfigure(DEV_IIC_INFO *iic_info_ptr)
{
	uint32_t reg_val = 0;
	DW_IIC_REG *iic_reg_ptr;	/** iic register structure */
	DW_IIC_CTRL *iic_ctrl_ptr;	/** iic control structure */

	/** convert iic regbase to iic reg structure format */
	iic_reg_ptr = (DW_IIC_REG_PTR)(iic_info_ptr->iic_regs);
	/** convert iic control address to iic control structure format */
	iic_ctrl_ptr = (DW_IIC_CTRL_PTR)(iic_info_ptr->iic_ctrl);

	/** disable iic device */
	iic_reg_ptr->IC_ENABLE = DISABLE_I2C;

	if (iic_info_ptr->mode == DEV_MASTER_MODE) {
		reg_val = ENB_MASTER_MODE | (iic_info_ptr->speed << 1) | MST_10_BIT_ADDR_MODE \
					| SLV_10_BIT_ADDR_MODE | IC_RESTART_EN;
		iic_reg_ptr->IC_CON = reg_val;
		reg_val = iic_info_ptr->tar_addr | IC_10BITADDR_MASTER | TAR_SPECIAL | TAR_GO_OR_START;
		iic_reg_ptr->IC_TAR = reg_val;
	} else {
		reg_val = (iic_info_ptr->speed << 1) | MST_10_BIT_ADDR_MODE \
				| SLV_10_BIT_ADDR_MODE | IC_RESTART_EN;
		iic_reg_ptr->IC_CON = reg_val;
	}

	/** enable iic device */
	iic_reg_ptr->IC_ENABLE = ENABLE_I2C;
}

/** check iic working error, 0 for working well, else return error status */
static int32_t dw_iic_chkerr(DEV_IIC_INFO *iic_info_ptr)
{
	uint32_t status;

	DW_IIC_REG *iic_reg_ptr;	/** iic register structure */
	DW_IIC_CTRL *iic_ctrl_ptr;	/** iic control structure */

	/** convert iic regbase to iic reg structure format */
	iic_reg_ptr = (DW_IIC_REG_PTR)(iic_info_ptr->iic_regs);
	/** convert iic control address to iic control structure format */
	iic_ctrl_ptr = (DW_IIC_CTRL_PTR)(iic_info_ptr->iic_ctrl);

	status = iic_reg_ptr->IC_RAW_INTR_STAT;

	if (status) {
		if (status & R_TX_ABRT) {
			iic_ctrl_ptr->iic_error_status = iic_reg_ptr->IC_TX_ABRT_SOURCE;
			return status;
		}
		if (status & R_TX_OVER) {
			iic_ctrl_ptr->iic_tx_over ++;
			return status;
		}
		if (status & R_RX_OVER) {
			iic_ctrl_ptr->iic_rx_over ++;
			return status;
		}
	}
	return 0;
}

/** @} */ /* DEVICE_DW_IIC */
