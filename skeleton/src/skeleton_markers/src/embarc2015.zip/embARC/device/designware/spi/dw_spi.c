/* ------------------------------------------
 * Copyright (c) 2015, Synopsys, Inc. All rights reserved.

 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:

 * 1) Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.

 * 2) Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation and/or
 * other materials provided with the distribution.

 * 3) Neither the name of the Synopsys, Inc., nor the names of its contributors may
 * be used to endorse or promote products derived from this software without
 * specific prior written permission.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * \version 2015.05
 * \date 2014-06-25
 * \author Huaqi Fang(Huaqi.Fang@synopsys.com)
--------------------------------------------- */

/**
 * \defgroup	DEVICE_DW_SPI	Designware SPI Driver
 * \ingroup	DEVICE_DW
 * \brief	Designware SPI Driver Implementation
 */

/**
 * \file
 * \brief	DesignWare SPI driver implemention based on device hal layer definition(\ref dev_spi.h)
 * \note	currently only support master mode in pull method
 * \ingroup	DEVICE_DW_SPI
 */

#include <stddef.h>
#include <stdbool.h> /** true or false definitions */

#include "embARC_toolchain.h"
#include "embARC_error.h"

#include "arc_exception.h"

#include "dw_spi_hal.h"
#include "dw_spi.h"

/**
 * \defgroup	DEVICE_DW_SPI_DEFINES	DesignWare SPI Driver Macros
 * \ingroup	DEVICE_DW_SPI
 * \brief	DesignWare SPI driver macros used in spi driver
 * @{
 */
/** check expressions used in DesignWare SPI driver implemention */
#define DW_SPI_CHECK_EXP(EXPR, ERROR_CODE)		CHECK_EXP(EXPR, ercd, ERROR_CODE, error_exit)

/** convert DesignWare frequence to divisor */
#define DW_SPI_FREQ2DV(perifreq, spifreq)		((perifreq) / (spifreq))

/**
 * \defgroup	DEVICE_DW_SPI_DEF_CBR	DesignWare SPI Interrupt Callback Routine Select Marcos
 * \ingroup	DEVICE_DW_SPI_DEFINES
 * \brief	DesignWare SPI interrupt callback routines select macros definitions
 * @{
 */
#define DW_SPI_RDY_SND					(1U)	/*!< ready to send callback */
#define DW_SPI_RDY_RCV					(2U)	/*!< ready to receive callback */
#define DW_SPI_RDY_ALL					(0U)	/*!< ready to operate all */
/** @} */

/** @} */

/** DesignWare SPI Functions Declaration */
static int32_t dw_spi_init (DW_SPI_REG *spi_reg_ptr, uint32_t baud_divisor, uint32_t clock_mode);
static int32_t dw_spi_dis_cbr (DW_SPI_REG *spi_reg_ptr, uint32_t cbrtn);
static int32_t dw_spi_ena_cbr (DW_SPI_REG *spi_reg_ptr, uint32_t cbrtn);

static void dw_spi_transfer(DEV_SPI_INFO *spi_info_ptr, DEV_SPI_TRANSFER *transfer);

/**
 * \defgroup	DEVICE_DW_SPI_INLINE	DesignWare SPI Inline Functions
 * \ingroup	DEVICE_DW_SPI
 * \brief	inline functions for DesignWare SPI handle spi operations,
 * 	only used in \ref dw_spi.c
 * @{
 */
/** test whether spi is busy, busy return 1, else 0 */
Inline int32_t dw_spi_busy(DW_SPI_REG *spi_reg_ptr)
{
	return ((spi_reg_ptr->SR & DW_SPI_SSI_SR_BUSY) != 0);
}
/** test whether spi is ready to send, 1 ready, 0 not ready */
Inline int32_t dw_spi_putready(DW_SPI_REG *spi_reg_ptr)
{
	return ((spi_reg_ptr->SR & DW_SPI_SSI_SR_TFNF) != 0);
}
/** test whether spi is read to receive, 1 ready, 0 not ready */
Inline int32_t dw_spi_getready(DW_SPI_REG *spi_reg_ptr)
{
	return ((spi_reg_ptr->SR & DW_SPI_SSI_SR_RFNE) != 0);
}
/** write data to spi send fifo */
Inline void dw_spi_putdata(DW_SPI_REG *spi_reg_ptr, int32_t data)
{
	spi_reg_ptr->DATAREG = (uint32_t)data;
}
/** read data from spi receive fifo, return data received */
Inline int32_t dw_spi_getdata(DW_SPI_REG *spi_reg_ptr)
{
	return (int32_t)spi_reg_ptr->DATAREG;
}
/**
 * \brief	send data by spi when available,
 * 	mostly used in interrupt method, non-blocked function
 * \param[in]	spi_reg_ptr	spi register structure pointer
 * \param[in]	data		data to be sent
 * \retval	E_OK		send successfully
 * \retval	E_OBJ		not ready to send data
 */
Inline int32_t dw_spi_snd_dat(DW_SPI_REG *spi_reg_ptr, int32_t data)
{
	if (dw_spi_putready(spi_reg_ptr)) {
		dw_spi_putdata(spi_reg_ptr, data);
		return E_OK;
	}
	return E_OBJ;
}
/**
 * \brief	receive one char from spi,
 * 	mostly used in interrupt routine, non-blocked function
 * \param[in]	spi_reg_ptr	spi register structure pointer
 * \return	data received by the spi
 */
Inline int32_t dw_spi_rcv_dat(DW_SPI_REG *spi_reg_ptr)
{
	return dw_spi_getdata(spi_reg_ptr);
}
/**
 * \brief	send char by spi in poll method, blocked function
 * \param[in]	spi_reg_ptr	spi register structure pointer
 * \param[in]	data		data to be sent
 */
Inline void dw_spi_psnd_dat(DW_SPI_REG *spi_reg_ptr, int32_t data)
{
	/** wait until spi is ready to send */
	while (!dw_spi_putready(spi_reg_ptr)); /* blocked */
	/** send char */
	dw_spi_putdata(spi_reg_ptr, data);
}
/**
 * \brief	receive one char from spi in poll method, blocked function
 * \param[in]	spi_reg_ptr	spi register structure pointer
 * \return	data received by the spi
 */
Inline int32_t dw_spi_prcv_dat(DW_SPI_REG *spi_reg_ptr)
{
	/** wait until spi is ready to receive */
	while (!dw_spi_getready(spi_reg_ptr)); /* blocked */
	/** receive data */
	return dw_spi_getdata(spi_reg_ptr);
}

/**
 * \brief	calculate spi fifo length using fifo threshold method
 * 	If you attempt to set bits [7:0] of this register to
 * 	a value greater than or equal to the depth of the FIFO,
 * 	this field is not written and retains its current value.
 * \param	spi_reg_ptr	spi register structure pointer
 * \retval	>0		spi fifo length
 */
uint32_t dw_spi_calc_fifolen(DW_SPI_REG *spi_reg_ptr)
{
	uint32_t fifo_thr_lev_tmp, left, right, i;

	fifo_thr_lev_tmp = spi_reg_ptr->TXFTLR;

	if (fifo_thr_lev_tmp != 0) {
		left = fifo_thr_lev_tmp;
	} else {
		left = DW_SPI_MIN_FIFO_LENGTH;
	}
	right = DW_SPI_MAX_FIFO_LENGTH + 1;

	while (1) {
		spi_reg_ptr->TXFTLR = left;
		if (left == spi_reg_ptr->TXFTLR) {
			left = left << 1;
		} else {
			break;
		}
	}
	while (1) {
		spi_reg_ptr->TXFTLR = right;
		if (right != spi_reg_ptr->TXFTLR) {
			right = right >> 1;
		} else {
			break;
		}
	}

	i = left; /** save left value */
	/** get the most approximate left and right boundary */
	left = (right > (left >> 1)) ? right : (left >> 1);
	right = (i > (right << 1)) ? i : (right << 1);

	for (i = left; i <= right; i++) {
		spi_reg_ptr->TXFTLR = i;
		if (spi_reg_ptr->TXFTLR != i) {
			break;
		}
	}
	spi_reg_ptr->TXFTLR = fifo_thr_lev_tmp; /* restore old fifo threshold */

	return (i);
}

/**
 * \brief	calc & adjust how many bytes need to transfer in this spi_transfer
 * \param[in]	spi_transfer	the transfer that need to be calculated
 * \retval	0		calc failed or count is zero
 * \retval	>0		total transfer count in a tranfer queue
 */
uint32_t calc_transfer_cnt(DEV_SPI_TRANSFER *spi_transfer)
{
	uint32_t cnt = 0;
	DEV_SPI_TRANSFER *xfer = spi_transfer;

	while (xfer != NULL) {
		if (xfer->snd_buf == NULL) {
			xfer->snd_cnt = 0; /* force send count = 0 */
		}

		xfer->rcv_cnt = xfer->rcv_cnt + xfer->rcv_ofs;

		if (xfer->rcv_buf == NULL) {
			xfer->rcv_cnt = 0; /* force receive count = 0 */
			xfer->rcv_ofs = 0;
		}
		/** get bytes count that need to be transfered */
		xfer->xfer_cnt = (xfer->rcv_cnt > xfer->snd_cnt) ? xfer->rcv_cnt : xfer->snd_cnt;
		cnt += xfer->xfer_cnt;
		xfer =  xfer->next;
	}
	return cnt;
}

/** @} */

/**
 * \defgroup	DEVICE_DW_SPI_IMPLEMENT	DesignWare SPI Driver Function API Implement
 * \ingroup	DEVICE_DW_SPI
 * \brief	implement device hal spi api with DesignWare SPIt
 * @{
 */
/**
 * \brief	DesignWare SPI get information by commands
 * \param[in]	spi_info_ptr	spi information structure pointer
 * \param[in]	cmd		command used by this function
 * \param[out]	rinfo		information return of this command
 * \retval
 */
int32_t dw_spi_get_info (DEV_SPI_INFO *spi_info_ptr, uint32_t cmd, void *rinfo)
{
	int32_t ercd = E_OK;

	DW_SPI_CHECK_EXP(spi_info_ptr!=NULL, E_PAR);

error_exit:
	return ercd;
}

/**
 * \brief	open a designware spi device
 * \param[in]	spi_info_ptr	spi information structure pointer
 * \param[in]	freq		spi working frequence
 * \param[in]	mode		spi working mode (master or slave)
 * \param[in]	method		working method(int or poll)
 * \retval	E_OK		open spi successfully
 * \retval	E_PAR		arguments passed was wrong
 * \retval	E_OPNED		spi was already opened
 * \retval	E_OBJ		spi has something error
 * \retval	<0		other error code not defined here
 */
int32_t dw_spi_open (DEV_SPI_INFO *spi_info_ptr, uint32_t freq, uint32_t mode, uint32_t method)
{
	int32_t ercd = E_OK;	/** error code to return, default E_OK */
	int32_t sck_divisor = 0;	/** sck divisor */
	DW_SPI_REG *spi_reg_ptr;	/** spi register structure */
	DW_SPI_CTRL *spi_ctrl_ptr;	/** spi control structure */

	/** check if spi structure available */
	DW_SPI_CHECK_EXP(spi_info_ptr!=NULL, E_PAR);
	/** check if input mode is valid */
	DW_SPI_CHECK_EXP((mode==DEV_MASTER_MODE)||(mode==DEV_SLAVE_MODE), E_PAR);
	/** check if input freq > 0 */
	DW_SPI_CHECK_EXP(freq>0, E_PAR);
	/** check if input method is valid */
	DW_SPI_CHECK_EXP((method==DEV_INTERRUPT_METHOD)||(method==DEV_POLL_METHOD), E_PAR);
	/** check if spi was closed, not opened before */
	DW_SPI_CHECK_EXP(spi_info_ptr->opn_flg==DEV_CLOSED, E_OPNED);
	/** check if spi was working good, not error */
	DW_SPI_CHECK_EXP(spi_info_ptr->err_flg==DEV_GOOD, E_OBJ);

	/** convert spi regbase to spi reg structure format */
	spi_reg_ptr = (DW_SPI_REG_PTR)(spi_info_ptr->spi_regs);
	/** convert to spi control structure */
	spi_ctrl_ptr = (DW_SPI_CTRL_PTR)(spi_info_ptr->spi_ctrl);

	/** init spi */
	spi_info_ptr->freq = freq;
	sck_divisor = DW_SPI_FREQ2DV(spi_ctrl_ptr->dw_apb_bus_freq, freq);
	/** calculate fifo length */
	spi_info_ptr->fifo_len = dw_spi_calc_fifolen(spi_reg_ptr);
	spi_ctrl_ptr->dw_spi_nbytes = 1;
	dw_spi_init(spi_reg_ptr, sck_divisor, spi_info_ptr->clock_mode);

	/**
	 * spi interrupt related init
	 */

	/** install spi interrupt into system */
	int_handler_install(spi_info_ptr->intno, spi_ctrl_ptr->dw_spi_int_handler);
	if (method == DEV_INTERRUPT_METHOD) {
		spi_info_ptr->method = DEV_INTERRUPT_METHOD;
		int_enable(spi_info_ptr->intno);	/** enable spi interrupt */
	} else { /** spi poll method setup */
		spi_info_ptr->method = DEV_POLL_METHOD;
	}
	spi_info_ptr->mode = mode;	/** set working mode */

	spi_info_ptr->opn_flg = DEV_OPENED;

error_exit:
	return ercd;
}

/**
 * \brief	close a DesignWare SPI device
 * \param[in]	spi_info_ptr	spi infomation structure pointer
 * \retval	E_OK		close spi successfully
 * \retval	E_PAR		arguments passed was wrong
 * \retval	E_CLSED		spi was already closed
 * \retval	E_OBJ		spi has something error
 * \retval	<0		other error code not defined here
 */
int32_t dw_spi_close (DEV_SPI_INFO *spi_info_ptr)
{
	int32_t ercd = E_OK;	/** error code to return, default E_OK */
	DW_SPI_REG *spi_reg_ptr;	/** spi register structure */

	/** check if spi structure available */
	DW_SPI_CHECK_EXP(spi_info_ptr!=NULL, E_PAR);
	/** check if spi was opened, not closed before */
	DW_SPI_CHECK_EXP(spi_info_ptr->opn_flg==DEV_OPENED, E_CLSED);

	/** convert spi regbase to spi reg structure format */
	spi_reg_ptr = (DW_SPI_REG_PTR)(spi_info_ptr->spi_regs);

	/* disable spi interrupt */
	int_disable(spi_info_ptr->intno);
	/** disable spi send&receive interrupt after disable spi interrupt */
	dw_spi_dis_cbr(spi_reg_ptr, DW_SPI_RDY_ALL);

	/**
	 * @todo may need to flush spi output here
	 * @todo may need to do software reset after flush
	 */
	/** set spi open flag to DEV_CLOSED */
	spi_info_ptr->opn_flg = DEV_CLOSED;
	/** clear spi error flag */
	spi_info_ptr->err_flg = DEV_GOOD;

error_exit:
	return ercd;
}

/**
 * \brief	control spi by ctrl command
 * \param[in]	spi_info_ptr	spi infomation structure pointer
 * \param[in]	ctrl_cmd	control command code to do specific spi work
 * \param[in,out]	param	parameters used to control spi or return something
 * \retval	E_OK		close spi successfully
 * \retval	E_PAR		arguments passed was wrong
 * \retval	E_OBJ		spi has something error, nothing can be done
 * \retval	E_CLSED		spi was closed, not available for control
 * \retval	<0		other error code not defined here
 */
int32_t dw_spi_control (DEV_SPI_INFO *spi_info_ptr, uint32_t ctrl_cmd, void *param)
{
	int32_t ercd = E_OK;		/** error code to return, default E_OK */
	volatile uint32_t val32;	/** to receive unsigned int value */
	int32_t sck_divisor = 0;	/** baudrate divisor */
	uint32_t temp = 0;
	uint8_t dummy_byte = 0xff;

	DW_SPI_REG *spi_reg_ptr;	/** spi register structure */
	DW_SPI_CTRL *spi_ctrl_ptr;	/** spi control structure */

	/** check if spi structure available */
	DW_SPI_CHECK_EXP(spi_info_ptr!=NULL, E_PAR);
	/** check if spi was opened to do following things */
	DW_SPI_CHECK_EXP(spi_info_ptr->opn_flg==DEV_OPENED, E_CLSED);
	/** check if spi was working good, not error */
	DW_SPI_CHECK_EXP(spi_info_ptr->err_flg==DEV_GOOD, E_OBJ);

	/** convert spi regbase to spi reg structure format */
	spi_reg_ptr = (DW_SPI_REG_PTR)(spi_info_ptr->spi_regs);
	/** convert to spi control structure */
	spi_ctrl_ptr = (DW_SPI_CTRL_PTR)(spi_info_ptr->spi_ctrl);

	switch (ctrl_cmd) {
		/**
		 * @todo may need work to do change baudrate.
		 * if need to disable and re-enable spi
		 */
		case SPI_CMD_CHG_FREQ:
			val32 = *((int32_t *)param); /** @note here must pass 4bytes aligned address */
			sck_divisor = DW_SPI_FREQ2DV(spi_ctrl_ptr->dw_apb_bus_freq, val32);
			if (sck_divisor != spi_reg_ptr->BAUDR) {
				/** set baudrate */
				spi_reg_ptr->SSIENR = DW_SPI_SSI_DISABLE;	/** spi disable */
				spi_reg_ptr->BAUDR = sck_divisor;
				spi_reg_ptr->SSIENR = DW_SPI_SSI_ENABLE;	/** spi enable */
			}
			/** update baudrate info in spi info struct */
			spi_info_ptr->freq = val32;
			break;
		case SPI_CMD_CHG_MTHD:
			/** get working method, only 1 bit */
			val32 = (*((int32_t *)param)) & 0x1; /** @note here must pass 4bytes aligned address */
			if (val32 == DEV_INTERRUPT_METHOD) {
				int_enable(spi_info_ptr->intno);	/** enable spi interrupt */
			} else {
				/* disable spi interrupt */
				int_disable(spi_info_ptr->intno);
				/** disable spi send&receive interrupt after disable spi interrupt */
				dw_spi_dis_cbr(spi_reg_ptr, DW_SPI_RDY_ALL);
			}
			spi_info_ptr->method = val32;
			break;
		case SPI_CMD_SEL_DEV:
			val32 = (*((int32_t *)param));
			val32 = (1 << val32);  /** select device bit */
			spi_reg_ptr->SER = val32;
			break;
		case SPI_CMD_DSEL_DEV:
			spi_reg_ptr->SER = 0;
			break;
		/** @todo need to realize flush spi output */
		case SPI_CMD_FLS_OUTP:
			while (spi_reg_ptr->RXFLR) {
				val32 = spi_reg_ptr->DATAREG;
			}
			break;
		/** change spi clock mode */
		case SPI_CMD_CHG_CLKMODE:
			val32 = *((int32_t *)param); /** @note here must pass 4bytes aligned address */
			val32 &= 0x3;
			/** set clock mode */
			temp = spi_reg_ptr->CTRLR0;
			if (((temp >> DW_SPI_CTRLR0_SC_OFS) & 0x3) != val32) {
				temp &= ~(0x3 << DW_SPI_CTRLR0_SC_OFS);
				spi_reg_ptr->SSIENR = DW_SPI_SSI_DISABLE;	/** spi disable */
				spi_reg_ptr->CTRLR0 = temp | (val32 << DW_SPI_CTRLR0_SC_OFS);
				spi_reg_ptr->SSIENR = DW_SPI_SSI_ENABLE;	/** spi enable */
			}
			/** update clock mode info in spi info struct */
			spi_info_ptr->clock_mode = val32;
			break;
		/** @todo need to realize dump spi information, may directly return to the para */
		case SPI_CMD_DMP_INFO:
			break;
		case SPI_CMD_TRANSFER:
			dw_spi_transfer(spi_info_ptr, (DEV_SPI_TRANSFER *)param);
			break;

		case SPI_CMD_SET_DUMMY_BYTE:
			dummy_byte = *((int8_t *)param);
			if (dummy_byte != spi_info_ptr->dummy_wr_byte) {
				spi_info_ptr->dummy_wr_byte = dummy_byte;
			}
			break;
		default:
			break;
	}

error_exit:
	return ercd;
}

/**
 * \brief	send data through DesignWare SPI
 * \param[in]	spi_info_ptr	spi infomation structure pointer
 * \param[in]	data		data that need to send (data must be char type)
 * \param[in]	len		data length need to send
 * \retval	>=0		data have been sent
 * \retval	E_PAR		arguments passed was wrong
 * \retval	E_OBJ		spi has something error, nothing can be done
 * \retval	E_CLSED		spi was closed, not available for control
 * \retval	<0		other error code not defined here
 */
int32_t dw_spi_write (DEV_SPI_INFO *spi_info_ptr, const void *data, uint32_t len)
{
	int32_t ercd = E_OK;	/** error code to return, default E_OK */

	volatile uint32_t transfer_end = 0;
	uint32_t transfer_cnt = 0;
	volatile uint32_t wri_cnt = 0;
	volatile uint32_t rea_cnt = 0;
	volatile int32_t rcv_dat; /** just for send/receive control */
	volatile int32_t snd_dat;

	const char *p_charbuf = (const char *)data; /** convert void buffer to char buffer */

	DW_SPI_REG *spi_reg_ptr;	/** spi register structure */
	DW_SPI_CTRL *spi_ctrl_ptr;	/** spi control structure */

	/** check if spi structure available */
	DW_SPI_CHECK_EXP(spi_info_ptr!=NULL, E_PAR);
	/** check if spi was opened to do following things */
	DW_SPI_CHECK_EXP(spi_info_ptr->opn_flg==DEV_OPENED, E_CLSED);
	/** check if spi was working good, not error */
	DW_SPI_CHECK_EXP(spi_info_ptr->err_flg==DEV_GOOD, E_OBJ);

	/** convert spi regbase to spi reg structure format */
	spi_reg_ptr = (DW_SPI_REG_PTR)(spi_info_ptr->spi_regs);
	/** convert spi control address to spi control structure format */
	spi_ctrl_ptr = (DW_SPI_CTRL_PTR)(spi_info_ptr->spi_ctrl);

	if (spi_info_ptr->method == DEV_INTERRUPT_METHOD) { /* Interrupt Method Send */
		/** @todo need to realize spi send in interrupt method */

	} else { /* Poll Method Send */
		transfer_cnt = len;
		transfer_end = 0, wri_cnt = 0, rea_cnt = 0;
		while ((!transfer_end) && transfer_cnt) {
			/** fill in send fifo when not full and with data need to send */
			while ((wri_cnt < transfer_cnt) && dw_spi_putready(spi_reg_ptr)) {
				if (dw_spi_getready(spi_reg_ptr)) {
					break; /* here go to receive because data is going to overflow */
				}
				snd_dat = p_charbuf[wri_cnt];
				dw_spi_snd_dat(spi_reg_ptr, snd_dat);
				wri_cnt ++;
			}
			if (dw_spi_getready(spi_reg_ptr)) {
				while (spi_reg_ptr->RXFLR) {
					rcv_dat = dw_spi_rcv_dat(spi_reg_ptr);
					rea_cnt ++;
					if (rea_cnt >= transfer_cnt) {
						transfer_end = 1; /* end transfer here */
						break; /* break loop out */
					}
				}
			}
		}
	}
	ercd = wri_cnt; /* get char send count */
error_exit:
	return ercd;
}

/**
 * \brief	read data through DesignWare SPI
 * \param[in]	spi_info_ptr	spi infomation structure pointer
 * \param[out]	data		data that need to read (data must be char type)
 * \param[in]	len		data count need to read
 * \retval	>=0		data have been read
 * \retval	E_PAR		arguments passed was wrong
 * \retval	E_OBJ		spi has something error, nothing can be done
 * \retval	E_CLSED		spi was closed, not available for control
 * \retval	<0		other error code not defined here
 */
int32_t dw_spi_read (DEV_SPI_INFO *spi_info_ptr, void *data, uint32_t len)
{
	int32_t ercd = E_OK;	/** error code to return, default E_OK */

	volatile uint32_t transfer_end = 0;
	uint32_t transfer_cnt = 0;
	volatile uint32_t wri_cnt = 0;
	volatile uint32_t rea_cnt = 0;
	volatile int32_t rcv_dat; /** just for send/receive control */
	volatile int32_t snd_dat;

	char *p_charbuf = (char *)data; /** convert void buffer to char buffer */

	DW_SPI_REG *spi_reg_ptr;	/** spi register structure */
	DW_SPI_CTRL *spi_ctrl_ptr;	/** spi control structure */


	/** check if spi structure available */
	DW_SPI_CHECK_EXP(spi_info_ptr!=NULL, E_PAR);
	/** check if spi was opened to do following things */
	DW_SPI_CHECK_EXP(spi_info_ptr->opn_flg==DEV_OPENED, E_CLSED);
	/** check if spi was working good, not error */
	DW_SPI_CHECK_EXP(spi_info_ptr->err_flg==DEV_GOOD, E_OBJ);

	/** convert spi regbase to spi reg structure format */
	spi_reg_ptr = (DW_SPI_REG_PTR)(spi_info_ptr->spi_regs);
	/** convert spi control address to spi control structure format */
	spi_ctrl_ptr = (DW_SPI_CTRL_PTR)(spi_info_ptr->spi_ctrl);

	if (spi_info_ptr->method == DEV_INTERRUPT_METHOD) { /* Interrupt Method Receive */
		/** @todo need to realize spi receive in interrupt method */

	} else { /* Poll Method Receive */
		transfer_cnt = len;
		transfer_end = 0, wri_cnt = 0, rea_cnt = 0;
		snd_dat = spi_info_ptr->dummy_wr_byte;
		while ((!transfer_end) && transfer_cnt) {
			/** fill in send fifo when not full and with data need to send */
			while ((wri_cnt < transfer_cnt) && dw_spi_putready(spi_reg_ptr)) {
				if (dw_spi_getready(spi_reg_ptr)) {
					break; /* here go to receive because data is going to overflow */
				}
				dw_spi_snd_dat(spi_reg_ptr, snd_dat);
				wri_cnt ++;
			}
			if (dw_spi_getready(spi_reg_ptr)) {
				while (spi_reg_ptr->RXFLR) {
					rcv_dat = dw_spi_rcv_dat(spi_reg_ptr);
					p_charbuf[rea_cnt++] = rcv_dat;
					if (rea_cnt >= transfer_cnt) {
						transfer_end = 1; /* end transfer here */
						break; /* break loop out */
					}
				}
			}
		}
	}
	ercd = rea_cnt; /* get char send count */
error_exit:
	return ercd;
}

static inline uint32_t min(uint32_t x, uint32_t y)
{
	return x < y ? x : y;
}

static void dw_spi_transfer(DEV_SPI_INFO *spi_info_ptr, DEV_SPI_TRANSFER *xfer)
{
	DW_SPI_REG *spi_reg_ptr;	/** spi register structure */
	uint32_t tx_end;
	uint32_t rx_end;
	uint32_t total_cnt;

	uint32_t total_wri_cnt;
	uint32_t total_rea_cnt;
	uint32_t xfer_wri_cnt, xfer_wri_num, xfer_wri_total;
	uint32_t xfer_rea_cnt, xfer_rea_num, xfer_rea_ofs, xfer_rea_total;

	uint32_t i;
	uint8_t rcv_dat;
	uint8_t *p_rcv_dat;
	uint8_t *p_snd_dat;
	DEV_SPI_TRANSFER *snd_xfer, *rcv_xfer;

	snd_xfer = xfer;
	rcv_xfer = xfer;

	spi_reg_ptr = (DW_SPI_REG_PTR)(spi_info_ptr->spi_regs);

	total_wri_cnt = 0;
	total_rea_cnt = 0;

	tx_end = 1;
	rx_end = 1;

	total_cnt = calc_transfer_cnt(xfer);

	while (total_rea_cnt < total_cnt) {
	/* write */
		i =  min(total_cnt - total_wri_cnt, (spi_info_ptr->fifo_len - spi_reg_ptr->TXFLR));
		while (i--) {
			if (tx_end) {
				tx_end = 0;
				xfer_wri_cnt = 0;
				if (snd_xfer != NULL) {
					p_snd_dat = (uint8_t *)snd_xfer->snd_buf;
					xfer_wri_num = snd_xfer->snd_cnt;
					xfer_wri_total = snd_xfer->xfer_cnt;
				} else {
					xfer_wri_num = 0;
					xfer_wri_total = 0;
				}
			}
			if (xfer_wri_cnt < xfer_wri_num) {
				dw_spi_putdata(spi_reg_ptr, p_snd_dat[xfer_wri_cnt]);
			} else {
				dw_spi_putdata(spi_reg_ptr, 0xff);
			}
			total_wri_cnt++;
			xfer_wri_cnt++;
			if ((snd_xfer != NULL) && (xfer_wri_cnt >= xfer_wri_total)){
				snd_xfer = snd_xfer->next;
				tx_end = 1;
			}
			// if (spi_reg_ptr->SR & DW_SPI_SSI_SR_RFF) {  receive fifo full go to receive it
			// 	break; /* here go to receive because data is going to overflow */
			// }
		}
	/* read */
		i = min(total_cnt - total_rea_cnt, spi_reg_ptr->RXFLR);
		//xprintf("rcv: %d\n", i);
		while (i--)	{
			if (rx_end == 1) {
				rx_end = 0;
				xfer_rea_cnt = 0;
				if (rcv_xfer != NULL) {
					xfer_rea_ofs = rcv_xfer->rcv_ofs;
					xfer_rea_num = rcv_xfer->rcv_cnt;
					xfer_rea_total = rcv_xfer->xfer_cnt;
					p_rcv_dat = (uint8_t *)rcv_xfer->rcv_buf;
				} else {
					xfer_rea_num = 0;
					xfer_rea_ofs = 0;
					xfer_rea_total = 0;
				}
			}
			rcv_dat = dw_spi_getdata(spi_reg_ptr);
			total_rea_cnt++;

			if (xfer_rea_cnt >= xfer_rea_ofs && xfer_rea_cnt < xfer_rea_num) {
				*p_rcv_dat = rcv_dat;
				p_rcv_dat++;
			}
			xfer_rea_cnt++;
			if ((rcv_xfer != NULL) && (xfer_rea_cnt >= xfer_rea_total)) {
				rcv_xfer = rcv_xfer->next;
				rx_end = 1;
			}
			//if (spi_reg_ptr->SR & DW_SPI_SSI_SR_TFE) {  //send fifo empty go to send it
			// 	break; /* here go to send because data is going to be empty */
			//}
		}
	}
}

/**
 * \brief	DesignWare SPI interrupt processing routine
 * \param[in]	spi_info_ptr	DEV_SPI_INFO *spi_info_ptr
 * \param[in]	ptr		extra information
 */
void dw_spi_isr(DEV_SPI_INFO *spi_info_ptr, void *ptr)
{


error_exit:
	return;
}
/** @} */ /* DEVICE_DW_SPI_IMPLEMENT */

/**
 * \brief	init designware spi with selected baud
 * \param[in]	spi_reg_ptr	spi register structure pointer
 * \param[in]	sck_divisor	ssi clock divider
 * \retval	E_OK		init success
 * \retval	E_PAR		arguments passed was wrong
 * \retval	<0		other error code not defined here
 */
static int32_t dw_spi_init (DW_SPI_REG *spi_reg_ptr, uint32_t sck_divisor, uint32_t clock_mode)
{
	int32_t ercd = E_OK;	/** error code to return, default E_OK */

	/** check if spi register structure available */
	DW_SPI_CHECK_EXP(spi_reg_ptr!=NULL, E_PAR);

	/** disable spi operations, then program spi control regs is possible */
	spi_reg_ptr->SSIENR = DW_SPI_SSI_DISABLE;

	/**
	 * dfs:8, tmod:transmit&receive, scpol:high,
	 * scph:clock toggles at start of first data bit
	 */
	spi_reg_ptr->CTRLR0 = (DW_SPI_CTRLR0_DFS_8|(DW_SPI_SPI_TRANSMIT_RECEIVE_MODE<<DW_SPI_SPI_TRANS_MODE_OFS)| \
				((clock_mode & 0x3) << DW_SPI_CTRLR0_SC_OFS));
	spi_reg_ptr->CTRLR1 = 0x0;	/** numbber of data frames set to 0 */

	/**
	 * setting spi baudrate registers
	 */
	spi_reg_ptr->BAUDR = sck_divisor;	/*!< sckdv set */

	/** transmit & receive fifo threshold level settings */
	spi_reg_ptr->TXFTLR = 0;
	spi_reg_ptr->RXFTLR = 0;

	spi_reg_ptr->IMR = DW_SPI_SSI_DISABLE_INT;	/** mask all spi interrupts */

	spi_reg_ptr->SSIENR = DW_SPI_SSI_ENABLE;	/** enable spi */

error_exit:
	return ercd;
}

/**
 * \brief	disable designware spi send or receive interrupt
 * \param[in]	spi_reg_ptr	spi register structure pointer
 * \param[in]	cbrtn		control code of callback routine of send or receive
 * \retval	E_OK		disable selected interrupt callback successfully
 * \retval	E_PAR		arguments passed was wrong
 * \retval	<0		other error code not defined here
 */
static int32_t dw_spi_dis_cbr (DW_SPI_REG *spi_reg_ptr, uint32_t cbrtn)
{
	int32_t ercd = E_OK;	/** error code to return, default E_OK */

	/** check if spi register structure available */
	DW_SPI_CHECK_EXP(spi_reg_ptr!=NULL, E_PAR);

	switch (cbrtn) {
		case DW_SPI_RDY_SND:
			spi_reg_ptr->IMR &= ~DW_SPI_IMR_ENABLE_RX_INT;
			break;
		case DW_SPI_RDY_RCV:
			spi_reg_ptr->IMR &= ~DW_SPI_IMR_ENABLE_TX_INT;
			break;
		case DW_SPI_RDY_ALL:
			spi_reg_ptr->IMR = DW_SPI_SSI_DISABLE_INT;
			break;
		default:
			break;
	}
error_exit:
	return ercd;
}

/**
 * \brief	enable DesignWare SPI send or receive interrupt
 * \param[in]	spi_reg_ptr	spi register structure pointer
 * \param[in]	cbrtn		control code of callback routine of send or receive
 * \retval	E_OK		enable selected interrupt callback successfully
 * \retval	E_PAR		arguments passed was wrong
 * \retval	<0		other error code not defined here
 */
static int32_t dw_spi_ena_cbr (DW_SPI_REG *spi_reg_ptr, uint32_t cbrtn)
{
	int32_t ercd = E_OK;	/** error code to return, default E_OK */

	/** check if spi register structure available */
	DW_SPI_CHECK_EXP(spi_reg_ptr!=NULL, E_PAR);

	switch (cbrtn) {
		case DW_SPI_RDY_SND:
			spi_reg_ptr->IMR |= DW_SPI_IMR_ENABLE_RX_INT;
			break;
		case DW_SPI_RDY_RCV:
			spi_reg_ptr->IMR |= DW_SPI_IMR_ENABLE_TX_INT;
			break;
		case DW_SPI_RDY_ALL:
			spi_reg_ptr->IMR = DW_SPI_SSI_ENABLE_INT;
			break;
		default:
			break;
	}
error_exit:
	return ercd;
}

/** @} */ /* DEVICE_DW_SPI */
