/* ------------------------------------------
 * Copyright (c) 2015, Synopsys, Inc. All rights reserved.

 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:

 * 1) Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.

 * 2) Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation and/or
 * other materials provided with the distribution.

 * 3) Neither the name of the Synopsys, Inc., nor the names of its contributors may
 * be used to endorse or promote products derived from this software without
 * specific prior written permission.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * \version 2015.05
 * \date 2014-06-20
 * \author Huaqi Fang(Huaqi.Fang@synopsys.com)
--------------------------------------------- */

/**
 * \defgroup	DEVICE_DW_UART	Designware UART Driver
 * \ingroup	DEVICE_DW
 * \brief	Designware UART Driver Implementation
 */

/**
 * \file
 * \ingroup	DEVICE_DW_UART
 * \brief	DesignWare UART driver implemention based on device hal layer definition(\ref dev_uart.h)
 */

#include "embARC_toolchain.h"
#include "embARC_error.h"

#include "arc_exception.h"

#include "dw_uart_hal.h"
#include "dw_uart.h"
#ifdef OS_CONTIKI
#include "serial-line.h"
#endif

/**
 * \name	DesignWare UART Driver Macros
 * \brief	DesignWare UART driver macros used in uart driver
 * @{
 */
/** check expressions used in DesignWare UART driver implemention */
#define DW_UART_CHECK_EXP(EXPR, ERROR_CODE)		CHECK_EXP(EXPR, ercd, ERROR_CODE, error_exit)

/** convert DesignWare baudrate to divisor */
#define DW_UART_BAUD2DIV(perifreq, baud)		((perifreq) / ((baud)*16))

/** parity disable, 1 stop bit, 8 bits data length in LCR register */
#define DW_UART_LCR0PEN_1STOP_8DLS			(DW_UART_LCR_PARITY_NONE|DW_UART_LCR_WORD_LEN8|DW_UART_LCR_1_STOP_BIT)

/**
 * \name	DesignWare UART Interrupt Callback Routine Select Marcos
 * \brief	DesignWare UART interrupt callback routines select macros definitions
 * @{
 */
#define DW_UART_RDY_SND					(1U)	/*!< ready to send callback */
#define DW_UART_RDY_RCV					(2U)	/*!< ready to receive callback */
/** @} */

/** @} */

/** DesignWare UART Functions Declaration */
static int32_t dw_uart_init (DW_UART_REG *uart_reg_ptr, uint32_t baud_divisor);
static int32_t dw_uart_dis_cbr (DW_UART_REG *uart_reg_ptr, uint32_t cbrtn);
static int32_t dw_uart_ena_cbr (DW_UART_REG *uart_reg_ptr, uint32_t cbrtn);

/**
 * \defgroup	DEVICE_DW_UART_INLINE	DesignWare UART Inline Functions
 * \ingroup	DEVICE_DW_UART
 * \brief	inline functions for DesignWare UART handle uart operations,
 * 	only used in \ref dw_uart.c
 * @{
 */
/** test whether uart is ready to send, 1 ready, 0 not ready */
Inline int32_t dw_uart_putready(DW_UART_REG *uart_reg_ptr)
{
	return ((uart_reg_ptr->USR & DW_UART_USR_TFNF) != 0);
}
/** test whether uart is read to receive, 1 ready, 0 not ready */
Inline int32_t dw_uart_getready(DW_UART_REG *uart_reg_ptr)
{
	return ((uart_reg_ptr->USR & DW_UART_USR_RFNE) != 0);
}
/** write char to uart send fifo */
Inline void dw_uart_putchar(DW_UART_REG *uart_reg_ptr, char chr)
{
	uart_reg_ptr->DATA = chr;
}
/** read data from uart receive fifo, return data received */
Inline int32_t dw_uart_getchar(DW_UART_REG *uart_reg_ptr)
{
	return (int32_t)uart_reg_ptr->DATA;
}
/**
 * \brief	send char by uart when available,
 * 	mostly used in interrupt method, non-blocked function
 * \param[in]	uart_reg_ptr	uart register structure pointer
 * \param[in]	chr		char to be sent
 * \retval	E_OK		send successfully
 * \retval	E_OBJ		not ready to send data
 */
Inline int32_t dw_uart_snd_chr(DW_UART_REG *uart_reg_ptr, char chr)
{
	if (dw_uart_putready(uart_reg_ptr)) {
		dw_uart_putchar(uart_reg_ptr, chr);
		return E_OK;
	}
	return E_OBJ;
}
/**
 * \brief	receive one char from uart,
 * 	mostly used in interrupt routine, non-blocked function
 * \param[in]	uart_reg_ptr	uart register structure pointer
 * \return	data received by the uart
 */
Inline int32_t dw_uart_rcv_chr(DW_UART_REG *uart_reg_ptr)
{
	return dw_uart_getchar(uart_reg_ptr);
}
/**
 * \brief	send char by uart in poll method, blocked function
 * \param[in]	uart_reg_ptr	uart register structure pointer
 * \param[in]	chr		char to be sent
 */
Inline void dw_uart_psnd_chr(DW_UART_REG *uart_reg_ptr, char chr)
{
	/** wait until uart is ready to send */
	while (!dw_uart_putready(uart_reg_ptr)); /* blocked */
	/** send char */
	dw_uart_putchar(uart_reg_ptr, chr);
}
/**
 * \brief	receive one char from uart in poll method, blocked function
 * \param[in]	uart_reg_ptr	uart register structure pointer
 * \return	data received by the uart
 */
Inline int32_t dw_uart_prcv_chr(DW_UART_REG *uart_reg_ptr)
{
	/** wait until uart is ready to receive */
	while (!dw_uart_getready(uart_reg_ptr)); /* blocked */
	/** receive data */
	return dw_uart_getchar(uart_reg_ptr);
}

/** @} */

/**
 * \brief	DesignWare UART get information by commands
 * \param[in]	uart_info_ptr	uart information structure pointer
 * \param[in]	cmd		command used by this function
 * \param[out]	rinfo		information return of this command
 * \retval
 */
int32_t dw_uart_get_info (DEV_UART_INFO *uart_info_ptr, uint32_t cmd, void *rinfo)
{
	int32_t ercd = E_OK;

	DW_UART_CHECK_EXP(uart_info_ptr!=NULL, E_PAR);

error_exit:
	return ercd;
}

/**
 * \brief	open a designware uart device
 * \param[in]	uart_info_ptr	uart information structure pointer
 * \param[in]	baud		baudrate to initialized
 * \param[in]	method		working method(int or poll)
 * \retval	E_OK		open uart successfully
 * \retval	E_PAR		arguments passed was wrong
 * \retval	E_OPNED		uart was already opened
 * \retval	E_OBJ		uart has something error
 * \retval	<0		other error code not defined here
 */
int32_t dw_uart_open (DEV_UART_INFO *uart_info_ptr, uint32_t baud, uint32_t method)
{
	int32_t ercd = E_OK;	/** error code to return, default E_OK */
	int32_t baud_divisor = 0;	/** baudrate divisor */
	DW_UART_REG *uart_reg_ptr;	/** uart register structure */
	DW_UART_CTRL *uart_ctrl_ptr;	/** uart control structure */

	/** check if uart structure available */
	DW_UART_CHECK_EXP(uart_info_ptr!=NULL, E_PAR);
	/** check if input method is valid */
	DW_UART_CHECK_EXP((method==DEV_INTERRUPT_METHOD)||(method==DEV_POLL_METHOD), E_PAR);
	/** check if uart was closed, not opened before */
	DW_UART_CHECK_EXP(uart_info_ptr->opn_flg==DEV_CLOSED, E_OPNED);
	/** check if uart was working good, not error */
	DW_UART_CHECK_EXP(uart_info_ptr->err_flg==DEV_GOOD, E_OBJ);


	/** convert uart regbase to uart reg structure format */
	uart_reg_ptr = (DW_UART_REG_PTR)(uart_info_ptr->uart_regs);
	/** convert to uart control structure */
	uart_ctrl_ptr = (DW_UART_CTRL_PTR)(uart_info_ptr->uart_ctrl);

	/** init uart */
	uart_info_ptr->baudrate = baud;
	baud_divisor = DW_UART_BAUD2DIV(uart_ctrl_ptr->dw_apb_bus_freq, baud);
	dw_uart_init(uart_reg_ptr, baud_divisor);

	/**
	 * uart interrupt related init
	 */

	/** install uart interrupt into system */
	int_handler_install(uart_info_ptr->intno, uart_ctrl_ptr->dw_uart_int_handler);
	if (method == DEV_INTERRUPT_METHOD) {
		uart_info_ptr->method = DEV_INTERRUPT_METHOD;
		int_enable(uart_info_ptr->intno);	/** enable uart interrupt */
		dw_uart_ena_cbr(uart_reg_ptr, DW_UART_RDY_RCV);	/** enable uart receive interrupt */
	} else { /** uart poll method setup */
		uart_info_ptr->method = DEV_POLL_METHOD;
	}
	/** set uart io ctrl to null, if you want to change use uart_control */
	uart_info_ptr->ioctl = UART_IOCTL_NULL;

	uart_info_ptr->opn_flg = DEV_OPENED;

	/** default block read */
	uart_info_ptr->read_mode = 0;

error_exit:
	return ercd;
}

/**
 * \brief	close a DesignWare UART device
 * \param[in]	uart_info_ptr	uart infomation structure pointer
 * \retval	E_OK		close uart successfully
 * \retval	E_PAR		arguments passed was wrong
 * \retval	E_CLSED		uart was already closed
 * \retval	E_OBJ		uart has something error
 * \retval	<0		other error code not defined here
 */
int32_t dw_uart_close (DEV_UART_INFO *uart_info_ptr)
{
	int32_t ercd = E_OK;	/** error code to return, default E_OK */
	DW_UART_REG *uart_reg_ptr;	/** uart register structure */

	/** check if uart structure available */
	DW_UART_CHECK_EXP(uart_info_ptr!=NULL, E_PAR);
	/** check if uart was opened, not closed before */
	DW_UART_CHECK_EXP(uart_info_ptr->opn_flg==DEV_OPENED, E_CLSED);

	/** convert uart regbase to uart reg structure format */
	uart_reg_ptr = (DW_UART_REG_PTR)(uart_info_ptr->uart_regs);

	/* disable uart interrupt */
	int_disable(uart_info_ptr->intno);
	/** disable uart send&receive interrupt after disable uart interrupt */
	dw_uart_dis_cbr(uart_reg_ptr, DW_UART_RDY_SND);
	dw_uart_dis_cbr(uart_reg_ptr, DW_UART_RDY_RCV);

	/**
	 * @todo may need to flush uart output here
	 * @todo may need to do software reset after flush
	 */
	/** set uart open flag to DEV_CLOSED */
	uart_info_ptr->opn_flg = DEV_CLOSED;
	/** clear uart error flag */
	uart_info_ptr->err_flg = DEV_GOOD;

error_exit:
	return ercd;
}

/**
 * \brief	control uart by ctrl command
 * \param[in]	uart_info_ptr	uart infomation structure pointer
 * \param[in]	ctrl_cmd	control command code to do specific uart work
 * \param[in,out]	param	parameters used to control uart or return something
 * \retval	E_OK		close uart successfully
 * \retval	E_PAR		arguments passed was wrong
 * \retval	E_OBJ		uart has something error, nothing can be done
 * \retval	E_CLSED		uart was closed, not available for control
 * \retval	<0		other error code not defined here
 */
int32_t dw_uart_control (DEV_UART_INFO *uart_info_ptr, uint32_t ctrl_cmd, void *param)
{
	int32_t ercd = E_OK;	/** error code to return, default E_OK */
	uint32_t val32;		/** to receive unsigned int value */
	int32_t baud_divisor = 0;	/** baudrate divisor */

	DW_UART_REG *uart_reg_ptr;	/** uart register structure */
	DW_UART_CTRL *uart_ctrl_ptr;	/** uart control structure */

	/** check if uart structure available */
	DW_UART_CHECK_EXP(uart_info_ptr!=NULL, E_PAR);
	/** check if uart was opened to do following things */
	DW_UART_CHECK_EXP(uart_info_ptr->opn_flg==DEV_OPENED, E_CLSED);
	/** check if uart was working good, not error */
	DW_UART_CHECK_EXP(uart_info_ptr->err_flg==DEV_GOOD, E_OBJ);

	/** convert uart regbase to uart reg structure format */
	uart_reg_ptr = (DW_UART_REG_PTR)(uart_info_ptr->uart_regs);
	/** convert to uart control structure */
	uart_ctrl_ptr = (DW_UART_CTRL_PTR)(uart_info_ptr->uart_ctrl);

	switch (ctrl_cmd) {
		/**
		 * @todo may need work to do change baudrate.
		 * if need to disable and re-enable uart
		 */
		case UART_CMD_CHG_BAUD:
			val32 = *((int32_t *)param); /** @note here must pass 4bytes aligned address */
			baud_divisor = DW_UART_BAUD2DIV(uart_ctrl_ptr->dw_apb_bus_freq, val32);
			/** set baudrate */
			uart_reg_ptr->LCR |= DW_UART_LCR_DLAB;	/** dlab enable */
			uart_reg_ptr->DATA = baud_divisor & 0xff;
			uart_reg_ptr->IER = (baud_divisor>>8) & 0xff;
			uart_reg_ptr->LCR &= ~DW_UART_LCR_DLAB;	/** dlab disable */
			/** update baudrate info in uart info struct */
			uart_info_ptr->baudrate = val32;
			break;
		case UART_CMD_CHG_MTHD:
			/** get working method, only 1 bit */
			val32 = (*((int32_t *)param)) & 0x1; /** @note here must pass 4bytes aligned address */
			if (val32 == DEV_INTERRUPT_METHOD) {
				int_enable(uart_info_ptr->intno);	/** enable uart interrupt */
				dw_uart_ena_cbr(uart_reg_ptr, DW_UART_RDY_RCV);	/** enable uart receive interrupt */
			} else {
				/* disable uart interrupt */
				int_disable(uart_info_ptr->intno);
				/** disable uart send&receive interrupt after disable uart interrupt */
				dw_uart_dis_cbr(uart_reg_ptr, DW_UART_RDY_SND);
				dw_uart_dis_cbr(uart_reg_ptr, DW_UART_RDY_RCV);
			}
			uart_info_ptr->method = val32;
			break;
		/** @todo need to realize flush uart output */
		case UART_CMD_FLS_OUTP:
			break;
		/** @todo need to realize dump uart information, may directly return to the para */
		case UART_CMD_DMP_INFO:
			break;
		case UART_CMD_CHG_IOCTL:
			/** get ioctl code */
			val32 = *((int32_t *)param); /** @note here must pass 4bytes aligned address */
			uart_info_ptr->ioctl = val32;
			break;
		case UART_CMD_SET_READ_MODE:
			/** get ioctl code */
			val32 = *((int32_t *)param); /** @note here must pass 4bytes aligned address */
			uart_info_ptr->read_mode = val32;
			break;
		default:
			break;
	}

error_exit:
	return ercd;
}

/**
 * \brief	send data through DesignWare UART
 * \param[in]	uart_info_ptr	uart infomation structure pointer
 * \param[in]	data		data that need to send (data must be char type)
 * \param[in]	len		data length need to send
 * \retval	>=0		data have been sent
 * \retval	E_PAR		arguments passed was wrong
 * \retval	E_OBJ		uart has something error, nothing can be done
 * \retval	E_CLSED		uart was closed, not available for control
 * \retval	<0		other error code not defined here
 */
int32_t dw_uart_write (DEV_UART_INFO *uart_info_ptr, const void *data, uint32_t len)
{
	int32_t ercd = E_OK;	/** error code to return, default E_OK */
	int32_t wricnt = 0;	/** data send count */
	uint8_t crlf_snd = 1, crlf_snd_save = 1;
	uint8_t buffer_full = true;	/** send ringbuffer full flag */
	uint8_t break_flag = false;	/** interrupt method send loop break flag */
	char sndchr = 0;		/** the char to to send get from the send data buffer */

	unsigned int int_status_saved;	/** saved interrupt state to restore */

	const char *p_charbuf = (const char *)data; /** convert void buffer to char buffer */

	DW_UART_REG *uart_reg_ptr;	/** uart register structure */
	DW_UART_CTRL *uart_ctrl_ptr;	/** uart control structure */

	/** check if uart structure available */
	DW_UART_CHECK_EXP(uart_info_ptr!=NULL, E_PAR);
	/** check if uart was opened to do following things */
	DW_UART_CHECK_EXP(uart_info_ptr->opn_flg==DEV_OPENED, E_CLSED);
	/** check if uart was working good, not error */
	DW_UART_CHECK_EXP(uart_info_ptr->err_flg==DEV_GOOD, E_OBJ);

	/** convert uart regbase to uart reg structure format */
	uart_reg_ptr = (DW_UART_REG_PTR)(uart_info_ptr->uart_regs);
	/** convert uart control address to uart control structure format */
	uart_ctrl_ptr = (DW_UART_CTRL_PTR)(uart_info_ptr->uart_ctrl);

	if (uart_info_ptr->method == DEV_INTERRUPT_METHOD) { /* Interrupt Method Send */
		while ( (wricnt < len) && (break_flag == false) ) {
			crlf_snd_save = crlf_snd;
			if ( crlf_snd && (p_charbuf[wricnt] == '\n') && \
					((uart_info_ptr->ioctl & UART_IOCTL_CRLF) != 0) ) {
				sndchr = '\r'; /** need to send '\r' before '\n' here */
				crlf_snd = 0;  /** make it next loop no enter here */
			} else {
				sndchr = p_charbuf[wricnt];
				crlf_snd = 1; /* make it next loop enter here */
			}
			/** LOCK CPU HERE for RINGBUFFER OPERATION */
			int_status_saved = cpu_lock_save();
			if ( (rb_isempty(&(uart_ctrl_ptr->snd_rb)) == 1) && \
					(dw_uart_snd_chr(uart_reg_ptr, sndchr) == E_OK) ) {
				wricnt += crlf_snd;
				buffer_full = false;
			} else {
				if (rb_add(&(uart_ctrl_ptr->snd_rb), sndchr) != 0) {
					crlf_snd = crlf_snd_save;
					buffer_full = true;
					if (exc_sense()) { /** sense whether in exc/interrupt processing */
						break_flag = true; /* here break when called in interrupt */
					}
				} else {
					dw_uart_ena_cbr(uart_reg_ptr, DW_UART_RDY_SND);
					wricnt += crlf_snd;
					buffer_full = false;
				}
			}
			/** UNLOCK CPU HERE to restore orginal environment */
			cpu_unlock_restore(int_status_saved);
		}
	} else { /* Poll Method Send */
		while (wricnt < len) {
			/** check if char is '\n', if enabled UART_IOCTL_CRLF, send a '\r' before it */
			if ((p_charbuf[wricnt] == '\n') && \
					((uart_info_ptr->ioctl & UART_IOCTL_CRLF) != 0)) {
				dw_uart_psnd_chr(uart_reg_ptr, '\r'); /* send a 'r' before '\n' */
			}
			dw_uart_psnd_chr(uart_reg_ptr, p_charbuf[wricnt++]); /* poll send*/
		}
	}
	ercd = wricnt; /* get char send count */
error_exit:
	return ercd;
}

/**
 * \brief	read data through DesignWare UART
 * \param[in]	uart_info_ptr	uart infomation structure pointer
 * \param[out]	data		data that need to read (data must be char type)
 * \param[in]	len		data count need to read
 * \retval	>=0		data have been read
 * \retval	E_PAR		arguments passed was wrong
 * \retval	E_OBJ		uart has something error, nothing can be done
 * \retval	E_CLSED		uart was closed, not available for control
 * \retval	<0		other error code not defined here
 */
int32_t dw_uart_read (DEV_UART_INFO *uart_info_ptr, void *data, uint32_t len)
{
	int32_t ercd = E_OK;	/** error code to return, default E_OK */
	int32_t reacnt = 0;	/** data receive count */
	char *p_charbuf = (char *)data; /** convert void buffer to char buffer */

	uint8_t buffer_empty = true;	/** received buffer empty flag */
	uint8_t break_flag = false;	/** interrupt method send loop break flag */

	unsigned int int_status_saved;	/** saved interrupt state to restore */

	DW_UART_REG *uart_reg_ptr;	/** uart register structure */
	DW_UART_CTRL *uart_ctrl_ptr;	/** uart control structure */

	/** check if uart structure available */
	DW_UART_CHECK_EXP(uart_info_ptr!=NULL, E_PAR);
	/** check if uart was opened to do following things */
	DW_UART_CHECK_EXP(uart_info_ptr->opn_flg==DEV_OPENED, E_CLSED);
	/** check if uart was working good, not error */
	DW_UART_CHECK_EXP(uart_info_ptr->err_flg==DEV_GOOD, E_OBJ);

	/** convert uart regbase to uart reg structure format */
	uart_reg_ptr = (DW_UART_REG_PTR)(uart_info_ptr->uart_regs);
	/** convert uart control address to uart control structure format */
	uart_ctrl_ptr = (DW_UART_CTRL_PTR)(uart_info_ptr->uart_ctrl);

	if (uart_info_ptr->method == DEV_INTERRUPT_METHOD) { /* Interrupt Method Receive */
		while ( (reacnt < len) && (break_flag == false) ) {
			/** LOCK CPU HERE for RINGBUFFER OPERATION */
			int_status_saved = cpu_lock_save();
			if (rb_remove(&(uart_ctrl_ptr->rcv_rb), &p_charbuf[reacnt]) != 0) {
				buffer_empty = true;
				if (exc_sense()) { /** sense whether in exc/interrupt processing */
					break_flag = true; /* here break when called in interrupt */
				} else {
					if (uart_info_ptr->read_mode) {
						break_flag = true;
					}
				}
			} else {
				reacnt ++;
				buffer_empty = false;
			}
			/** UNLOCK CPU HERE to restore orginal environment */
			cpu_unlock_restore(int_status_saved);
		}
	} else { /* Poll Method Receive */
		while (reacnt < len) {
			if (dw_uart_getready(uart_reg_ptr)) {
				p_charbuf[reacnt++] = dw_uart_getchar(uart_reg_ptr);
			} else {
				/** when non-block read mode, break loop */
				if (uart_info_ptr->read_mode) break;
			}
		}
	}
	ercd = reacnt; /* get char send count */
error_exit:
	return ercd;
}

/**
 * \brief	DesignWare UART interrupt processing routine
 * \param[in]	uart_info_ptr	DEV_UART_INFO *uart_info_ptr
 * \param[in]	ptr		extra information
 */
void dw_uart_isr (DEV_UART_INFO *uart_info_ptr, void *ptr)
{
	int32_t ercd = E_OK; 	/** error code to return, default E_OK */
	uint32_t uart_int_status; /** uart interrupt status */
	volatile uint32_t temp; /** read error status to clear interrupt */
	unsigned int int_status_saved; 	/** saved interrupt state to restore */
	char sndchr = 0;		/** send char */
	char rcvchr = 0;		/** receive char */

	DW_UART_REG *uart_reg_ptr;	/** uart register structure */
	DW_UART_CTRL *uart_ctrl_ptr; 	/** uart control structure */

	/** check if uart structure available */
	DW_UART_CHECK_EXP(uart_info_ptr!=NULL, E_PAR);
	/** check if uart was opened to do following things */
	DW_UART_CHECK_EXP(uart_info_ptr->opn_flg==DEV_OPENED, E_CLSED);
	/** check if uart was working good, not error */
	DW_UART_CHECK_EXP(uart_info_ptr->err_flg==DEV_GOOD, E_OBJ);

	/** convert uart regbase to uart reg structure format */
	uart_reg_ptr = (DW_UART_REG_PTR)(uart_info_ptr->uart_regs);
	/** convert uart control address to uart control structure format */
	uart_ctrl_ptr = (DW_UART_CTRL_PTR)(uart_info_ptr->uart_ctrl);

	/** get uart interrupt status */
	uart_int_status = (uart_reg_ptr->IIR) & DW_UART_IIR_INT_ID_MASK;

	switch (uart_int_status) {
		case DW_UART_IIR_MDM_STATUS:
			temp = (volatile uint32_t)(uart_reg_ptr->MSR);
			break;
		case DW_UART_IIR_LINE_STATUS:
			temp = (volatile uint32_t)(uart_reg_ptr->LSR);
			break;
		case DW_UART_IIR_XMIT_EMPTY:
			while (dw_uart_putready(uart_reg_ptr)) {
				/** LOCK CPU HERE for RINGBUFFER OPERATION */
				int_status_saved = cpu_lock_save();
				if (rb_remove(&(uart_ctrl_ptr->snd_rb), &sndchr) != 0) {
					dw_uart_dis_cbr(uart_reg_ptr, DW_UART_RDY_SND);
					/** UNLOCK CPU HERE to restore orginal environment */
					cpu_unlock_restore(int_status_saved);
					break;
				}
				/** UNLOCK CPU HERE to restore orginal environment */
				cpu_unlock_restore(int_status_saved);
				dw_uart_putchar(uart_reg_ptr, sndchr);
			}
			break;
		case DW_UART_IIR_RX_TIMEOUT:
			rcvchr = (char)dw_uart_getchar(uart_reg_ptr);
			break;
		case DW_UART_IIR_DATA_AVAIL:
			while (dw_uart_getready(uart_reg_ptr)) {
				rcvchr = (char)dw_uart_getchar(uart_reg_ptr);
				/** LOCK CPU HERE for RINGBUFFER OPERATION */
#ifdef OS_CONTIKI
				serial_line_input_byte(rcvchr);
#endif
				int_status_saved = cpu_lock_save();
				if (rb_add(&(uart_ctrl_ptr->rcv_rb), rcvchr) != 0) {
					/** UNLOCK CPU HERE to restore orginal environment */
					cpu_unlock_restore(int_status_saved);
					break;
				}
			}
			break;
		default:
			temp = (volatile uint32_t)(uart_reg_ptr->USR);
			break;
	}

error_exit:
	return;
}


/**
 * \brief	init designware uart with selected baud
 * \param[in]	uart_reg_ptr	uart register structure pointer
 * \param[in]	baud_divisor	baudrate divisor
 * \retval	E_OK		init success
 * \retval	E_PAR		arguments passed was wrong
 * \retval	<0		other error code not defined here
 */
static int32_t dw_uart_init (DW_UART_REG *uart_reg_ptr, uint32_t baud_divisor)
{
	int32_t ercd = E_OK;	/** error code to return, default E_OK */

	/** check if uart register structure available */
	DW_UART_CHECK_EXP(uart_reg_ptr!=NULL, E_PAR);

	/** do a software reset of uart */
	uart_reg_ptr->SRR = DW_UART_SRR_UR|DW_UART_SRR_RFR|DW_UART_SRR_XFR;

	uart_reg_ptr->MCR = 0;		/** modem control register init */
	uart_reg_ptr->IIR = 0x1;	/** enable uart fifo (FCR IIR is the same) */
	/**
	 * enable write baudrate reg(DLAB),
	 * 1 stop bit, parity disabled, 8bits length
	 */
	uart_reg_ptr->LCR = DW_UART_LCR_DLAB|DW_UART_LCR0PEN_1STOP_8DLS;
	/**
	 * setting uart baudrate registers
	 */
	uart_reg_ptr->DATA = baud_divisor & 0xff;	/*!< DLL */
	uart_reg_ptr->IER = (baud_divisor>>8) & 0xff;	/*!< DLH */
	/** disable DLAB */
	uart_reg_ptr->LCR = DW_UART_LCR0PEN_1STOP_8DLS;

	uart_reg_ptr->IER = 0x0;	/** disable all uart interrupt */

error_exit:
	return ercd;
}

/**
 * \brief	disable designware uart send or receive interrupt
 * \param[in]	uart_reg_ptr	uart register structure pointer
 * \param[in]	cbrtn		control code of callback routine of send or receive
 * \retval	E_OK		disable selected interrupt callback successfully
 * \retval	E_PAR		arguments passed was wrong
 * \retval	<0		other error code not defined here
 */
static int32_t dw_uart_dis_cbr (DW_UART_REG *uart_reg_ptr, uint32_t cbrtn)
{
	int32_t ercd = E_OK;	/** error code to return, default E_OK */

	/** check if uart register structure available */
	DW_UART_CHECK_EXP(uart_reg_ptr!=NULL, E_PAR);

	switch (cbrtn) {
		case DW_UART_RDY_SND:
			uart_reg_ptr->IER &= ~DW_UART_IER_XMIT_EMPTY;
			break;
		case DW_UART_RDY_RCV:
			uart_reg_ptr->IER &= ~DW_UART_IER_DATA_AVAIL;
			break;
		default:
			break;
	}
error_exit:
	return ercd;
}

/**
 * \brief	enable DesignWare UART send or receive interrupt
 * \param[in]	uart_reg_ptr	uart register structure pointer
 * \param[in]	cbrtn		control code of callback routine of send or receive
 * \retval	E_OK		enable selected interrupt callback successfully
 * \retval	E_PAR		arguments passed was wrong
 * \retval	<0		other error code not defined here
 */
static int32_t dw_uart_ena_cbr (DW_UART_REG *uart_reg_ptr, uint32_t cbrtn)
{
	int32_t ercd = E_OK;	/** error code to return, default E_OK */

	/** check if uart register structure available */
	DW_UART_CHECK_EXP(uart_reg_ptr!=NULL, E_PAR);

	switch (cbrtn) {
		case DW_UART_RDY_SND:
			uart_reg_ptr->IER |= DW_UART_IER_XMIT_EMPTY;
			break;
		case DW_UART_RDY_RCV:
			uart_reg_ptr->IER |= DW_UART_IER_DATA_AVAIL;
			break;
		default:
			break;
	}
error_exit:
	return ercd;
}