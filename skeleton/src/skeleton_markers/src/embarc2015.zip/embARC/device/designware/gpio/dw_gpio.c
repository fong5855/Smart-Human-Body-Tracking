/* ------------------------------------------
 * Copyright (c) 2015, Synopsys, Inc. All rights reserved.

 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:

 * 1) Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.

 * 2) Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation and/or
 * other materials provided with the distribution.

 * 3) Neither the name of the Synopsys, Inc., nor the names of its contributors may
 * be used to endorse or promote products derived from this software without
 * specific prior written permission.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * \version 2015.05
 * \date 2014-07-22
 * \author Wayne Ren(Wei.Ren@synopsys.com)
--------------------------------------------- */

/**
 * \defgroup	DEVICE_DW_GPIO	Designware GPIO Driver
 * \ingroup	DEVICE_DW
 * \brief	Designware GPIO Driver Implementation
 */

/**
 * \file
 * \brief	designware gpio driver
 * \ingroup	DEVICE_DW_GPIO
 * \brief	Designware GPIO driver
 */

#include "dw_gpio.h"


/** check expressions used in DesignWare UART driver implemention */
#define DW_GPIO_CHECK_EXP(EXPR, ERROR_CODE)		CHECK_EXP(EXPR, ercd, ERROR_CODE, error_exit)


/**
 * \brief set trigger of interrupt: level or edge
 *
 * \param port
 * \param bit_mask
 * \param level
 */
void dw_gpio_int_write_level(DW_GPIO_PORT_PTR port, uint32_t bit_mask, uint32_t level)
{
	uint32_t reg_val;

	reg_val = port->regs->INTTYPE_LEVEL;

	if (level == DW_GPIO_INT_LEVEL_TRIG) {
		reg_val &= (~bit_mask);
	} else {
		reg_val |= bit_mask;
	}
	port->regs->INTTYPE_LEVEL = reg_val;
}


/**
 * \brief
 *
 * \param port
 * \param bit_mask
 * \param pol
 */
void dw_gpio_int_write_polarity(DW_GPIO_PORT_PTR port, uint32_t bit_mask, uint32_t pol)
{
	uint32_t reg_val;

	reg_val = port->regs->INT_POLARITY;

	if (pol == DW_GPIO_INT_ACT_LOW) {
		reg_val &= (~bit_mask);
	} else {
		reg_val |= bit_mask;
	}
	port->regs->INT_POLARITY = reg_val;
}

void dw_gpio_write_dr(DW_GPIO_PORT_PTR port, uint32_t bit_mask, uint32_t val)
{
	uint32_t temp_reg;

	temp_reg = port->regs->SWPORTS[port->no].DR;
	temp_reg &= ~bit_mask;
	val &= bit_mask;
	temp_reg |= val;

	port->regs->SWPORTS[port->no].DR = temp_reg;
}

void dw_gpio_write_dir(DW_GPIO_PORT_PTR port, uint32_t bit_mask, uint32_t val)
{
	uint32_t temp_reg;

	temp_reg = port->regs->SWPORTS[port->no].DDR;
	temp_reg &= ~bit_mask;
	val &= bit_mask;
	temp_reg |= val;

	port->regs->SWPORTS[port->no].DDR = temp_reg;
}

/**
 * \brief
 *
 * \param port
 * \param bit_mask
 * \param debounce
 */
void dw_gpio_int_write_debounce(DW_GPIO_PORT_PTR port, uint32_t bit_mask, uint32_t debounce)
{
	uint32_t reg_val;

	reg_val = port->regs->DEBOUNCE;

	if (debounce == DW_GPIO_INT_NO_DEBOUNCE) {
		reg_val &= (~bit_mask);
	} else {
		reg_val |= bit_mask;
	}
	port->regs->DEBOUNCE = reg_val;

}

/* interface for DEV_GPIO */

/**
 * \brief
 *
 * \param port_info_ptr
 * \param cmd
 * \param rinfo
 *
 * \returns
 */
int32_t dw_gpio_get_info(DEV_GPIO_INFO *port_info_ptr, uint32_t cmd, void *rinfo)
{
	int32_t ercd = E_OK;

	DW_GPIO_PORT_PTR port;

	/** check if gpio structure available */
	DW_GPIO_CHECK_EXP(port_info_ptr!=NULL, E_PAR);
		/** check if gpio was opened to do following things */
	DW_GPIO_CHECK_EXP(port_info_ptr->opn_flg==DEV_OPENED, E_CLSED);
	/** check if gpio was working good, not error */
	DW_GPIO_CHECK_EXP(port_info_ptr->err_flg==DEV_GOOD, E_OBJ);

	port = (DW_GPIO_PORT_PTR)(port_info_ptr->gpio_ctrl);

	DW_GPIO_CHECK_EXP(port->no <= DW_GPIO_PORT_D, E_PAR);

	if (cmd == DW_GPIO_CMD_GETINFO_DIR)
	{
		port_info_ptr->direction = dw_gpio_read_dir(port);
		*((uint32_t *)rinfo) = dw_gpio_read_dir(port);
	} else {
		DW_GPIO_CHECK_EXP(port->no == DW_GPIO_PORT_A, E_PAR);
		switch (cmd) {
			case DW_GPIO_CMD_GETINFO_INT_PORLARITY:
				*((uint32_t *)rinfo) = dw_gpio_int_read_polarity(port);
				break;
			case DW_GPIO_CMD_GETINFO_INT_LEVEL:
				*((uint32_t *)rinfo) = dw_gpio_int_read_level(port);
				break;
			case DW_GPIO_CMD_GETINFO_INT_STATUS:
				*((uint32_t *)rinfo) = dw_gpio_int_read_status(port);
				break;
			case GPIO_CMD_GETINFO_INTBIT_MTHD:
				*((uint32_t *)rinfo) = dw_gpio_read_mthd(port);
				break;
			default:
				ercd = E_PAR;
				break;
		}
	}

error_exit:
	return ercd;
}

/**
 * \brief
 *
 * \param port_info_ptr
 * \param dir
 * \param method
 *
 * \returns
 */
int32_t dw_gpio_open(DEV_GPIO_INFO_PTR port_info_ptr, uint32_t dir, uint32_t method)
{
	int32_t ercd = E_OK;

	DW_GPIO_PORT_PTR port;

	/** check if gpio structure available */
	DW_GPIO_CHECK_EXP(port_info_ptr!=NULL, E_PAR);
	/** output pin cannot be used as interrupt */
	/** check if gpio was closed, not opened before */
	DW_GPIO_CHECK_EXP(port_info_ptr->opn_flg==DEV_CLOSED, E_OPNED);
	/** check if gpio was working good, not error */
	DW_GPIO_CHECK_EXP(port_info_ptr->err_flg==DEV_GOOD, E_OBJ);

	port = (DW_GPIO_PORT_PTR)(port_info_ptr->gpio_ctrl);

	/** when GPIO_A , can't set gpio as output & interrupt at the same time */
	DW_GPIO_CHECK_EXP( !( ((dir & method) != 0) && (port->no == DW_GPIO_PORT_A) ) , E_PAR);
	DW_GPIO_CHECK_EXP(port->no <= DW_GPIO_PORT_D, E_PAR);

	dw_gpio_write_dir(port, port->valid_bit_mask, dir);

	if (port->no == DW_GPIO_PORT_A) {
		dw_gpio_int_clear(port, 0xffffffff);
		dw_gpio_int_disable(port, 0xffffffff);
		dw_gpio_int_enable(port, method);
		/* install gpio interrupt handler */
		int_handler_install(port_info_ptr->intno, port->int_handler);
		if (method != 0) {
			int_enable(port_info_ptr->intno);
		}
		port_info_ptr->method = dw_gpio_read_mthd(port);
	} else {
		port_info_ptr->method = 0;
	}

	dw_gpio_write_dr(port, port->valid_bit_mask, 0);

	port_info_ptr->direction = dir;
	port_info_ptr->opn_flg = DEV_OPENED;
	port_info_ptr->err_flg = DEV_GOOD;

error_exit:
	return ercd;
}

/**
 * \brief
 *
 * \param port_info_ptr
 *
 * \returns
 */
int32_t dw_gpio_close(DEV_GPIO_INFO_PTR port_info_ptr)
{
	int32_t ercd = E_OK;

	DW_GPIO_PORT_PTR port;

	/** check if gpio structure available */
	DW_GPIO_CHECK_EXP(port_info_ptr!=NULL, E_PAR);
		/** check if gpio was opened to do following things */
	DW_GPIO_CHECK_EXP(port_info_ptr->opn_flg==DEV_OPENED, E_CLSED);

	port = (DW_GPIO_PORT_PTR)(port_info_ptr->gpio_ctrl);

	DW_GPIO_CHECK_EXP(port->no <= DW_GPIO_PORT_D, E_PAR);

	dw_gpio_write_dr(port, port->valid_bit_mask, 0);
	dw_gpio_write_dir(port, port->valid_bit_mask, 0);

	if (port->no == DW_GPIO_PORT_A) {
		dw_gpio_int_clear(port, 0xffffffff);
		dw_gpio_int_disable(port, 0xffffffff);
		int_disable(port_info_ptr->intno);
	}

	port_info_ptr->direction = 0;
	port_info_ptr->method = 0;
	port_info_ptr->opn_flg = DEV_CLOSED;
	port_info_ptr->err_flg = DEV_GOOD;

error_exit:
	return ercd;
}

/**
 * \brief
 *
 * \param port_info_ptr
 * \param val
 * \param mask
 *
 * \returns
 */
int32_t dw_gpio_read(DEV_GPIO_INFO_PTR port_info_ptr, uint32_t *val, uint32_t mask)
{
	int32_t ercd = E_OK;

	DW_GPIO_PORT_PTR port;

	/** check if gpio structure available */
	DW_GPIO_CHECK_EXP(port_info_ptr!=NULL, E_PAR);
	/** check if value pointer available */
	DW_GPIO_CHECK_EXP(val!=NULL, E_PAR);
	/** check if gpio was opened to do following things */
	DW_GPIO_CHECK_EXP(port_info_ptr->opn_flg==DEV_OPENED, E_CLSED);
	/** check if gpio was working good, not error */
	DW_GPIO_CHECK_EXP(port_info_ptr->err_flg==DEV_GOOD, E_OBJ);

	port = (DW_GPIO_PORT_PTR)(port_info_ptr->gpio_ctrl);

	DW_GPIO_CHECK_EXP(port->no <= DW_GPIO_PORT_D, E_PAR);

	*val = dw_gpio_read_ext(port) & mask;

error_exit:
	return ercd;
}

/**
 * \brief
 *
 * \param port_info_ptr
 * \param val
 * \param mask
 *
 * \returns
 */
int32_t dw_gpio_write(DEV_GPIO_INFO_PTR port_info_ptr, uint32_t val, uint32_t mask)
{
	int32_t ercd = E_OK;

	DW_GPIO_PORT_PTR port;

	/** check if gpio structure available */
	DW_GPIO_CHECK_EXP(port_info_ptr!=NULL, E_PAR);
	/** check if gpio was opened to do following things */
	DW_GPIO_CHECK_EXP(port_info_ptr->opn_flg==DEV_OPENED, E_CLSED);
	/** check if gpio was working good, not error */
	DW_GPIO_CHECK_EXP(port_info_ptr->err_flg==DEV_GOOD, E_OBJ);

	port = (DW_GPIO_PORT_PTR)(port_info_ptr->gpio_ctrl);

	DW_GPIO_CHECK_EXP(port->no <= DW_GPIO_PORT_D, E_PAR);

	dw_gpio_write_dr(port, mask, val);

error_exit:
	return ercd;
}


/**
 * \brief
 *
 * \param port_info_ptr
 * \param ctrl_cmd
 * \param param
 *
 * \returns
 */
int32_t dw_gpio_control(DEV_GPIO_INFO_PTR port_info_ptr, uint32_t ctrl_cmd, void *param)
{
	int32_t ercd = E_OK;
	uint32_t val32;	/** to receive unsigned int value */

	DEV_GPIO_INT_INFO *gpio_int_info;

	DW_GPIO_PORT_PTR port;
	DEV_GPIO_BIT_ISR *port_bit_isr;

	/** check if gpio structure available */
	DW_GPIO_CHECK_EXP(port_info_ptr!=NULL, E_PAR);
	/** check if gpio was opened to do following things */
	DW_GPIO_CHECK_EXP(port_info_ptr->opn_flg==DEV_OPENED, E_CLSED);
	/** check if gpio was working good, not error */
	DW_GPIO_CHECK_EXP(port_info_ptr->err_flg==DEV_GOOD, E_OBJ);

	port = (DW_GPIO_PORT_PTR)(port_info_ptr->gpio_ctrl);

	DW_GPIO_CHECK_EXP(port->no <= DW_GPIO_PORT_D, E_PAR);

	val32 = *((uint32_t *)param);	/* get bit mask */
	if (ctrl_cmd == GPIO_CMD_CHG_DIR_INPUT) {
		dw_gpio_write_dir(port, val32, DW_GPIO_INPUT_ALL);
		port_info_ptr->direction = dw_gpio_read_dir(port);
	} else if (ctrl_cmd == GPIO_CMD_CHG_DIR_OUTPUT) {
		dw_gpio_write_dir(port, val32, DW_GPIO_OUTPUT_ALL);
		port_info_ptr->direction = dw_gpio_read_dir(port);
	} else {
		DW_GPIO_CHECK_EXP(port->no == DW_GPIO_PORT_A, E_PAR);
		/* output pin cannot be used as interrupt */
		DW_GPIO_CHECK_EXP(!(val32 & port_info_ptr->direction), E_PAR);

		switch (ctrl_cmd) {
			case GPIO_CMD_CHG_MTHD_POLL:
				dw_gpio_int_disable(port, val32);
				port_info_ptr->method = dw_gpio_read_mthd(port);
				break;
			case GPIO_CMD_CHG_MTHD_INT:
				dw_gpio_int_enable(port, val32);
				port_info_ptr->method = dw_gpio_read_mthd(port);
				break;
			case DW_GPIO_CMD_INT_ENABLE:
				int_enable(port_info_ptr->intno);
				break;
			case DW_GPIO_CMD_INT_DISABLE:
				int_disable(port_info_ptr->intno);
				break;
			case DW_GPIO_CMD_INT_MASK:
				dw_gpio_int_mask(port, val32);
				break;
			case DW_GPIO_CMD_INT_UNMASK:
				dw_gpio_int_unmask(port, val32);
				break;
			case DW_GPIO_CMD_INT_LEVEL_TRIG:
				dw_gpio_int_write_level(port, val32, DW_GPIO_INT_LEVEL_TRIG);
				break;
			case DW_GPIO_CMD_INT_EDGE_TRIG:
				dw_gpio_int_write_level(port, val32, DW_GPIO_INT_EDGE_TRIG);
				break;
			case DW_GPIO_CMD_INT_POLARITY_HIGH:
				dw_gpio_int_write_polarity(port, val32, DW_GPIO_INT_ACT_HIGH);
				break;
			case DW_GPIO_CMD_INT_POLARITY_LOW:
				dw_gpio_int_write_polarity(port, val32, DW_GPIO_INT_ACT_LOW);
				break;
			case DW_GPIO_CMD_INT_DEBOUNCE:
				dw_gpio_int_write_debounce(port, val32, DW_GPIO_INT_DEBOUNCE);
				break;
			case DW_GPIO_CMD_INT_NODEBOUNCE:
				dw_gpio_int_write_debounce(port, val32, DW_GPIO_INT_NO_DEBOUNCE);
				break;
			case DW_GPIO_CMD_INT_CLEAR:
				dw_gpio_int_clear(port, val32);
				break;
			case GPIO_CMD_CHG_INTINFO:
				gpio_int_info = (DEV_GPIO_INT_INFO *)param;
				dw_gpio_int_write_level(port, gpio_int_info->int_bit_mask, gpio_int_info->int_type);
				if (gpio_int_info->int_type == DW_GPIO_INT_LEVEL_TRIG) {
					val32 = gpio_int_info->int_level;
				} else {
					val32 = gpio_int_info->int_edge;
				}
				dw_gpio_int_write_polarity(port, gpio_int_info->int_bit_mask, val32);
				dw_gpio_int_write_debounce(port, gpio_int_info->int_bit_mask, gpio_int_info->int_debounce);
				break;
			case GPIO_CMD_INT_BIT_ENABLE:
				dw_gpio_int_enable(port, 1<<val32);
				port_info_ptr->method = dw_gpio_read_mthd(port);
				break;
			case GPIO_CMD_INT_BIT_DISABLE:
				dw_gpio_int_disable(port, 1<<val32);
				port_info_ptr->method = dw_gpio_read_mthd(port);
				break;
			case GPIO_CMD_INT_BIT_REGISTER:
				port_bit_isr = (DEV_GPIO_BIT_ISR *)param;
				if (port_bit_isr->int_bit_ofs < port->gpio_bit_isr->int_bit_max_cnt) {
					port->gpio_bit_isr->int_bit_handler_ptr[port_bit_isr->int_bit_ofs] = port_bit_isr->int_bit_handler;
				} else {
					ercd = E_PAR;
				}
				break;
			default:
				ercd = E_ILUSE;
				break;
		}
	}
error_exit:
	return ercd;
}

/**
 * @brief 	designware interrupt handler
 * @param 	port_info_ptr	port info pointer
 * @param   ptr        		interrupt information passed
 * @return  error code of interrupt handler
 * @author huaqi.fang@synopsys.com
 * @version v0.1
 * @date    2014-07-29
 */
int32_t dw_gpio_isr_handler(DEV_GPIO_INFO_PTR port_info_ptr, void *ptr)
{
	int32_t ercd = E_OK;
	uint32_t i, gpio_bit_isr_state;
	uint32_t max_int_bit_count = 0;

	DW_GPIO_PORT_PTR port;

	/** check if gpio structure available */
	DW_GPIO_CHECK_EXP(port_info_ptr!=NULL, E_PAR);
	/** check if gpio was opened to do following things */
	DW_GPIO_CHECK_EXP(port_info_ptr->opn_flg==DEV_OPENED, E_CLSED);
	/** check if gpio was working good, not error */
	DW_GPIO_CHECK_EXP(port_info_ptr->err_flg==DEV_GOOD, E_OBJ);

	port = (DW_GPIO_PORT_PTR)(port_info_ptr->gpio_ctrl);

	DW_GPIO_CHECK_EXP(port->no == DW_GPIO_PORT_A, E_PAR);

	/** read interrupt status */
	gpio_bit_isr_state = dw_gpio_int_read_status(port);

	if (port->gpio_bit_isr) {
		max_int_bit_count = (port->gpio_bit_isr->int_bit_max_cnt);
	} else {
		dw_gpio_int_clear(port, gpio_bit_isr_state);
	}

	for (i=0; i<max_int_bit_count; i++) {
		if (gpio_bit_isr_state & (1<<i)) {
			dw_gpio_int_clear(port, (1<<i)); /** clear this bit interrupt */
			/* this bit interrupt enabled */
			if (port->gpio_bit_isr->int_bit_handler_ptr[i]) {
				port->gpio_bit_isr->int_bit_handler_ptr[i](&i);
			}
		}
	}

error_exit:
	return ercd;
}