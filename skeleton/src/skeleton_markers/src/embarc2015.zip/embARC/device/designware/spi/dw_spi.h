/* ------------------------------------------
 * Copyright (c) 2015, Synopsys, Inc. All rights reserved.

 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:

 * 1) Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.

 * 2) Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation and/or
 * other materials provided with the distribution.

 * 3) Neither the name of the Synopsys, Inc., nor the names of its contributors may
 * be used to endorse or promote products derived from this software without
 * specific prior written permission.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * \version 2015.05
 * \date 2014-06-25
 * \author Huaqi Fang(Huaqi.Fang@synopsys.com)
--------------------------------------------- */

/**
 * \file
 * \brief	DesignWare SPI driver header file
 * \ingroup	DEVICE_DW_SPI
 */

#ifndef _DEVICE_DW_SPI_H_
#define _DEVICE_DW_SPI_H_

#include "dev_spi.h"

/**
 * if this header file is included,
 * will indicate that this designware spi device
 * is used
 */
#define DEVICE_USE_DESIGNWARE_SPI

/**
 * \defgroup	DEVICE_DW_SPI_TRANSFERSTATE	DesignWare SPI Transfer State
 * \ingroup	DEVICE_DW_SPI
 * \brief	marcos to define current working state of spi module
 * @{
 */
#define DW_SPI_UNINITED		(0)	/*!< spi not inited */
#define DW_SPI_IDLE		(1)	/*!< spi init successful and idle now */
#define DW_SPI_UNDERTRANSFER	(2)	/*!< spi is under transfer now */
#define DW_SPI_TRANSFER_ERROR	(3)	/*!< spi transfer error */
/** @} end of DEVICE_DW_SPI_TRANSFERSTATE */

/**
 * \defgroup	DEVICE_DW_SPI_REGSTRUCT		DesignWare SPI Register Structure
 * \ingroup	DEVICE_DW_SPI
 * \brief	contains definitions of DesignWare SPI register structure.
 * \details	detailed description of DesignWare SPI register information
 * @{
 */
/**
 * \brief	DesignWare SPI register structure
 * \details	Detailed struct description of DesignWare SPI
 * 	block register information, implementation of dev_spi_info::spi_regs
 */
typedef volatile struct dw_spi_reg
{
	/*!< Control Register */
	/*!< SPI Control Register 0  (0x0) */
	uint32_t CTRLR0;
	/*!< SPI Control Register 1  (0x4) */
	uint32_t CTRLR1;
	/*!< Enable Register */
	/*!< SPI Enable Register  (0x8) */
	uint32_t SSIENR;
	/*!< SPI Microwire Control Register  (0xC) */
	uint32_t MWCR;
	/*!< SPI Slave Enable Register  (0x10) */
	uint32_t SER;
	/*!< SPI Baud Rate Select Register  (0x14) */
	uint32_t BAUDR;
	/*!< TX and RX FIFO Control Register */
	/*!< SPI Transmit FIFO Threshold Level Register  (0x18) */
	uint32_t TXFTLR;
	/*!< SPI Receive  FIFO Threshold Level Register  (0x1C) */
	uint32_t RXFTLR;
	/*!< SPI Transmit FIFO Level Register  (0x20) */
	uint32_t TXFLR;
	/*!< SPI Receive  FIFO Level Register  (0x24) */
	uint32_t RXFLR;
	/*!< SPI Status   Register  (0x28) */
	uint32_t SR;
	/*!< Interrupt Enable/Disable/Control Registers */
	/*!< SPI Interrupt Mask Register  (0x2C) */
	uint32_t IMR;
	/*!< SPI Interrupt Status Register  (0x30) */
	uint32_t ISR;
	/*!< SPI Raw Interrupt Status Register (0x34) */
	uint32_t RISR;
	/*!< SPI Transmit FIFO Overflow Interrupt Clear Register  (0x38) */
	uint32_t TXOICR;
	/*!< SPI Receive  FIFO Overflow Interrupt Clear Register  (0x3C) */
	uint32_t RXOICR;
	/*!< SPI Receive FIFO Underflow Interrupt Clear Register  (0x40) */
	uint32_t RXUICR;
	/*!< SPI Multi-Master Interrupt Clear Register  (0x44) */
	uint32_t MSTICR;
	/*!< SPI Interrupt Clear Register  (0x48) */
	uint32_t ICR;
	/*!< DMA Control Register  (0x4C) */
	uint32_t DMACTRL;
	/*!< DMA Transmit Data Level  (0x50) */
	uint32_t DMATDLR;
	/*!< DMA Receive Data Level  (0x54) */
	uint32_t DMARDLR;
	/*!< SPI Identification Register  (0x58) */
	uint32_t IDR;
	/*!< SPI CoreKit ID Register (Value after Reset : 0x3332322A)  (0x5C) */
	uint32_t SSI_VER_ID;
	/*!< Data Register */
	/*!< SPI DATA Register for both Read and Write  (0x60) */
	uint32_t DATAREG;
} DW_SPI_REG, *DW_SPI_REG_PTR;
/** @} */

/**
 * \brief	DesignWare SPI control structure definition
 * \details	implement of dev_spi_info::dev_spi_info
 */
typedef struct dw_spi_ctrl {
	uint32_t dw_spi_relbase;	/*!< spi ip base relative to peripheral baseaddr */
	uint32_t dw_apb_bus_freq;	/*!< spi ip apb bus frequence */
	uint32_t dw_spi_fifolen;	/*!< spi fifo len */
	uint32_t dw_spi_nbytes;		/*!< spi transfer bytes count in one write/read */
	uint32_t dw_spi_state;		/*!< spi working state, refer to \ref DEVICE_DW_SPI_TRANSFERSTATE */
	INT_HANDLER dw_spi_int_handler;	/*!< spi interrupt handler */
} DW_SPI_CTRL, *DW_SPI_CTRL_PTR;

/**
 * \defgroup	DEVICE_DW_SPI_FUNCDLR		DesignWare SPI Function Declaration
 * \ingroup	DEVICE_DW_SPI
 * \brief	contains declarations of designware spi functions.
 * \details	This are only used in \ref dw_spi_obj.c
 * @{
 */
extern int32_t dw_spi_get_info (DEV_SPI_INFO *spi_info_ptr, uint32_t cmd, void *rinfo);
extern int32_t dw_spi_open (DEV_SPI_INFO *spi_info_ptr, uint32_t freq, uint32_t mode, uint32_t method);
extern int32_t dw_spi_close (DEV_SPI_INFO *spi_info_ptr);
extern int32_t dw_spi_control (DEV_SPI_INFO *spi_info_ptr, uint32_t ctrl_cmd, void *param);
extern int32_t dw_spi_write (DEV_SPI_INFO *spi_info_ptr, const void *data, uint32_t len);
extern int32_t dw_spi_read (DEV_SPI_INFO *spi_info_ptr, void *data, uint32_t len);
extern void dw_spi_isr(DEV_SPI_INFO *spi_info_ptr, void *ptr);
/** @} */

/** @} */

#endif /* _DEVICE_DW_SPI_H_ */
