/* ------------------------------------------
 * Copyright (c) 2015, Synopsys, Inc. All rights reserved.

 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:

 * 1) Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.

 * 2) Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation and/or
 * other materials provided with the distribution.

 * 3) Neither the name of the Synopsys, Inc., nor the names of its contributors may
 * be used to endorse or promote products derived from this software without
 * specific prior written permission.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * \version 2015.05
 * \date 2014-07-22
 * \author Wayne Ren(Wei.Ren@synopsys.com)
--------------------------------------------- */

/**
 * \file
 * \brief	designware gpio driver
 * \ingroup	DEVICE_DW_GPIO
 * \brief	Designware GPIO driver header file
 */

#ifndef _DW_GPIO_H_
#define _DW_GPIO_H_

#include "dev_gpio.h"
#include "embARC_toolchain.h"
#include "embARC_error.h"
#include "arc_exception.h"

#define DW_GPIO_CMD_GETINFO_DIR			DEV_SET_USRCMD(0x3)
#define DW_GPIO_CMD_GETINFO_INT_PORLARITY	DEV_SET_USRCMD(0x4)
#define DW_GPIO_CMD_GETINFO_INT_LEVEL		DEV_SET_USRCMD(0x5)
#define DW_GPIO_CMD_GETINFO_INT_STATUS		DEV_SET_USRCMD(0x6)

#define DW_GPIO_CMD_INT_ENABLE			DEV_SET_USRCMD(0x3)
#define DW_GPIO_CMD_INT_DISABLE			DEV_SET_USRCMD(0x4)
#define DW_GPIO_CMD_INT_MASK			DEV_SET_USRCMD(0x5)
#define DW_GPIO_CMD_INT_UNMASK			DEV_SET_USRCMD(0x6)
#define DW_GPIO_CMD_INT_LEVEL_TRIG		DEV_SET_USRCMD(0x7)
#define DW_GPIO_CMD_INT_EDGE_TRIG		DEV_SET_USRCMD(0x8)
#define DW_GPIO_CMD_INT_POLARITY_HIGH		DEV_SET_USRCMD(0x9)
#define DW_GPIO_CMD_INT_POLARITY_LOW		DEV_SET_USRCMD(0xA)
#define DW_GPIO_CMD_INT_DEBOUNCE		DEV_SET_USRCMD(0xB)
#define DW_GPIO_CMD_INT_NODEBOUNCE		DEV_SET_USRCMD(0xC)
#define DW_GPIO_CMD_INT_CLEAR			DEV_SET_USRCMD(0xD)


#define DW_GPIO_PORT_A	(0x00)
#define DW_GPIO_PORT_B	(0x01)
#define DW_GPIO_PORT_C	(0x02)
#define DW_GPIO_PORT_D	(0x03)

#define DW_GPIO_INT_ACT_LOW			GPIO_INT_ACT_LOW
#define DW_GPIO_INT_ACT_HIGH			GPIO_INT_ACT_HIGH

#define DW_GPIO_INT_LEVEL_TRIG			GPIO_INT_LEVEL_TRIG
#define DW_GPIO_INT_EDGE_TRIG			GPIO_INT_EDGE_TRIG

#define DW_GPIO_INT_NO_DEBOUNCE			GPIO_INT_NO_DEBOUNCE
#define DW_GPIO_INT_DEBOUNCE			GPIO_INT_DEBOUNCE

#define DW_GPIO_MASK_ALL			(0xffffffff)
#define DW_GPIO_INPUT_ALL			(0x0)
#define DW_GPIO_OUTPUT_ALL			(0xffffffff)

typedef struct port_ctrl {
	uint32_t DR;
	uint32_t DDR;
	uint32_t CTRL;
} PORT_CTRL;

/* DW GPIO PORTS.*/
typedef volatile struct dw_gpio_reg {
	PORT_CTRL SWPORTS[4];
	uint32_t INTEN;		/*!< (0x30) */
	uint32_t INTMASK;	/*!< (0x34) */
	uint32_t INTTYPE_LEVEL;	/*!< (0x38) */
	uint32_t INT_POLARITY;	/*!< (0x3c) */
	uint32_t INTSTATUS;	/*!< (0x40) */
	uint32_t RAW_INTSTATUS;	/*!< (0x44) */
	uint32_t DEBOUNCE;	/*!< (0x48) */
	uint32_t PORTA_EOI;	/*!< (0x4c) */
	uint32_t EXT_PORTS[4];	/*!< (0x50) -A
				     (0x54) -B
				     (0x58) -C
				     (0x5c) -D */
	uint32_t LS_SYNC;	/*!< (0x60) */
	uint32_t ID_CODE;	/*!< (0x64) */
	uint32_t RESERVED_3;	/*!< (0x68) */
	uint32_t VER_ID_CODE;	/*!< (0x6c) */
	uint32_t CONFIG_REG2;	/*!< (0x70) */
	uint32_t CONFIG_REG1;	/*!< (0x74) */
} DW_GPIO_REG, *DW_GPIO_REG_PTR;

/** interrupt handler for each port bit */
typedef struct dw_gpio_bit_isr {
	uint32_t int_bit_max_cnt;		/*!< max bit count for each port */
	DEV_GPIO_HANDLER *int_bit_handler_ptr;	/*!< interrupt handler pointer */
} DW_GPIO_BIT_ISR, * DW_GPIO_BIT_ISR_PTR;

typedef struct dw_gpio_port {
	uint32_t no;				/*!< gpio port number */
	DW_GPIO_REG_PTR	regs;			/*!< gpio port register */
	uint32_t valid_bit_mask;		/*!< valid bit mask of gpio port */
	INT_HANDLER int_handler;		/*!< gpio interrupt handler */
	DW_GPIO_BIT_ISR_PTR gpio_bit_isr;	/*!< gpio bit handler struct */
} DW_GPIO_PORT, *DW_GPIO_PORT_PTR;

Inline uint32_t dw_gpio_read_ext(DW_GPIO_PORT_PTR port)
{
	return  port->regs->EXT_PORTS[port->no];
}

Inline uint32_t dw_gpio_read_dir(DW_GPIO_PORT_PTR port)
{
	return port->regs->SWPORTS[port->no].DDR;
}

Inline uint32_t dw_gpio_read_mthd(DW_GPIO_PORT_PTR port)
{
	return port->regs->INTEN;
}

Inline void dw_gpio_int_enable(DW_GPIO_PORT_PTR port, uint32_t bit_mask)
{
	port->regs->INTEN |= bit_mask;
}

Inline void dw_gpio_int_disable(DW_GPIO_PORT_PTR port, uint32_t bit_mask)
{
	port->regs->INTEN &= (~bit_mask);
}

Inline void dw_gpio_int_mask(DW_GPIO_PORT_PTR port, uint32_t bit_mask)
{
	port->regs->INTMASK |= bit_mask;
}

Inline void dw_gpio_int_unmask(DW_GPIO_PORT_PTR port, uint32_t bit_mask)
{
	port->regs->INTMASK &= (~bit_mask);
}

Inline uint32_t dw_gpio_int_read_level(DW_GPIO_PORT_PTR port)
{
	return port->regs->INTTYPE_LEVEL;
}

Inline uint32_t dw_gpio_int_read_polarity(DW_GPIO_PORT_PTR port)
{
	return port->regs->INT_POLARITY;
}

Inline uint32_t dw_gpio_int_read_status(DW_GPIO_PORT_PTR port)
{
	return port->regs->INTSTATUS;
}

Inline void dw_gpio_int_clear(DW_GPIO_PORT_PTR port, uint32_t bit_mask)
{
	port->regs->PORTA_EOI = bit_mask;
}

extern void dw_gpio_int_write_level(DW_GPIO_PORT_PTR port, uint32_t bit_mask, uint32_t level);
extern void dw_gpio_int_write_polarity(DW_GPIO_PORT_PTR port, uint32_t bit_mask, uint32_t pol);
extern void dw_gpio_int_write_debounce(DW_GPIO_PORT_PTR port, uint32_t bit_mask, uint32_t debounce);
extern int32_t dw_gpio_get_info (DEV_GPIO_INFO *port_info_ptr, uint32_t cmd, void *rinfo);
extern int32_t dw_gpio_open(DEV_GPIO_INFO_PTR port_info_ptr, uint32_t dir, uint32_t method);
extern int32_t dw_gpio_close(DEV_GPIO_INFO_PTR port_info_ptr);
extern int32_t dw_gpio_read(DEV_GPIO_INFO_PTR port_info_ptr, uint32_t *val, uint32_t mask);
extern int32_t dw_gpio_write(DEV_GPIO_INFO_PTR port_info_ptr, uint32_t val, uint32_t mask);
extern int32_t dw_gpio_control(DEV_GPIO_INFO_PTR port_info_ptr, uint32_t ctrl_cmd, void *param);
extern int32_t dw_gpio_isr_handler(DEV_GPIO_INFO_PTR port_info_ptr, void *ptr);

#endif /* _DW_GPIO_H_ */
