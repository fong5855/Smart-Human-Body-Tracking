/* ------------------------------------------
 * Copyright (c) 2015, Synopsys, Inc. All rights reserved.

 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:

 * 1) Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.

 * 2) Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation and/or
 * other materials provided with the distribution.

 * 3) Neither the name of the Synopsys, Inc., nor the names of its contributors may
 * be used to endorse or promote products derived from this software without
 * specific prior written permission.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * \version 2015.05
 * \date 2014-06-30
 * \author Huaqi Fang(Huaqi.Fang@synopsys.com)
--------------------------------------------- */

/**
 * \file
 * \brief	designware iic driver header file
 * \ingroup	DEVICE_DW_IIC
 */

#ifndef _DEVICE_DW_IIC_H_
#define _DEVICE_DW_IIC_H_

#include "dev_iic.h"

/**
 * If this header file is included,
 * will indicate that this designware iic device
 * is used
 */
#define DEVICE_USE_DESIGNWARE_IIC

/**
 * \defgroup	DEVICE_DW_IIC_INFO	DesignWare IIC Related Information
 * \ingroup	DEVICE_DW_IIC
 * \brief	Defines some macros of DesignWare IIC need.
 * \details	macros like, iic number
 * @{
 */

/* Software configurable - fifo trigger levels. */
#define DW_TX_FIFO_THRESHOLD	(0)
#define DW_RX_FIFO_THRESHOLD	(0)

#define I2C_OK			(0x00)
#define I2C_ERROR		(0x01)

/* I2C device status. */
#define I2C_BUSY		(0)
#define I2C_READY		(1)
/** @} */

/**
 * \defgroup	DEVICE_DW_IIC_WSTATE	DesignWare IIC Working State
 * \ingroup	DEVICE_DW_IIC
 * \brief	designware iic working state changes when send or receive data
 * @{
 */
/* I2C device state. */
#define I2C_STATE_READY		(1)
#define I2C_STATE_RECEIVE	(2)
#define I2C_STATE_TRANSMIT	(3)
#define I2C_STATE_FINISHED	(4)
/** @} */

/**
 * \defgroup	DEVICE_DW_IIC_REGSTRUCT		DesignWare IIC Register Structure
 * \ingroup	DEVICE_DW_IIC
 * \brief	contains definitions of DesignWare IIC register structure.
 * \details	detailed description of DesignWare IIC register information
 * @{
 */
/**
 * \brief	DesignWare IIC register structure
 * \details	Detailed struct description of DesignWare IIC
 *	block register information, implementation of dev_iic_info::iic_regs
 */
typedef volatile struct dw_iic_reg
{
	uint32_t IC_CON;		/*!< (0x00) : i2c control */
	uint32_t IC_TAR;		/*!< (0x04) : i2c target address */
	uint32_t IC_SAR;		/*!< (0x08) : i2c slave address */
	uint32_t IC_HS_MADDR;		/*!< (0x0c) : i2c HS Master Mode Code address */
	uint32_t IC_DATA_CMD;		/*!< (0x10) : i2c Rx/Tx Data Buffer and Command */
	uint32_t IC_SS_SCL_HCNT;	/*!< (0x14) : Standard Speed i2c clock SCL High Count */
	uint32_t IC_SS_SCL_LCNT;	/*!< (0x18) : Standard Speed i2c clock SCL Low Count */
	uint32_t IC_FS_SCL_HCNT;	/*!< (0x1c) : Fast Speed i2c clock SCL Low Count */
	uint32_t IC_FS_SCL_LCNT;	/*!< (0x20) : Fast Speed i2c clock SCL Low Count */
	uint32_t IC_HS_SCL_HCNT;	/*!< (0x24) : High Speed i2c clock SCL Low Count */
	uint32_t IC_HS_SCL_LCNT;	/*!< (0x28) : High Speed i2c clock SCL Low Count */
	uint32_t IC_INTR_STAT;		/*!< (0x2c) : i2c Interrupt Status */
	uint32_t IC_INTR_MASK;		/*!< (0x30) : i2c Interrupt Mask */
	uint32_t IC_RAW_INTR_STAT;	/*!< (0x34) : i2c Raw Interrupt Status */
	uint32_t IC_RX_TL;		/*!< (0x38) : i2c Receive FIFO Threshold */
	uint32_t IC_TX_TL;		/*!< (0x3c) : i2c Transmit FIFO Threshold */
	uint32_t IC_CLR_INTR;		/*!< (0x40) : Clear combined and Individual Interrupts */
	uint32_t IC_CLR_RX_UNDER;	/*!< (0x44) : Clear RX_UNDER Interrupt */
	uint32_t IC_CLR_RX_OVER;	/*!< (0x48) : Clear RX_OVER Interrupt */
	uint32_t IC_CLR_TX_OVER;	/*!< (0x4c) : Clear TX_OVER Interrupt */
	uint32_t IC_CLR_RD_REQ;		/*!< (0x50) : Clear RQ_REQ Interrupt */
	uint32_t IC_CLR_TX_ABRT;	/*!< (0x54) : Clear TX_ABRT Interrupt */
	uint32_t IC_CLR_RX_DONE;	/*!< (0x58) : Clear RX_DONE Interrupt */
	uint32_t IC_CLR_ACTIVITY;	/*!< (0x5c) : Clear ACTIVITY Interrupt */
	uint32_t IC_CLR_STOP_DET;	/*!< (0x60) : Clear STOP_DET Interrupt */
	uint32_t IC_CLR_START_DET;	/*!< (0x64) : Clear START_DET Interrupt */
	uint32_t IC_CLR_GEN_CALL;	/*!< (0x68) : Clear GEN_CALL Interrupt */
	uint32_t IC_ENABLE;		/*!< (0x6c) : i2c Enable */
	uint32_t IC_STATUS;		/*!< (0x70) : i2c Status */
	uint32_t IC_TXFLR;		/*!< (0x74) : Transmit FIFO Level Register */
	uint32_t IC_RXFLR;		/*!< (0x78) : Receive FIFO Level Register */
	uint32_t IC_SDA_HOLD;		/*!< (0x7c) : SDA Hold Time Length Reg */
	uint32_t IC_TX_ABRT_SOURCE;	/*!< (0x80) : i2c Transmit Abort Status Reg */
	uint32_t IC_SLV_DATA_NACK_ONLY;	/*!< (0x84) : Generate SLV_DATA_NACK Register */
	uint32_t IC_DMA_CR;		/*!< (0x88) : DMA Control Register */
	uint32_t IC_DMA_TDLR;		/*!< (0x8c) : DMA Transmit Data Level */
	uint32_t IC_DMA_RDLR;		/*!< (0x90) : DMA Receive Data Level */
	uint32_t IC_SDA_SETUP;		/*!< (0x94) : SDA Setup Register */
	uint32_t IC_ACK_GENERAL_CALL;	/*!< (0x98) : ACK General Call Register */
	uint32_t IC_ENABLE_STATUS;	/*!< (0x9c) : Enable Status Register */
	uint32_t IC_FS_SPKLEN;		/*!< (0xa0) : ISS and FS spike suppression limit */
	uint32_t IC_HS_SPKLEN;		/*!< (0xa4) : HS spike suppression limit */
	uint32_t RESERVED[19];		/*!< (0xa8) : Reserved */
	uint32_t IC_COMP_PARAM_1;	/*!< (0xf4) : Component Parameter Register */
	uint32_t IC_COMP_VERSION;	/*!< (0xf8) : Component Version ID Reg */
	uint32_t IC_COMP_TYPE;		/*!< (0xfc) : Component Type Reg */
} DW_IIC_REG, *DW_IIC_REG_PTR;
/** @} */

/**
 * \brief	DesignWare IIC control structure definition
 * \details	implement of dev_iic_info::dev_iic_info
 */
typedef struct dw_iic_ctrl {
	uint32_t dw_iic_relbase;	/*!< iic ip base relative to peripheral baseaddr  */
	uint32_t dw_apb_bus_freq;	/*!< iic ip apb bus frequence   */
	INT_HANDLER dw_iic_int_handler;	/*!< iic interrupt handler                  */
	uint32_t iic_state;		/*!< iic current working state */
	uint32_t iic_error_status;	/*!< iic error status */
	uint32_t iic_tx_over;		/*!< iic tx overflow count */
	uint32_t iic_rx_over;		/*!< iic rx overflow count */
	volatile uint32_t iic_snd_len;	/*!< iic send length */
	volatile uint32_t iic_snd_idx;	/*!< iic send index */
	volatile uint32_t iic_rcv_len;	/*!< iic receive length */
	volatile uint32_t iic_rcv_idx;	/*!< iic receive index */
	volatile uint32_t write_mode;	/*!< iic write mode */
	const void * iic_snd_buf;	/*!< iic send buffer pointor */
	void *iic_rcv_buf;		/*!< iic receive buffer pointor */
} DW_IIC_CTRL, *DW_IIC_CTRL_PTR;

/**
 * \defgroup	DEVICE_DW_IIC_FUNCDLR	DesignWare IIC Function Declaration
 * \ingroup	DEVICE_DW_IIC
 * \brief	Contains declarations of designware iic functions.
 * \details	This are only used in \ref dw_iic_obj.c
 * @{
 */
extern int32_t dw_iic_get_info (DEV_IIC_INFO *iic_info_ptr, uint32_t cmd, void *rinfo);
extern int32_t dw_iic_open (DEV_IIC_INFO *iic_info_ptr, uint32_t freq, uint32_t mode, uint32_t method);
extern int32_t dw_iic_close (DEV_IIC_INFO *iic_info_ptr);
extern int32_t dw_iic_control (DEV_IIC_INFO *iic_info_ptr, uint32_t ctrl_cmd, void *param);
extern int32_t dw_iic_write (DEV_IIC_INFO *iic_info_ptr, const void *data, uint32_t len);
extern int32_t dw_iic_read (DEV_IIC_INFO *iic_info_ptr, void *data, uint32_t len);
extern void dw_iic_isr(DEV_IIC_INFO *iic_info_ptr, void *ptr);
/** @} */

/** @} */

#endif /* _DEVICE_DW_IIC_H_ */
