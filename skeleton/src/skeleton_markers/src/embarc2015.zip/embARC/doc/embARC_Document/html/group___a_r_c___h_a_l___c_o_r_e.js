var group___a_r_c___h_a_l___c_o_r_e =
[
    [ "Core Definition", "group___a_r_c___h_a_l___c_o_r_e___c_o_m_m.html", "group___a_r_c___h_a_l___c_o_r_e___c_o_m_m" ],
    [ "EM Series", "group___a_r_c___h_a_l___c_o_r_e___e_m.html", "group___a_r_c___h_a_l___c_o_r_e___e_m" ],
    [ "HS Series", "group___a_r_c___h_a_l___c_o_r_e___h_s.html", "group___a_r_c___h_a_l___c_o_r_e___h_s" ]
];