var group___a_r_c___h_a_l =
[
    [ "Compiler Builtin and Helper", "group___a_r_c___h_a_l___b_u_i_l_t_i_n.html", "group___a_r_c___h_a_l___b_u_i_l_t_i_n" ],
    [ "Core HAL", "group___a_r_c___h_a_l___c_o_r_e.html", "group___a_r_c___h_a_l___c_o_r_e" ],
    [ "Exception and Interrupt", "group___a_r_c___h_a_l___e_x_c_e_p_t_i_o_n.html", "group___a_r_c___h_a_l___e_x_c_e_p_t_i_o_n" ],
    [ "Internal Components", "group___a_r_c___h_a_l___m_i_s_c.html", "group___a_r_c___h_a_l___m_i_s_c" ],
    [ "Startup", "group___a_r_c___h_a_l___s_t_a_r_t_u_p.html", null ]
];