var group___a_r_c___h_a_l___c_o_r_e___e_m =
[
    [ "arc_em.h", "arc__em_8h.html", null ]
];