var group___a_r_c___h_a_l___e_x_c_e_p_t_i_o_n___c_p_u =
[
    [ "arc_exception.c", "arc__exception_8c.html", null ],
    [ "arc_exception.h", "arc__exception_8h.html", null ],
    [ "NUM_EXC_ALL", "group___a_r_c___h_a_l___e_x_c_e_p_t_i_o_n___c_p_u.html#gae5139fa9096875ad9a126741fce30e03", null ],
    [ "NUM_EXC_CPU", "group___a_r_c___h_a_l___e_x_c_e_p_t_i_o_n___c_p_u.html#ga1443e9a11bdf7ee0540d79c6ebcc321f", null ],
    [ "NUM_EXC_INT", "group___a_r_c___h_a_l___e_x_c_e_p_t_i_o_n___c_p_u.html#ga07e2a217a7f54496ed4ad507d48d894d", null ],
    [ "EXC_ENTRY", "group___a_r_c___h_a_l___e_x_c_e_p_t_i_o_n___c_p_u.html#gae3672aa4e2804ea07d3ecd02d68b2893", null ],
    [ "EXC_HANDLER", "group___a_r_c___h_a_l___e_x_c_e_p_t_i_o_n___c_p_u.html#ga76ef78e52a0465e63fcebd9385b71bbd", null ],
    [ "_arc_reset", "group___a_r_c___h_a_l___e_x_c_e_p_t_i_o_n___c_p_u.html#ga7eada76e99261c0fcc1ad28909770ef1", null ],
    [ "exc_entry_default", "group___a_r_c___h_a_l___e_x_c_e_p_t_i_o_n___c_p_u.html#ga8675632bfc45dfc4b9ccf97c559b2e37", null ],
    [ "exc_entry_get", "group___a_r_c___h_a_l___e_x_c_e_p_t_i_o_n___c_p_u.html#ga46edef87701cac2e231b674ace9984c4", null ],
    [ "exc_entry_install", "group___a_r_c___h_a_l___e_x_c_e_p_t_i_o_n___c_p_u.html#ga8f747480018612aab9fb83556580a897", null ],
    [ "exc_entry_int", "group___a_r_c___h_a_l___e_x_c_e_p_t_i_o_n___c_p_u.html#ga3d9c822d87f512a468d2247f4c150cab", null ],
    [ "exc_handler_get", "group___a_r_c___h_a_l___e_x_c_e_p_t_i_o_n___c_p_u.html#ga0602dbd11b7f4bbce7c5fba96d945139", null ],
    [ "exc_handler_install", "group___a_r_c___h_a_l___e_x_c_e_p_t_i_o_n___c_p_u.html#gada230bd0bd55152a783f9fee5d11f0eb", null ],
    [ "exc_sense", "group___a_r_c___h_a_l___e_x_c_e_p_t_i_o_n___c_p_u.html#ga4fbb945b914687002f7c283252f77ed0", null ],
    [ "exc_vector_base_read", "group___a_r_c___h_a_l___e_x_c_e_p_t_i_o_n___c_p_u.html#ga3ec60ebbf99ecb22ddd15492a96f5edd", null ],
    [ "exc_vector_base_write", "group___a_r_c___h_a_l___e_x_c_e_p_t_i_o_n___c_p_u.html#gaf8163e1ce7f9fbf19d5f09eebc58fc8a", null ],
    [ "exc_entry_table", "group___a_r_c___h_a_l___e_x_c_e_p_t_i_o_n___c_p_u.html#ga91b7022c29998a80fe16897fd8514a8f", null ],
    [ "exc_nest_count", "group___a_r_c___h_a_l___e_x_c_e_p_t_i_o_n___c_p_u.html#ga5f9b7ff48abdf4699865396f0cce4cc8", null ]
];