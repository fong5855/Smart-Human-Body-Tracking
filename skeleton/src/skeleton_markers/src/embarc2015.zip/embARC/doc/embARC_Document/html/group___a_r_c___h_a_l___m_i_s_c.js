var group___a_r_c___h_a_l___m_i_s_c =
[
    [ "Cache", "group___a_r_c___h_a_l___m_i_s_c___c_a_c_h_e.html", "group___a_r_c___h_a_l___m_i_s_c___c_a_c_h_e" ],
    [ "Internal Timer", "group___a_r_c___h_a_l___m_i_s_c___t_i_m_e_r.html", "group___a_r_c___h_a_l___m_i_s_c___t_i_m_e_r" ],
    [ "arc_asm_common.h", "arc__asm__common_8h.html", null ]
];