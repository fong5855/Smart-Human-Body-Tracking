var group___a_r_c___h_a_l___c_o_r_e___h_s =
[
    [ "arc_hs.h", "arc__hs_8h.html", null ]
];