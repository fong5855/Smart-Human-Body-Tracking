var group___a_r_c___h_a_l___b_u_i_l_t_i_n =
[
    [ "arc_builtin.h", "arc__builtin_8h.html", null ],
    [ "_arc_brk", "group___a_r_c___h_a_l___b_u_i_l_t_i_n.html#ga7974888f34d00304cbeaf8ab948d1269", null ],
    [ "_arc_clri", "group___a_r_c___h_a_l___b_u_i_l_t_i_n.html#ga72cb582da8bcbe8bd56fd701e5e022bf", null ],
    [ "_arc_core_read", "group___a_r_c___h_a_l___b_u_i_l_t_i_n.html#ga13a91ed1f6deafab4253accdb2976af9", null ],
    [ "_arc_core_write", "group___a_r_c___h_a_l___b_u_i_l_t_i_n.html#ga04aedd6ff5e8bd995f276a4c5e996290", null ],
    [ "_arc_flag", "group___a_r_c___h_a_l___b_u_i_l_t_i_n.html#gaaa9cdf00a9a835f7fee4f8cafeded961", null ],
    [ "_arc_lr_reg", "group___a_r_c___h_a_l___b_u_i_l_t_i_n.html#ga9a3e0a1903d9a64e35b3ad3866ce5b0f", null ],
    [ "_arc_nop", "group___a_r_c___h_a_l___b_u_i_l_t_i_n.html#gaf3f0dc7e55ccccc48b5221b044fea76c", null ],
    [ "_arc_seti", "group___a_r_c___h_a_l___b_u_i_l_t_i_n.html#gac88768a7f4c0cdba77e0adfbb8a5aebd", null ],
    [ "_arc_sleep", "group___a_r_c___h_a_l___b_u_i_l_t_i_n.html#gae3ae996a22713a4641a075a97b3447ca", null ],
    [ "_arc_sr_reg", "group___a_r_c___h_a_l___b_u_i_l_t_i_n.html#ga8ee255d46720ce1489efdc9d18f2756e", null ],
    [ "_arc_swi", "group___a_r_c___h_a_l___b_u_i_l_t_i_n.html#gac5e596c9be37023b785d097061ec14d7", null ],
    [ "_arc_sync", "group___a_r_c___h_a_l___b_u_i_l_t_i_n.html#gae036cd29e75a50a6e98090522cbb3968", null ],
    [ "_arc_read_cached_32", "group___a_r_c___h_a_l___b_u_i_l_t_i_n.html#gaa7a668f089bf8c4ca7d050977b91ad97", null ],
    [ "_arc_read_uncached_32", "group___a_r_c___h_a_l___b_u_i_l_t_i_n.html#gafdc2fb9ca910be4c26acac3d23a50c04", null ],
    [ "_arc_write_cached_32", "group___a_r_c___h_a_l___b_u_i_l_t_i_n.html#ga36e9e097538d46192c144c0954f5f5e2", null ],
    [ "_arc_write_uncached_32", "group___a_r_c___h_a_l___b_u_i_l_t_i_n.html#gafb8cae06aec51bb3f6298cc7226c139d", null ]
];