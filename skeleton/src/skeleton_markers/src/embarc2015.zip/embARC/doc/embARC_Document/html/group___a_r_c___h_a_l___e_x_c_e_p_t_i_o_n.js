var group___a_r_c___h_a_l___e_x_c_e_p_t_i_o_n =
[
    [ "CPU Exception", "group___a_r_c___h_a_l___e_x_c_e_p_t_i_o_n___c_p_u.html", "group___a_r_c___h_a_l___e_x_c_e_p_t_i_o_n___c_p_u" ],
    [ "Interrupt", "group___a_r_c___h_a_l___e_x_c_e_p_t_i_o_n___i_n_t_e_r_r_u_p_t.html", "group___a_r_c___h_a_l___e_x_c_e_p_t_i_o_n___i_n_t_e_r_r_u_p_t" ]
];