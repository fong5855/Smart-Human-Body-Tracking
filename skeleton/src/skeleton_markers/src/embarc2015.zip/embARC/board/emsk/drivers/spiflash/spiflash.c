/* ------------------------------------------
 * Copyright (c) 2015, Synopsys, Inc. All rights reserved.

 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:

 * 1) Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.

 * 2) Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation and/or
 * other materials provided with the distribution.

 * 3) Neither the name of the Synopsys, Inc., nor the names of its contributors may
 * be used to endorse or promote products derived from this software without
 * specific prior written permission.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * \version 2015.05
 * \date 2014-07-17
 * \author Huaqi Fang(Huaqi.Fang@synopsys.com)
--------------------------------------------- */

/**
 * \defgroup	BOARD_EMSK_DRV_SPIFLASH	EMSK SPI Flash Driver
 * \ingroup	BOARD_EMSK_DRIVER
 * \brief	EMSK Onboard SPIFlash Driver
 * \details
 *		Realize driver for onboard W25Q128BV spi flash using Designware spi driver.
 */

/**
 * \file
 * \ingroup	BOARD_EMSK_DRV_SPIFLASH
 * \brief	emsk onboard W25Q128BV spiflash driver
 */

/**
 * \addtogroup	BOARD_EMSK_DRV_SPIFLASH
 * @{
 */
#include "spiflash.h"

#include "embARC_error.h"
#include "board.h"
#include "dev_spi.h"
#include "arc_exception.h"

/**
 * \name	SPI Flash Commands
 * @{
 */
#define RDID	0x9F	/*!<read chip ID */
#define RDSR	0x05	/*!< read status register */
#define WRSR	0x01	/*!< write status register */
#define WREN	0x06	/*!< write enablewaitDeviceReady */
#define WRDI	0x04	/*!< write disable */
#define READ	0x03	/*!<read data bytes */
#define SE	0x20	/*!< sector erase */
#define PP	0x02	/*!< page program */
/** @} end of name */

#define SPI_LINE_SFLASH		BOARD_SFLASH_SPI_LINE
#define SPI_ID_SFLASH		BOARD_SFLASH_SPI_ID

#define SPI_FLASH_FREQ		(BOARD_SPI_FREQ)

static DEV_SPI *spi_flash;
static uint32_t cs_flash = SPI_LINE_SFLASH;

/**
 * \brief	spi flash spi send command to operate spi flash
 * \param[in]	xfer	spi transfer that need to transfer to spi device
 */
Inline void spi_send_cmd(struct dev_spi_transfer *xfer)
{
	uint32_t cpu_status;

	cpu_status = cpu_lock_save();

	/* select device */
	spi_flash->spi_control(SPI_CMD_SEL_DEV, &cs_flash);
	spi_flash->spi_control(SPI_CMD_TRANSFER, xfer);
	/* deselect device */
	spi_flash->spi_control(SPI_CMD_DSEL_DEV, &cs_flash);

	cpu_unlock_restore(cpu_status);
}

/**
 * \brief	init spi flash related interface
 */
void flash_init(void)
{
	spi_flash = spi_get_dev(SPI_ID_SFLASH);
	spi_flash->spi_open(SPI_FLASH_FREQ, DEV_MASTER_MODE, DEV_POLL_METHOD);
}

/**
 * \brief	read spiflash identification ID
 * \return	the id of the spi flash
 */
uint32_t flash_read_id(void)
{
	uint32_t id = 0;
	uint8_t local_buf[4];
	struct dev_spi_transfer cmd_xfer;

	local_buf[0] = RDID;

	cmd_xfer.next = NULL;
	cmd_xfer.snd_buf = local_buf;
	cmd_xfer.snd_cnt = 1;
	cmd_xfer.rcv_buf = local_buf;
	cmd_xfer.rcv_cnt = 3;
	cmd_xfer.rcv_ofs = 1;

	spi_send_cmd(&cmd_xfer);

	id = (local_buf[0] << 16) | (local_buf[1] << 8) | local_buf[2] ;

	return id;
}

/**
 * \brief	read the status of spi flash
 * \return	current status of spi flash
 */
uint32_t flash_read_status(void)
{

	uint8_t local_buf[2];
	struct dev_spi_transfer cmd_xfer;

	local_buf[0] = RDSR;

	cmd_xfer.next = NULL;
	cmd_xfer.snd_buf = local_buf;
	cmd_xfer.snd_cnt = 1;
	cmd_xfer.rcv_buf = local_buf;
	cmd_xfer.rcv_cnt = 1;
	cmd_xfer.rcv_ofs = 1;

	spi_send_cmd(&cmd_xfer);

	return local_buf[0];
}

/**
 * \brief	read data from flash
 * \param[in]	address		read start address of spi flash
 * \param[in]	size		read size of spi flash
 * \param[out]	data		data to store the return data
 *
 * \retval	1		failed in read operation
 * \retval	>=0		data size of data read
 */
int32_t flash_read(unsigned int address, unsigned int size, void *data)
{

	uint8_t local_buf[4];
	struct dev_spi_transfer cmd_xfer;

	/* out of range */
	if ((address + size) >= BOOTIMAGE_END)
		return -1;

	local_buf[0] = READ;
	local_buf[1] = (address >> 16) & 0xff;
	local_buf[2] = (address >> 8) & 0xff;
	local_buf[3] = address  & 0xff;


	cmd_xfer.next = NULL;
	cmd_xfer.snd_buf = local_buf;
	cmd_xfer.snd_cnt = 4;
	cmd_xfer.rcv_buf = data;
	cmd_xfer.rcv_cnt = size;
	cmd_xfer.rcv_ofs = 4;

	spi_send_cmd(&cmd_xfer);

	return size;
}

/**
 * \brief 	Read status and wait while busy flag is set
 */
void flash_wait_ready(void)
{
	unsigned int status = 0x01;
	do {
		status = flash_read_status();
	} while (status & 0x01);

}

/**
 * \brief 	enable to write flash
 */
void flash_write_enable(void)
{
	uint8_t local_buf[3];
	struct dev_spi_transfer cmd_xfer;

	unsigned int status = 0;
	do {
		local_buf[0] = WREN;

		cmd_xfer.next = NULL;
		cmd_xfer.snd_buf = local_buf;
		cmd_xfer.snd_cnt = 1;
		cmd_xfer.rcv_buf = NULL;
		cmd_xfer.rcv_cnt = 0;
		cmd_xfer.rcv_ofs = 0;

		spi_send_cmd(&cmd_xfer);
		status = flash_read_status();
		// clear protection bits
		//  Write Protect. and Write Enable.
		if( (status & 0xfc) && (status & 0x02) ) {
			local_buf[0] = WRSR; // write status
			local_buf[1] = 0x00; // write status
			local_buf[2] = 0x00; // write status

			cmd_xfer.next = NULL;
			cmd_xfer.snd_buf = local_buf;
			cmd_xfer.snd_cnt = 3;
			cmd_xfer.rcv_buf = NULL;
			cmd_xfer.rcv_cnt = 0;
			cmd_xfer.rcv_ofs = 0;

			spi_send_cmd(&cmd_xfer);
			status = 0;
		}
	} while ( status != 0x02);
}


/**
 * \brief 	flash erase in sectors
 *
 * \param[in]	address		erase start address of spi flash
 * \param[in]	size		erase size
 *
 * \retval	-1 		failed in erase operation
 * \retval	>=0		sector count erased
 */
int32_t flash_erase(uint32_t address, uint32_t size)
{
	uint32_t last_address;
	uint32_t count = 0;
	uint8_t local_buf[4];
	struct dev_spi_transfer cmd_xfer;

	/* check parameter */
	if (address < BOOTIMAGE_START || (address + size) >= BOOTIMAGE_END)
		return -1;

	// start ddress of last sector
	last_address = (address + size) & (~(FLASH_SECTOR_SIZE - 1));

	// start address of first sector
	address &= ~(FLASH_SECTOR_SIZE - 1);

	do {
		flash_write_enable();

		local_buf[0] = SE;
		local_buf[1] = (address >> 16) & 0xff;
		local_buf[2] = (address >> 8) & 0xff;
		local_buf[3] =  address & 0xff;

		cmd_xfer.next = NULL;
		cmd_xfer.snd_buf = local_buf;
		cmd_xfer.snd_cnt = 4;
		cmd_xfer.rcv_buf = NULL;
		cmd_xfer.rcv_cnt = 0;
		cmd_xfer.rcv_ofs = 0;

		spi_send_cmd(&cmd_xfer);

		flash_wait_ready();

		address += FLASH_SECTOR_SIZE;
		count++;
	} while(address <= last_address);

	return (int32_t)count;
}

/**
 * \brief	write data to spi flash
 *
 * \param[in]	address	start address
 * \param[in]	size	data size
 * \param[in]	data	pointer to data
 *
 * \retval	>=0		written bytes number
 * \retval 	<0 		error
 */
int32_t flash_write(uint32_t address, uint32_t size, const void *data)
{

	uint8_t local_buf[4];
	struct dev_spi_transfer cmd_xfer;
	struct dev_spi_transfer data_xfer;

	uint32_t first = 0;
	uint32_t size_orig = size;

	/* check parameter */
	if (address < BOOTIMAGE_START || (address + size) >= BOOTIMAGE_END)
		return -1;

	flash_wait_ready();

	first = FLASH_PAGE_SIZE - (address & (FLASH_PAGE_SIZE - 1));

	do {
		// send write enable command to flash
		flash_write_enable();
		flash_wait_ready();

		first = first < size ? first : size;

		local_buf[0] = PP;
		local_buf[1] = (address >> 16) & 0xff;
		local_buf[2] = (address >> 8) & 0xff;
		local_buf[3] = address  & 0xff;

		cmd_xfer.next = &data_xfer;
		cmd_xfer.snd_buf = local_buf;
		cmd_xfer.snd_cnt = 4;
		cmd_xfer.rcv_buf = NULL;
		cmd_xfer.rcv_cnt = 0;
		cmd_xfer.rcv_ofs = 0;

		data_xfer.next = NULL;
		data_xfer.snd_buf = (void *)data;
		data_xfer.snd_cnt = first;
		data_xfer.rcv_buf = NULL;
		data_xfer.rcv_cnt = 0;
		data_xfer.rcv_ofs = 0;

		spi_send_cmd(&cmd_xfer);

		size -= first;
		address += first;
		data += first;
		first = FLASH_PAGE_SIZE;

	} while (size);

	flash_wait_ready();

	return (int32_t)(size_orig);
}

/** @} end of group BOARD_EMSK_DRV_SPIFLASH */
