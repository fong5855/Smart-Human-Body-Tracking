/* ------------------------------------------
 * Copyright (c) 2015, Synopsys, Inc. All rights reserved.

 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:

 * 1) Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.

 * 2) Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation and/or
 * other materials provided with the distribution.

 * 3) Neither the name of the Synopsys, Inc., nor the names of its contributors may
 * be used to endorse or promote products derived from this software without
 * specific prior written permission.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * \version 2015.05
 * \date 2014-07-31
 * \author Wayne Ren(Wei.Ren@synopsys.com)
--------------------------------------------- */
/**
 * \defgroup	BOARD_EMSK_COMMON_INIT	EMSK Common Init Module
 * \ingroup	BOARD_EMSK_COMMON
 * \brief	EMSK Board Common Init Module
 * \details
 * 		EMSK timer/gpio/interrupt init process. Device-driver installation is done while
 *	getting the device object for the first time.
 */

/**
 * \file
 * \ingroup	BOARD_EMSK_COMMON_INIT
 * \brief	common emsk init module
 */

/**
 * \addtogroup	BOARD_EMSK_COMMON_INIT
 * @{
 */
#include "arc_builtin.h"
#include "arc.h"
#include "arc_timer.h"
#include "arc_exception.h"

#include "board.h"

#ifdef MID_COMMON
#include "console_io.h"
#endif

#include "emsk_timer.h"

#include "../drivers/mux/io_types.h"
#include "../drivers/mux/mux.h"

#define PERIPHERAL_BASE		_arc_aux_read(AUX_DMP_PERIPHERAL)

/**
 * \brief	Disable all interrupts during startup (OPTIONAL)
 * \note	When debugging using jtag, the chip might not
 *	fully reset. Some interrupts are still enabled,
 *	causing them to go into the default routine and resulting in a bug.
 */
static void all_interrupt_disable(void)
{
	int i;

	for (i=NUM_EXC_CPU; i<NUM_EXC_ALL; i++) {
		int_disable(i);
	}
}

/**
 * \brief	emsk-related mux io init
 */
static void emsk_mux_init(void)
{
	DWCREG_PTR mux;

	mux = (DWCREG_PTR)(PERIPHERAL_BASE|REL_REGBASE_PINMUX);
	mux_init(mux);
	/**
	 * set up pin-multiplexer to route I2C lines on Pmod2
	 * PM5 J5: Use as PMOD & GPIO
	 * PM5 J1: Connect upper row to UART0, use lower row as GPIO
	 */
	set_pmod_mux(mux, PM2_I2C_HRI|PM5_UR_SPI_M1|PM5_LR_GPIO_A \
		|PM6_UR_SPI_M0|PM6_LR_GPIO_A|PM1_UR_UART_0|PM1_LR_GPIO_A);

	/**
	 * PM1 upper row as UART for HM10 BLE
	 * UM4:RXD, UM3:TXD
	 * UM2:RTS_N, UM1:CTS_N
	 */
	set_uart_map(mux, 0x9c);
}

/**
 * \brief	Board init routine MUST be called in each application
 * \note	It is better to disable interrupts when calling this function
 *	remember to enable interrupt when you want to use them
 */
void board_init(void)
{
	timer_init();
	all_interrupt_disable();
	emsk_mux_init();
	emsk_gpio_init();
	emsk_timer_init();
	int_ipm_set(INT_PRI_MAX);
#ifdef MID_COMMON
	xprintf_setup(DEV_INTERRUPT_METHOD);
#endif
}

/** @} end of group BOARD_EMSK_COMMON_INIT */
