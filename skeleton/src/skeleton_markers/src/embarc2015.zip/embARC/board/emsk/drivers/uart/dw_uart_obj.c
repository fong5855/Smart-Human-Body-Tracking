/* ------------------------------------------
 * Copyright (c) 2015, Synopsys, Inc. All rights reserved.

 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:

 * 1) Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.

 * 2) Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation and/or
 * other materials provided with the distribution.

 * 3) Neither the name of the Synopsys, Inc., nor the names of its contributors may
 * be used to endorse or promote products derived from this software without
 * specific prior written permission.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * \version 2015.05
 * \date 2014-07-03
 * \author Huaqi Fang(Huaqi.Fang@synopsys.com)
--------------------------------------------- */

/**
 * \defgroup	BOARD_EMSK_DRV_DW_UART_OBJ	EMSK DW UART Object
 * \ingroup	BOARD_EMSK_DRIVER
 * \brief	EMSK Designware UART Objects
 * \details
 *		Realize the EMSK board uart object using Designware uart device driver,
 *	only need to realize some Designware uart structures combine with EMSK uart
 *	hardware resource. just like cpp class instantiation.
 */

/**
 * \file
 * \ingroup	BOARD_EMSK_DRV_DW_UART_OBJ
 * \brief	designware uart object instantiation on emsk
 */

/**
 * \addtogroup	BOARD_EMSK_DRV_DW_UART_OBJ
 * @{
 */
#include "arc.h"
#include "arc_builtin.h"
#include "embARC_toolchain.h"
#include "embARC_error.h"

#include "arc_exception.h"

#include "ringbuffer.h"
#include "dw_uart.h"
#include "dw_uart_obj.h"

#include "../../emsk.h"

#define PERIPHERAL_BASE		_arc_aux_read(AUX_DMP_PERIPHERAL)

/**
 * \name	EMSK DesignWare UART 0 Object Instantiation
 * @{
 */
#if (USE_DW_UART_0)
static void dw_uart_0_isr(void *ptr);
#define DW_UART_0_RELBASE	(REL_REGBASE_UART0)	/*!< designware uart 0 relative baseaddr */
#define DW_UART_0_INTNO		(INTNO_UART0)		/*!< designware uart 0 interrupt number  */

DEV_UART		dw_uart_0;			/*!< designware uart object */
DW_UART_CTRL	dw_uart_0_ctrl = {			/*!< designware uart 0 ctrl */
	DW_UART_0_RELBASE, CLK_BUS_APB, (INT_HANDLER)dw_uart_0_isr
};
static rb_buftype dw_uart_0_sndbuf[MAX_SNDBUF_SIZE];
static rb_buftype dw_uart_0_rcvbuf[MAX_RCVBUF_SIZE];

/** designware uart 0 get info */
static int32_t dw_uart_0_get_info (uint32_t cmd, void *rinfo)
{
	return dw_uart_get_info(&(dw_uart_0.uart_info), cmd, rinfo);
}
/** designware uart 0 open */
static int32_t dw_uart_0_open (uint32_t baud, uint32_t method)
{
	return dw_uart_open(&(dw_uart_0.uart_info), baud, method);
}
/** designware uart 0 close */
static int32_t dw_uart_0_close (void)
{
	return dw_uart_close(&(dw_uart_0.uart_info));
}
/** designware uart 0 control */
static int32_t dw_uart_0_control (uint32_t ctrl_cmd, void *param)
{
	return dw_uart_control(&(dw_uart_0.uart_info), ctrl_cmd, param);
}
/** designware uart 0 write */
static int32_t dw_uart_0_write (const void *data, uint32_t len)
{
	return dw_uart_write(&(dw_uart_0.uart_info), data, len);
}
/** designware uart 0 close */
static int32_t dw_uart_0_read (void *data, uint32_t len)
{
	return dw_uart_read(&(dw_uart_0.uart_info), data, len);
}
/** designware uart 0 interrupt rountine */
static void dw_uart_0_isr(void *ptr)
{
	dw_uart_isr(&(dw_uart_0.uart_info), ptr);
}
/** install designware uart 0 to system */
static void dw_uart_0_install(void)
{
	uint32_t uart_abs_base = 0;
	DEV_UART *dw_uart_ptr = &dw_uart_0;
	DEV_UART_INFO *dw_uart_info_ptr = &(dw_uart_0.uart_info);
	DW_UART_CTRL *dw_uart_ctrl_ptr = &dw_uart_0_ctrl;
	DW_UART_REG *dw_uart_reg_ptr;

	/**
	 * get absolute designware base address
	 */
	uart_abs_base = (uint32_t)PERIPHERAL_BASE + dw_uart_ctrl_ptr->dw_uart_relbase;
	dw_uart_reg_ptr = (DW_UART_REG *)uart_abs_base;

	/** uart info init */
	dw_uart_info_ptr->uart_regs = (void *)dw_uart_reg_ptr;
	dw_uart_info_ptr->uart_ctrl = (void *)dw_uart_ctrl_ptr;
	dw_uart_info_ptr->opn_flg = DEV_CLOSED;
	dw_uart_info_ptr->err_flg = DEV_GOOD;
	dw_uart_info_ptr->baudrate = UART_BAUDRATE_115200;  /* default 115200bps */
	dw_uart_info_ptr->method = DEV_POLL_METHOD;
	dw_uart_info_ptr->intno = DW_UART_0_INTNO;
	dw_uart_info_ptr->ioctl = UART_IOCTL_NULL;
	dw_uart_info_ptr->read_mode = 0;

	/** uart dev init */
	dw_uart_ptr->uart_get_info = dw_uart_0_get_info;
	dw_uart_ptr->uart_open = dw_uart_0_open;
	dw_uart_ptr->uart_close = dw_uart_0_close;
	dw_uart_ptr->uart_control = dw_uart_0_control;
	dw_uart_ptr->uart_write = dw_uart_0_write;
	dw_uart_ptr->uart_read = dw_uart_0_read;

	/** send and receive ringbuffer init */
	if (rb_init(&(dw_uart_ctrl_ptr->snd_rb), &dw_uart_0_sndbuf[0], MAX_SNDBUF_SIZE) != 0) {
		dw_uart_info_ptr->err_flg = DEV_ERROR;
	}
	if (rb_init(&(dw_uart_ctrl_ptr->rcv_rb), &dw_uart_0_rcvbuf[0], MAX_RCVBUF_SIZE) != 0) {
		dw_uart_info_ptr->err_flg = DEV_ERROR;
	}
}
#endif /* USE_DW_UART_0 */
/** @} end of name */

/**
 * \name	EMSK DesignWare UART 1 Object Instantiation
 * @{
 */
#if (USE_DW_UART_1)
static void dw_uart_1_isr(void *ptr);
#define DW_UART_1_RELBASE	(REL_REGBASE_UART1)	/*!< designware uart 1 relative baseaddr */
#define DW_UART_1_INTNO		(INTNO_UART1)		/*!< designware uart 1 interrupt number  */

DEV_UART		dw_uart_1;			/*!< designware uart 1 object */
DW_UART_CTRL	dw_uart_1_ctrl = {			/*!< designware uart 1 ctrl */
	DW_UART_1_RELBASE, CLK_BUS_APB, (INT_HANDLER)dw_uart_1_isr
};
static rb_buftype dw_uart_1_sndbuf[MAX_SNDBUF_SIZE];
static rb_buftype dw_uart_1_rcvbuf[MAX_RCVBUF_SIZE];

/** designware uart 1 get info */
static int32_t dw_uart_1_get_info (uint32_t cmd, void *rinfo)
{
	return dw_uart_get_info(&(dw_uart_1.uart_info), cmd, rinfo);
}
/** designware uart 1 open */
static int32_t dw_uart_1_open (uint32_t baud, uint32_t method)
{
	return dw_uart_open(&(dw_uart_1.uart_info), baud, method);
}
/** designware uart 1 close */
static int32_t dw_uart_1_close (void)
{
	return dw_uart_close(&(dw_uart_1.uart_info));
}
/** designware uart 1 control */
static int32_t dw_uart_1_control (uint32_t ctrl_cmd, void *param)
{
	return dw_uart_control(&(dw_uart_1.uart_info), ctrl_cmd, param);
}
/** designware uart 1 write */
static int32_t dw_uart_1_write (const void *data, uint32_t len)
{
	return dw_uart_write(&(dw_uart_1.uart_info), data, len);
}
/** designware uart 1 close */
static int32_t dw_uart_1_read (void *data, uint32_t len)
{
	return dw_uart_read(&(dw_uart_1.uart_info), data, len);
}
/** designware uart 1 interrupt routine */
static void dw_uart_1_isr(void *ptr)
{
	dw_uart_isr(&(dw_uart_1.uart_info), ptr);
}
/** install designware uart 1 to system */
static void dw_uart_1_install(void)
{
	uint32_t uart_abs_base = 0;
	DEV_UART *dw_uart_ptr = &dw_uart_1;
	DEV_UART_INFO *dw_uart_info_ptr = &(dw_uart_1.uart_info);
	DW_UART_CTRL *dw_uart_ctrl_ptr = &dw_uart_1_ctrl;
	DW_UART_REG *dw_uart_reg_ptr;

	/**
	 * get absolute designware base address
	 */
	uart_abs_base = (uint32_t)PERIPHERAL_BASE + dw_uart_ctrl_ptr->dw_uart_relbase;
	dw_uart_reg_ptr = (DW_UART_REG *)uart_abs_base;

	/** uart info init */
	dw_uart_info_ptr->uart_regs = (void *)dw_uart_reg_ptr;
	dw_uart_info_ptr->uart_ctrl = (void *)dw_uart_ctrl_ptr;
	dw_uart_info_ptr->opn_flg = DEV_CLOSED;
	dw_uart_info_ptr->err_flg = DEV_GOOD;
	dw_uart_info_ptr->baudrate = UART_BAUDRATE_115200;  /* default 115200bps */
	dw_uart_info_ptr->method = DEV_POLL_METHOD;
	dw_uart_info_ptr->intno = DW_UART_1_INTNO;
	dw_uart_info_ptr->ioctl = UART_IOCTL_NULL;
	dw_uart_info_ptr->read_mode = 0;

	/** uart dev init */
	dw_uart_ptr->uart_get_info = dw_uart_1_get_info;
	dw_uart_ptr->uart_open = dw_uart_1_open;
	dw_uart_ptr->uart_close = dw_uart_1_close;
	dw_uart_ptr->uart_control = dw_uart_1_control;
	dw_uart_ptr->uart_write = dw_uart_1_write;
	dw_uart_ptr->uart_read = dw_uart_1_read;
	/** send and receive ringbuffer init */
	if (rb_init(&(dw_uart_ctrl_ptr->snd_rb), &dw_uart_1_sndbuf[0], MAX_SNDBUF_SIZE) != 0) {
		dw_uart_info_ptr->err_flg = DEV_ERROR;
	}
	if (rb_init(&(dw_uart_ctrl_ptr->rcv_rb), &dw_uart_1_rcvbuf[0], MAX_RCVBUF_SIZE) != 0) {
		dw_uart_info_ptr->err_flg = DEV_ERROR;
	}
}
#endif /* USE_DW_UART_1 */
/** @} end of name */

/** get one designware device structure */
DEV_UART_PTR uart_get_dev(int32_t uart_id)
{
	static uint32_t install_flag = 0;

	/* intall device objects */
	if (install_flag == 0) {
		install_flag = 1;
		dw_uart_all_install();
	}

	switch (uart_id) {
#if (USE_DW_UART_0)
		case DW_UART_0_ID:
			return &dw_uart_0;
			break;
#endif
#if (USE_DW_UART_1)
		case DW_UART_1_ID:
			return &dw_uart_1;
			break;
#endif
		default:
			break;
	}
	return NULL;
}

/**
 * \brief	install all uart objects
 * \note	\b MUST be called during system init
 */
void dw_uart_all_install(void)
{
#if (USE_DW_UART_0)
	dw_uart_0_install();
#endif
#if (USE_DW_UART_1)
	dw_uart_1_install();
#endif
}

/** @} end of group BOARD_EMSK_DRV_DW_UART_OBJ */
