/* ------------------------------------------
 * Copyright (c) 2015, Synopsys, Inc. All rights reserved.

 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:

 * 1) Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.

 * 2) Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation and/or
 * other materials provided with the distribution.

 * 3) Neither the name of the Synopsys, Inc., nor the names of its contributors may
 * be used to endorse or promote products derived from this software without
 * specific prior written permission.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * \version 2015.05
 * \date 2014-07-03
 * \author Huaqi Fang(Huaqi.Fang@synopsys.com)
--------------------------------------------- */

/**
 * \defgroup	BOARD_EMSK_DRV_DW_IIC_OBJ	EMSK DW IIC Object
 * \ingroup	BOARD_EMSK_DRIVER
 * \brief	EMSK Designware IIC Objects
 * \details
 *		Realize the EMSK board iic object using designware iic device driver,
 *	only need to realize some designware iic structures combine with EMSK iic
 *	hardware resource. just like cpp class instantiation.
 */

/**
 * \file
 * \ingroup	BOARD_EMSK_DRV_DW_IIC_OBJ
 * \brief	designware iic object instantiation on emsk
 */

/**
 * \addtogroup	BOARD_EMSK_DRV_DW_IIC_OBJ
 * @{
 */
#include "arc.h"
#include "arc_builtin.h"
#include "embARC_toolchain.h"
#include "embARC_error.h"

#include "arc_exception.h"

#include "dw_iic.h"
#include "dw_iic_obj.h"

#include "../../emsk.h"

#define PERIPHERAL_BASE		_arc_aux_read(AUX_DMP_PERIPHERAL)

/**
 * \name	EMSK DesignWare IIC 0 Object Instantiation
 * @{
 */
#if (USE_DW_IIC_0)
static void dw_iic_0_isr(void *ptr);
#define DW_IIC_0_RELBASE	(REL_REGBASE_I2C0)	/*!< designware iic 0 relative baseaddr */
#define DW_IIC_0_INTNO		(INTNO_I2C0)		/*!< designware iic 0 interrupt number  */
#define DW_IIC_0_SLVADDR	(0x55)			/*!< iic 0 slave address working in slave mode */

DEV_IIC			dw_iic_0;			/*!< designware iic object */
DW_IIC_CTRL		dw_iic_0_ctrl = {		/*!< designware iic 0 ctrl */
	DW_IIC_0_RELBASE, CLK_BUS_APB, (INT_HANDLER)dw_iic_0_isr,
	I2C_STATE_READY, 0, 0, 0,
	0, 0, 0, 0,IIC_WRITE_MODE_STOP,
	(const void *)0, (void *)0
};

/** designware iic 0 get info */
static int32_t dw_iic_0_get_info (uint32_t cmd, void *rinfo)
{
	return dw_iic_get_info(&(dw_iic_0.iic_info), cmd, rinfo);
}
/** designware iic 0 open */
static int32_t dw_iic_0_open (uint32_t speed, uint32_t mode, uint32_t method)
{
	return dw_iic_open(&(dw_iic_0.iic_info), speed, mode, method);
}
/** designware iic 0 close */
static int32_t dw_iic_0_close (void)
{
	return dw_iic_close(&(dw_iic_0.iic_info));
}
/** designware iic 0 control */
static int32_t dw_iic_0_control (uint32_t ctrl_cmd, void *param)
{
	return dw_iic_control(&(dw_iic_0.iic_info), ctrl_cmd, param);
}
/** designware iic 0 write */
static int32_t dw_iic_0_write (const void *data, uint32_t len)
{
	return dw_iic_write(&(dw_iic_0.iic_info), data, len);
}
/** designware iic 0 close */
static int32_t dw_iic_0_read (void *data, uint32_t len)
{
	return dw_iic_read(&(dw_iic_0.iic_info), data, len);
}
/** designware iic 0 interrupt rountine */
static void dw_iic_0_isr(void *ptr)
{
	dw_iic_isr(&(dw_iic_0.iic_info), ptr);
}
/** install designware iic 0 to system */
static void dw_iic_0_install(void)
{
	uint32_t iic_abs_base = 0;
	DEV_IIC *dw_iic_ptr = &dw_iic_0;
	DEV_IIC_INFO *dw_iic_info_ptr = &(dw_iic_0.iic_info);
	DW_IIC_CTRL *dw_iic_ctrl_ptr = &dw_iic_0_ctrl;
	DW_IIC_REG *dw_iic_reg_ptr;

	/**
	 * get absolute designware base address
	 */
	iic_abs_base = (uint32_t)PERIPHERAL_BASE + dw_iic_ctrl_ptr->dw_iic_relbase;
	dw_iic_reg_ptr = (DW_IIC_REG *)iic_abs_base;

	/** iic info init */
	dw_iic_info_ptr->iic_regs = (void *)dw_iic_reg_ptr;
	dw_iic_info_ptr->iic_ctrl = (void *)dw_iic_ctrl_ptr;
	dw_iic_info_ptr->opn_flg = DEV_CLOSED;
	dw_iic_info_ptr->err_flg = DEV_GOOD;
	dw_iic_info_ptr->speed = IIC_SPEED_STANDARD;
	dw_iic_info_ptr->mode = DEV_MASTER_MODE;
	dw_iic_info_ptr->slv_addr = DW_IIC_0_SLVADDR;
	dw_iic_info_ptr->tar_addr = 0;
	dw_iic_info_ptr->method = DEV_POLL_METHOD;
	dw_iic_info_ptr->intno = DW_IIC_0_INTNO;

	/** iic dev init */
	dw_iic_ptr->iic_get_info = dw_iic_0_get_info;
	dw_iic_ptr->iic_open = dw_iic_0_open;
	dw_iic_ptr->iic_close = dw_iic_0_close;
	dw_iic_ptr->iic_control = dw_iic_0_control;
	dw_iic_ptr->iic_write = dw_iic_0_write;
	dw_iic_ptr->iic_read = dw_iic_0_read;
}
#endif /* USE_DW_IIC_0 */
/** @} end of name */

/**
 * \name	EMSK DesignWare IIC 1 Object Instantiation
 * @{
 */
#if (USE_DW_IIC_1)
static void dw_iic_1_isr(void *ptr);
#define DW_IIC_1_RELBASE	(REL_REGBASE_I2C1)	/*!< designware iic 1 relative baseaddr */
#define DW_IIC_1_INTNO		(INTNO_I2C1)		/*!< designware iic 1 interrupt number  */
#define DW_IIC_1_SLVADDR	(0x55)			/*!< iic 1 slave address working in slave mode */

DEV_IIC		dw_iic_1;				/*!< designware iic 1 object */
DW_IIC_CTRL 	dw_iic_1_ctrl = {			/*!< designware iic 1 ctrl */
	DW_IIC_1_RELBASE, CLK_BUS_APB, (INT_HANDLER)dw_iic_1_isr,
	I2C_STATE_READY, 0, 0, 0,
	0, 0, 0, 0,IIC_WRITE_MODE_STOP,
	(const void *)0, (void *)0
};

/** designware iic 1 get info */
static int32_t dw_iic_1_get_info (uint32_t cmd, void *rinfo)
{
	return dw_iic_get_info(&(dw_iic_1.iic_info), cmd, rinfo);
}
/** designware iic 1 open */
static int32_t dw_iic_1_open (uint32_t speed, uint32_t mode, uint32_t method)
{
	return dw_iic_open(&(dw_iic_1.iic_info), speed, mode, method);
}
/** designware iic 1 close */
static int32_t dw_iic_1_close (void)
{
	return dw_iic_close(&(dw_iic_1.iic_info));
}
/** designware iic 1 control */
static int32_t dw_iic_1_control (uint32_t ctrl_cmd, void *param)
{
	return dw_iic_control(&(dw_iic_1.iic_info), ctrl_cmd, param);
}
/** designware iic 1 write */
static int32_t dw_iic_1_write (const void *data, uint32_t len)
{
	return dw_iic_write(&(dw_iic_1.iic_info), data, len);
}
/** designware iic 1 close */
static int32_t dw_iic_1_read (void *data, uint32_t len)
{
	return dw_iic_read(&(dw_iic_1.iic_info), data, len);
}
/** designware iic 1 interrupt routine */
static void dw_iic_1_isr(void *ptr)
{
	dw_iic_isr(&(dw_iic_1.iic_info), ptr);
}
/** install designware iic 1 to system */
static void dw_iic_1_install(void)
{
	uint32_t iic_abs_base = 0;
	DEV_IIC *dw_iic_ptr = &dw_iic_1;
	DEV_IIC_INFO *dw_iic_info_ptr = &(dw_iic_1.iic_info);
	DW_IIC_CTRL *dw_iic_ctrl_ptr = &dw_iic_1_ctrl;
	DW_IIC_REG *dw_iic_reg_ptr;

	/**
	 * get absolute designware base address
	 */
	iic_abs_base = (uint32_t)PERIPHERAL_BASE + dw_iic_ctrl_ptr->dw_iic_relbase;
	dw_iic_reg_ptr = (DW_IIC_REG *)iic_abs_base;

	/** iic info init */
	dw_iic_info_ptr->iic_regs = (void *)dw_iic_reg_ptr;
	dw_iic_info_ptr->iic_ctrl = (void *)dw_iic_ctrl_ptr;
	dw_iic_info_ptr->opn_flg = DEV_CLOSED;
	dw_iic_info_ptr->err_flg = DEV_GOOD;
	dw_iic_info_ptr->speed = IIC_SPEED_STANDARD;
	dw_iic_info_ptr->mode = DEV_MASTER_MODE;
	dw_iic_info_ptr->slv_addr = DW_IIC_1_SLVADDR;
	dw_iic_info_ptr->tar_addr = 0;
	dw_iic_info_ptr->method = DEV_POLL_METHOD;
	dw_iic_info_ptr->intno = DW_IIC_1_INTNO;

	/** iic dev init */
	dw_iic_ptr->iic_get_info = dw_iic_1_get_info;
	dw_iic_ptr->iic_open = dw_iic_1_open;
	dw_iic_ptr->iic_close = dw_iic_1_close;
	dw_iic_ptr->iic_control = dw_iic_1_control;
	dw_iic_ptr->iic_write = dw_iic_1_write;
	dw_iic_ptr->iic_read = dw_iic_1_read;
}
#endif /* USE_DW_IIC_1 */
/** @} end of name */

/** get one designware device structure */
DEV_IIC_PTR iic_get_dev(int32_t iic_id)
{
	static uint32_t install_flag = 0;

	/* intall device objects */
	if (install_flag == 0) {
		install_flag = 1;
		dw_iic_all_install();
	}

	switch (iic_id) {
#if (USE_DW_IIC_0)
		case DW_IIC_0_ID:
			return &dw_iic_0;
			break;
#endif
#if (USE_DW_IIC_1)
		case DW_IIC_1_ID:
			return &dw_iic_1;
			break;
#endif
		default:
			break;
	}
	return NULL;
}

/**
 * \brief	install all iic objects
 * \note	\b MUST be called during system init
 */
void dw_iic_all_install(void)
{
#if (USE_DW_IIC_0)
	dw_iic_0_install();
#endif
#if (USE_DW_IIC_1)
	dw_iic_1_install();
#endif
}

/** @} end of group BOARD_EMSK_DRV_DW_IIC_OBJ */
