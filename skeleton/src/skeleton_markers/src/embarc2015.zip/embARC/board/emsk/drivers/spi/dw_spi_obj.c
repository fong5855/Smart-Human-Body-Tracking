/* ------------------------------------------
 * Copyright (c) 2015, Synopsys, Inc. All rights reserved.

 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:

 * 1) Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.

 * 2) Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation and/or
 * other materials provided with the distribution.

 * 3) Neither the name of the Synopsys, Inc., nor the names of its contributors may
 * be used to endorse or promote products derived from this software without
 * specific prior written permission.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * \version 2015.05
 * \date 2014-07-03
 * \author Huaqi Fang(Huaqi.Fang@synopsys.com)
--------------------------------------------- */

/**
 * \defgroup	BOARD_EMSK_DRV_DW_SPI_OBJ	EMSK DW SPI Object
 * \ingroup	BOARD_EMSK_DRIVER
 * \brief	EMSK Designware SPI Objects
 * \details
 *		realize the EMSK board spi object using designware spi device driver,
 *	only need to realize some designware spi structures combine with EMSK spi
 *	hardware resource. just like cpp class instantiation.
 */

/**
 * \file
 * \ingroup	BOARD_EMSK_DRV_DW_SPI_OBJ
 * \brief	designware spi object instantiation on emsk
 */

/**
 * \addtogroup	BOARD_EMSK_DRV_DW_SPI_OBJ
 * @{
 */
#include "arc.h"
#include "arc_builtin.h"
#include "embARC_toolchain.h"
#include "embARC_error.h"

#include "arc_exception.h"

#include "dw_spi.h"
#include "dw_spi_obj.h"

#include "../../emsk.h"

#define PERIPHERAL_BASE		_arc_aux_read(AUX_DMP_PERIPHERAL)

/**
 * \name	EMSK DesignWare SPI 0 Object Instantiation
 * @{
 */
#if (USE_DW_SPI_0)
static void dw_spi_0_isr(void *ptr);
#define DW_SPI_0_RELBASE	(REL_REGBASE_SPI0)	/*!< designware spi 0 relative baseaddr */
#define DW_SPI_0_INTNO		(INTNO_SPI_MASTER)	/*!< designware spi 0 interrupt number  */

DEV_SPI			dw_spi_0;			/*!< designware spi object */
DW_SPI_CTRL		dw_spi_0_ctrl = {		/*!< designware spi 0 ctrl */
	DW_SPI_0_RELBASE, CLK_BUS_APB,
	0, 1, DW_SPI_UNINITED,
	(INT_HANDLER)dw_spi_0_isr
};

/** designware spi 0 get info */
static int32_t dw_spi_0_get_info (uint32_t cmd, void *rinfo)
{
	return dw_spi_get_info(&(dw_spi_0.spi_info), cmd, rinfo);
}
/** designware spi 0 open */
static int32_t dw_spi_0_open (uint32_t freq, uint32_t mode, uint32_t method)
{
	return dw_spi_open(&(dw_spi_0.spi_info), freq, mode, method);
}
/** designware spi 0 close */
static int32_t dw_spi_0_close (void)
{
	return dw_spi_close(&(dw_spi_0.spi_info));
}
/** designware spi 0 control */
static int32_t dw_spi_0_control (uint32_t ctrl_cmd, void *param)
{
	return dw_spi_control(&(dw_spi_0.spi_info), ctrl_cmd, param);
}
/** designware spi 0 write */
static int32_t dw_spi_0_write (const void *data, uint32_t len)
{
	return dw_spi_write(&(dw_spi_0.spi_info), data, len);
}
/** designware spi 0 close */
static int32_t dw_spi_0_read (void *data, uint32_t len)
{
	return dw_spi_read(&(dw_spi_0.spi_info), data, len);
}
/** designware spi 0 interrupt rountine */
static void dw_spi_0_isr(void *ptr)
{
	dw_spi_isr(&(dw_spi_0.spi_info), ptr);
}
/** install designware spi 0 to system */
static void dw_spi_0_install(void)
{
	uint32_t spi_abs_base = 0;
	DEV_SPI *dw_spi_ptr = &dw_spi_0;
	DEV_SPI_INFO *dw_spi_info_ptr = &(dw_spi_0.spi_info);
	DW_SPI_CTRL *dw_spi_ctrl_ptr = &dw_spi_0_ctrl;
	DW_SPI_REG *dw_spi_reg_ptr;

	/**
	 * get absolute designware base address
	 */
	spi_abs_base = (uint32_t)PERIPHERAL_BASE + dw_spi_ctrl_ptr->dw_spi_relbase;
	dw_spi_reg_ptr = (DW_SPI_REG *)spi_abs_base;

	/** spi info init */
	dw_spi_info_ptr->spi_regs = (void *)dw_spi_reg_ptr;
	dw_spi_info_ptr->spi_ctrl = (void *)dw_spi_ctrl_ptr;
	dw_spi_info_ptr->opn_flg = DEV_CLOSED;
	dw_spi_info_ptr->err_flg = DEV_GOOD;
	dw_spi_info_ptr->freq = 1000;  /* default 1Khz */
	dw_spi_info_ptr->mode = DEV_MASTER_MODE;
	dw_spi_info_ptr->clock_mode = SPI_CLK_MODE_3;
	dw_spi_info_ptr->method = DEV_POLL_METHOD;
	dw_spi_info_ptr->intno = DW_SPI_0_INTNO;
	dw_spi_info_ptr->dummy_wr_byte = 0xff;

	/** spi dev init */
	dw_spi_ptr->spi_get_info = dw_spi_0_get_info;
	dw_spi_ptr->spi_open = dw_spi_0_open;
	dw_spi_ptr->spi_close = dw_spi_0_close;
	dw_spi_ptr->spi_control = dw_spi_0_control;
	dw_spi_ptr->spi_write = dw_spi_0_write;
	dw_spi_ptr->spi_read = dw_spi_0_read;
}
#endif /* USE_DW_SPI_0 */
/** @} end of name */

/**
 * \name	EMSK DesignWare SPI 1 Object Instantiation
 * @{
 */
#if (USE_DW_SPI_1)
static void dw_spi_1_isr(void *ptr);
#define DW_SPI_1_RELBASE	(REL_REGBASE_SPI1)	/*!< designware spi 1 relative baseaddr */
#define DW_SPI_1_INTNO		(INTNO_SPI_SLAVE)	/*!< designware spi 1 interrupt number  */

DEV_SPI			dw_spi_1;			/*!< designware spi 1 object */
DW_SPI_CTRL		dw_spi_1_ctrl = {		/*!< designware spi 1 ctrl */
	DW_SPI_1_RELBASE, CLK_BUS_APB,
	0, 1, DW_SPI_UNINITED,
	(INT_HANDLER)dw_spi_1_isr
};

/** designware spi 1 get info */
static int32_t dw_spi_1_get_info (uint32_t cmd, void *rinfo)
{
	return dw_spi_get_info(&(dw_spi_1.spi_info), cmd, rinfo);
}
/** designware spi 1 open */
static int32_t dw_spi_1_open (uint32_t freq, uint32_t mode, uint32_t method)
{
	return dw_spi_open(&(dw_spi_1.spi_info), freq, mode, method);
}
/** designware spi 1 close */
static int32_t dw_spi_1_close (void)
{
	return dw_spi_close(&(dw_spi_1.spi_info));
}
/** designware spi 1 control */
static int32_t dw_spi_1_control (uint32_t ctrl_cmd, void *param)
{
	return dw_spi_control(&(dw_spi_1.spi_info), ctrl_cmd, param);
}
/** designware spi 1 write */
static int32_t dw_spi_1_write (const void *data, uint32_t len)
{
	return dw_spi_write(&(dw_spi_1.spi_info), data, len);
}
/** designware spi 1 close */
static int32_t dw_spi_1_read (void *data, uint32_t len)
{
	return dw_spi_read(&(dw_spi_1.spi_info), data, len);
}
/** designware spi 1 interrupt rountine */
static void dw_spi_1_isr(void *ptr)
{
	dw_spi_isr(&(dw_spi_1.spi_info), ptr);
}
/** install designware spi 1 to system */
static void dw_spi_1_install(void)
{
	uint32_t spi_abs_base = 0;
	DEV_SPI *dw_spi_ptr = &dw_spi_1;
	DEV_SPI_INFO *dw_spi_info_ptr = &(dw_spi_1.spi_info);
	DW_SPI_CTRL *dw_spi_ctrl_ptr = &dw_spi_1_ctrl;
	DW_SPI_REG *dw_spi_reg_ptr;

	/**
	 * get absolute designware base address
	 */
	spi_abs_base = (uint32_t)PERIPHERAL_BASE + dw_spi_ctrl_ptr->dw_spi_relbase;
	dw_spi_reg_ptr = (DW_SPI_REG *)spi_abs_base;

	/** spi info init */
	dw_spi_info_ptr->spi_regs = (void *)dw_spi_reg_ptr;
	dw_spi_info_ptr->spi_ctrl = (void *)dw_spi_ctrl_ptr;
	dw_spi_info_ptr->opn_flg = DEV_CLOSED;
	dw_spi_info_ptr->err_flg = DEV_GOOD;
	dw_spi_info_ptr->freq = 1000;  /* default 1Khz */
	dw_spi_info_ptr->mode = DEV_MASTER_MODE;
	dw_spi_info_ptr->clock_mode = SPI_CLK_MODE_3;
	dw_spi_info_ptr->method = DEV_POLL_METHOD;
	dw_spi_info_ptr->intno = DW_SPI_1_INTNO;
	dw_spi_info_ptr->dummy_wr_byte = 0xff;

	/** spi dev init */
	dw_spi_ptr->spi_get_info = dw_spi_1_get_info;
	dw_spi_ptr->spi_open = dw_spi_1_open;
	dw_spi_ptr->spi_close = dw_spi_1_close;
	dw_spi_ptr->spi_control = dw_spi_1_control;
	dw_spi_ptr->spi_write = dw_spi_1_write;
	dw_spi_ptr->spi_read = dw_spi_1_read;
}
#endif /* USE_DW_SPI_1 */
/** @} end of name */

/** get one designware device structure */
DEV_SPI_PTR spi_get_dev(int32_t spi_id)
{
	static uint32_t install_flag = 0;

	/* intall device objects */
	if (install_flag == 0) {
		install_flag = 1;
		dw_spi_all_install();
	}

	switch (spi_id) {
#if (USE_DW_SPI_0)
		case DW_SPI_0_ID:
			return &dw_spi_0;
			break;
#endif
#if (USE_DW_SPI_1)
		case DW_SPI_1_ID:
			return &dw_spi_1;
			break;
#endif
		default:
			break;
	}
	return NULL;
}

/**
 * \brief	install all spi objects
 * \note	\b MUST be called during system init
 */
void dw_spi_all_install(void)
{
#if (USE_DW_SPI_0)
	dw_spi_0_install();
#endif
#if (USE_DW_SPI_1)
	dw_spi_1_install();
#endif
}

/** @} end of group BOARD_EMSK_DRV_DW_SPI_OBJ */
