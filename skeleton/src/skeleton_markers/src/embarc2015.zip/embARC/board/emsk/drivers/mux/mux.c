/* ------------------------------------------
 * Copyright (c) 2015, Synopsys, Inc. All rights reserved.

 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:

 * 1) Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.

 * 2) Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation and/or
 * other materials provided with the distribution.

 * 3) Neither the name of the Synopsys, Inc., nor the names of its contributors may
 * be used to endorse or promote products derived from this software without
 * specific prior written permission.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * \version 2015.05
 * \date 2014-07-07
 * \author Huaqi Fang(Huaqi.Fang@synopsys.com)
--------------------------------------------- */
/**
 * \defgroup	BOARD_EMSK_DRV_MUX	EMSK Mux Driver
 * \ingroup	BOARD_EMSK_DRIVER
 * \brief	EMSK Mux Controller Driver
 * \details
 *		Mux controller is the hardware external PMOD port pin connection
 *	controller, it can distribute the external port pins into different
 *	functions like general input/output, spi, iic, uart and so on.
 */

/**
 * \file
 * \ingroup	BOARD_EMSK_DRV_MUX
 * \brief	emsk mux controller driver
 */

/**
 * \addtogroup	BOARD_EMSK_DRV_MUX
 * @{
 */
#include "io_types.h"
#include "mux_hal.h"
#include "mux.h"

/** initialize i2c controller and set slave device address */
void mux_init(DWCREG_PTR mux_regs)
{
	// Initialize Mux controller registers by default values
	mux_regs[PMOD_MUX_CTRL] = PMOD_MUX_CTRL_DEFAULT;
	mux_regs[SPI_MAP_CTRL] =  SPI_MAP_CTRL_DEFAULT;
	mux_regs[UART_MAP_CTRL] = UART_MAP_CTRL_DEFAULT;
}

/** set PMOD muxer scheme */
void set_pmod_mux(DWCREG_PTR mux_regs, unsigned int val)
{
	mux_regs[PMOD_MUX_CTRL] = val;
}

/** get PMOD muxer scheme */
unsigned int get_pmod_mux(DWCREG_PTR mux_regs)
{
	return (unsigned int) mux_regs[PMOD_MUX_CTRL];
}

/** set PMOD muxer scheme */
void change_pmod_mux(DWCREG_PTR mux_regs, unsigned int val, unsigned int change_bits)
{
	mux_regs[PMOD_MUX_CTRL] = ((mux_regs[PMOD_MUX_CTRL] & ~change_bits) | val);
}

/** set SPI connection scheme */
void set_spi_map(DWCREG_PTR mux_regs, unsigned int val)
{
	mux_regs[SPI_MAP_CTRL] = val;
}

/** get SPI connection scheme */
unsigned int get_spi_map(DWCREG_PTR mux_regs)
{
	return (unsigned int) mux_regs[SPI_MAP_CTRL];
}

/** set UART connection scheme */
void set_uart_map(DWCREG_PTR mux_regs, unsigned int val)
{
	mux_regs[UART_MAP_CTRL] = val;
}

/** get UART connection scheme */
unsigned int get_uart_map(DWCREG_PTR mux_regs)
{
	return (unsigned int) mux_regs[UART_MAP_CTRL];
}
/** @} end of group BOARD_EMSK_DRV_MUX */

